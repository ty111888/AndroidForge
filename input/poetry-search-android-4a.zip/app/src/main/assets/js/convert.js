/* convert.js — 简繁转换（OpenCC）：显示转换、搜索词展开、整页 DOM 转换
 * 浏览器里挂在 window.PSConvert，Node 里用 require 引入（用 init() 传入两个 OpenCC 库）。 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory(root);
  else root.PSConvert = factory(root);
})(typeof self !== 'undefined' ? self : this, function (root) {
  'use strict';

  var libT2 = null, libC2 = null, ready = false, convs = {}, rev = null, cache = new Map();
  var mode = 's';            // 's' = 显示简体（按钮显示"简"）  't' = 显示繁体（按钮显示"繁"）
  var variant = 'std';       // 繁体写法：std 标准 / tw 台湾 / hk 香港
  var VARMAP = { std: 't', tw: 'tw', hk: 'hk', twp: 'twp' };
  var listeners = [];
  var HAN = /[\u3400-\u9fff\uf900-\ufaff]/;

  function conv(kind, to) {
    var key = kind + ':' + to;
    if (!convs[key]) convs[key] = kind === 't2cn' ? libT2.Converter({ from: 't', to: 'cn' }) : libC2.Converter({ from: 'cn', to: to });
    return convs[key];
  }
  function init(libs) { libT2 = libs.t2cn; libC2 = libs.cn2t; ready = !!(libT2 && libC2); convs = {}; rev = null; cache.clear(); }

  // 加载脚本，最多等 8 秒；挂住或失败都按失败处理，不让转换库卡住页面
  function loadScript(src) {
    return new Promise(function (res, rej) {
      var done = false;
      var timer = setTimeout(function () { if (!done) { done = true; rej(new Error('加载超时：' + src)); } }, 8000);
      var s = document.createElement('script');
      s.src = src;
      s.onload = function () { if (!done) { done = true; clearTimeout(timer); res(); } };
      s.onerror = function () { if (!done) { done = true; clearTimeout(timer); rej(new Error('加载失败：' + src)); } };
      document.head.appendChild(s);
    });
  }
  async function load() {
    if (ready) return;
    await loadScript('vendor/opencc/t2cn.js'); var a = root.OpenCC;
    await loadScript('vendor/opencc/cn2t.js'); var b = root.OpenCC;
    init({ t2cn: a, cn2t: b });
  }

  function remember(k, v) { if (cache.size > 6000) cache.clear(); cache.set(k, v); return v; }
  function toSimp(s) {
    s = String(s == null ? '' : s);
    if (!ready || !HAN.test(s)) return s;
    var k = 's|' + s, c = cache.get(k); if (c !== undefined) return c;
    return remember(k, conv('t2cn')(s));
  }
  function toTrad(s, v) {
    s = String(s == null ? '' : s);
    if (!ready || !HAN.test(s)) return s;
    var to = VARMAP[v || variant] || 't';
    var k = to + '|' + s, c = cache.get(k); if (c !== undefined) return c;
    return remember(k, conv('cn2t', to)(s));
  }

  // 简体字 -> 所有对应的繁体字（把每个汉字单独转一遍，反向收集）
  function revMap() {
    if (rev) return rev;
    rev = new Map();
    if (!ready) return rev;
    var f = conv('t2cn');
    for (var c = 0x4E00; c <= 0x9FFF; c++) {
      var ch = String.fromCharCode(c), sc = f(ch);
      if (sc !== ch && sc.length === 1) { var l = rev.get(sc); if (!l) rev.set(sc, l = []); l.push(ch); }
    }
    return rev;
  }

  // 一个词的所有可能写法：原样、简体、繁体（逐字展开 + 词组转换）
  function variants(tok) {
    var out = [tok];
    if (!ready || !HAN.test(tok)) return out;
    var S = toSimp(tok); out.push(S);
    var rm = revMap(), lists = Array.from(S).map(function (c) { return [c].concat(rm.get(c) || []); });
    var total = lists.reduce(function (a, l) { return a * l.length; }, 1);
    if (total > 1 && total <= 48) {
      var combos = [''];
      lists.forEach(function (l) { var next = []; combos.forEach(function (p) { l.forEach(function (c) { next.push(p + c); }); }); combos = next; });
      combos.forEach(function (x) { out.push(x); });
    }
    out.push(toTrad(S, 'std'), toTrad(S, 'tw'), toTrad(S, 'hk'));
    var s = {}, u = [];
    out.forEach(function (x) { if (x && !s[x]) { s[x] = 1; u.push(x); } });
    return u;
  }

  function getMode() { return mode; }
  function getVariant() { return variant; }
  function save() { try { localStorage.setItem('ps.conv', JSON.stringify({ mode: mode, variant: variant })); } catch (e) { /* ignore */ } }
  function restore() {
    try { var o = JSON.parse(localStorage.getItem('ps.conv') || 'null'); if (o) { mode = o.mode === 't' ? 't' : 's'; variant = VARMAP[o.variant] ? o.variant : 'std'; } } catch (e) { /* ignore */ }
  }
  function show(s) { return mode === 's' ? toSimp(s) : toTrad(s); }
  function onChange(fn) { listeners.push(fn); }
  function setMode(m, v) {
    var nm = m === 't' ? 't' : 's', nv = v && VARMAP[v] ? v : variant;
    if (nm === mode && nv === variant) return;
    mode = nm; variant = nv; save();
    if (typeof document !== 'undefined') applyAll();
    listeners.forEach(function (f) { try { f(mode, variant); } catch (e) { /* ignore */ } });
  }
  function toggle() { setMode(mode === 's' ? 't' : 's'); return mode; }

  var texts = (typeof WeakMap !== 'undefined') ? new WeakMap() : null;
  var attrs = (typeof WeakMap !== 'undefined') ? new WeakMap() : null;
  var busy = false, observer = null, pending = [], timer = 0;
  var ATTRS = ['placeholder', 'title', 'aria-label'];

  function skip(node) {
    for (var p = node.parentNode; p && p.nodeType === 1; p = p.parentNode) {
      var t = p.nodeName;
      if (t === 'SCRIPT' || t === 'STYLE' || t === 'TEXTAREA' || t === 'NOSCRIPT') return true;
      if (p.hasAttribute && p.hasAttribute('data-noconv')) return true;
    }
    return false;
  }
  function doText(node) {
    var v = node.nodeValue;
    if (!v || !HAN.test(v) || skip(node)) return;
    var rec = texts.get(node), orig = v;
    if (rec && rec.out === v) orig = rec.orig;
    var out = show(orig);
    texts.set(node, { orig: orig, out: out });
    if (out !== v) node.nodeValue = out;
  }
  function doAttrs(el) {
    if (!el.hasAttribute || el.hasAttribute('data-noconv')) return;
    var rec = attrs.get(el) || {}, changed = false;
    ATTRS.forEach(function (a) {
      if (!el.hasAttribute(a)) return;
      var v = el.getAttribute(a); if (!v || !HAN.test(v)) return;
      var r = rec[a], orig = r && r.out === v ? r.orig : v, out = show(orig);
      rec[a] = { orig: orig, out: out }; changed = true;
      if (out !== v) el.setAttribute(a, out);
    });
    if (changed) attrs.set(el, rec);
  }
  function apply(rootNode) {
    if (!ready || typeof document === 'undefined' || !rootNode) return;
    busy = true;
    try {
      if (rootNode.nodeType === 3) { doText(rootNode); return; }
      if (rootNode.nodeType !== 1 && rootNode.nodeType !== 9) return;
      var w = document.createTreeWalker(rootNode, 4), n;
      while ((n = w.nextNode())) doText(n);
      var els = rootNode.querySelectorAll ? rootNode.querySelectorAll('[placeholder],[title],[aria-label]') : [];
      for (var i = 0; i < els.length; i++) doAttrs(els[i]);
      if (rootNode.nodeType === 1) doAttrs(rootNode);
    } finally { busy = false; }
  }
  function applyAll() { apply(document.body); }
  function flush() { timer = 0; var list = pending; pending = []; list.forEach(function (n) { if (n.isConnected !== false) apply(n); }); }
  function watch() {
    if (observer || typeof MutationObserver === 'undefined') return;
    observer = new MutationObserver(function (muts) {
      if (busy) return;
      muts.forEach(function (m) { if (m.type === 'characterData') pending.push(m.target); else m.addedNodes.forEach(function (n) { pending.push(n); }); });
      if (!timer) timer = setTimeout(flush, 16);
    });
    observer.observe(document.body, { childList: true, subtree: true, characterData: true });
  }
  async function start() {
    restore();
    try { await load(); } catch (e) { return false; }
    applyAll(); watch();
    return true;
  }

  return {
    init: init, load: load, start: start, isReady: function () { return ready; },
    toSimp: toSimp, toTrad: toTrad, revMap: revMap, variants: variants,
    getMode: getMode, getVariant: getVariant, setMode: setMode, toggle: toggle, show: show, onChange: onChange,
    apply: apply, applyAll: applyAll
  };
});
