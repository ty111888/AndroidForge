/* settings.js — 设置（存在 localStorage）：各种可编辑列表、字体字号、选中的数据库等
 * 浏览器里挂在 window.PSSettings，Node 里可 require（没有 localStorage 时只在内存里）。 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory(root);
  else root.PSSettings = factory(root);
})(typeof self !== 'undefined' ? self : this, function (root) {
  'use strict';

  var KEY = 'ps.settings.v3', cache = null, listeners = [];

  function defaults() {
    return {
      v: 3,
      sites: [
        { name: '搜韵', url: 'https://www.sou-yun.cn/index.aspx' },
        { name: '识典古籍', url: 'https://www.shidianguji.com/' },
        { name: '汉典诗词', url: 'https://sc.zdic.net/' },
        { name: '中国哲学书电子化计划', url: 'https://ctext.org/pre-qin-and-han/zhs' },
        { name: '中华经典古籍库', url: 'https://jingdian.ancientbooks.cn/6' },
        { name: '汉籍全文资料库', url: 'https://hanchi.ihp.sinica.edu.tw/ihp/hanji.htm' },
        { name: '韵典网', url: 'https://ytenx.org/' },
        { name: '古诗文断句', url: 'https://seg.shenshen.wiki/' },
        { name: '古籍文本对勘', url: 'https://guji.xueheng.net/' },
        { name: 'AI太炎', url: 'https://t.shenshen.wiki/' }
      ],
      // 搜索引擎：url 里的 {q} 是关键字；id 对应内置的特殊处理（港台参数、简体转繁体等）
      engines: [
        { id: 'baidu', name: '百度', url: 'https://www.baidu.com/s?wd={q}' },
        { id: 'google', name: '谷歌', url: 'https://www.google.com/search?q={q}' },
        { id: 'bing', name: '必应', url: 'https://www.bing.com/search?q={q}' },
        { id: 'ddg', name: 'DuckDuckGo', url: 'https://duckduckgo.com/?q={q}' },
        { id: 'google-hk', name: '谷歌香港', url: 'https://www.google.com/search?q={q}' },
        { id: 'google-tw', name: '谷歌台湾', url: 'https://www.google.com/search?q={q}' },
        { id: 'yahoo-hk', name: 'Yahoo香港', url: 'https://hk.search.yahoo.com/search?p={q}' },
        { id: 'yahoo-tw', name: 'Yahoo台湾', url: 'https://tw.search.yahoo.com/search?p={q}' }
      ],
      engineLocal: 'prefer',        // 港台搜索本地化：normal 普通 / prefer 偏好本地 / strict 严格本地
      googleNoAI: true,             // 谷歌结果页去掉 AI 概览（udm=14）
      engineConv: true,             // 港台搜索时把关键字转成对应的繁体写法
      galleries: [
        { id: 'met', name: '大都会艺术博物馆', enabled: true },
        { id: 'aic', name: '芝加哥艺术博物馆', enabled: true },
        { id: 'cma', name: '克利夫兰艺术博物馆', enabled: true }
      ],
      aiSites: [
        { name: 'Pollinations（一键出图）', url: 'https://image.pollinations.ai/prompt/{prompt}?width=768&height=1152&nologo=true', mode: 'api' },
        { name: '即梦', url: 'https://jimeng.jianying.com/', mode: 'web' },
        { name: '通义万相', url: 'https://tongyi.aliyun.com/wanxiang/', mode: 'web' },
        { name: '文心一格', url: 'https://yige.baidu.com/', mode: 'web' }
      ],
      autoGallery: true,            // 打开诗时先从在线图库匹配背景
      autoAI: false,                // 图库全失败时，后台让 AI 出图
      fonts: {                      // 四处文字：font = default | system | file；size = s | m | l | xl
        title: { font: 'default', file: '', size: 'm' },
        home: { font: 'default', file: '', size: 'm' },
        results: { font: 'default', file: '', size: 'm' },
        poem: { font: 'default', file: '', size: 'm' }
      },
      homeBg: { type: 'ink', n: 0, url: '' },     // 首页背景：ink 自带水墨（n=第几张，0=按日子轮换）/ local 手机图片
      autoChange: { mode: 'none', folderUri: '', folderName: '', interval: 'open', list: [] },
      crystal: { url: '', name: '', mode: 'local', list: [] },   // 水晶球：url 当前图（空=本机原来的渐变）；mode: local 本机 / normal 正常 / beauty 美化；list 是加过的图片列表
      splash: { url: '', name: '', size: 0 },                    // 开屏：当前一个开屏文件（GIF / MP4 / MKV），换 = 替代
      dim: 0,                       // 诗页背景明暗（-50..50）
      selDb: ['wn:唐.csv'],         // 选中的数据库文件
      selCol: [],                   // 选中的文集
      scope: 'all',                 // 搜索范围：all content title author dynasty
      confirmMB: 60,                // 一次搜索要下载超过这么多 MB 就先问
      history: []
    };
  }

  function clone(o) { return JSON.parse(JSON.stringify(o)); }
  function merge(d, o) {
    var out = clone(d);
    Object.keys(o || {}).forEach(function (k) {
      var v = o[k];
      if (Array.isArray(v)) out[k] = v;
      else if (v && typeof v === 'object' && out[k] && typeof out[k] === 'object' && !Array.isArray(out[k])) {
        Object.keys(v).forEach(function (j) {
          var x = v[j];
          out[k][j] = (x && typeof x === 'object' && !Array.isArray(x) && out[k][j] && typeof out[k][j] === 'object') ? Object.assign({}, out[k][j], x) : x;
        });
      } else out[k] = v;
    });
    return out;
  }
  function storage() { try { return root.localStorage || null; } catch (e) { return null; } }
  function load() {
    if (cache) return cache;
    var d = defaults(), ls = storage(), o = null;
    try { o = ls ? JSON.parse(ls.getItem(KEY) || 'null') : null; } catch (e) { o = null; }
    cache = o ? merge(d, o) : d;
    return cache;
  }
  function save() { var ls = storage(); try { if (ls) ls.setItem(KEY, JSON.stringify(cache)); } catch (e) { /* ignore */ } }
  function fire(k) { listeners.forEach(function (f) { try { f(k); } catch (e) { /* ignore */ } }); }

  return {
    defaults: defaults, all: load,
    get: function (k) { return load()[k]; },
    set: function (k, v) { load()[k] = v; save(); fire(k); },
    update: function (k, fn) { var v = load()[k]; var r = fn(v); if (r !== undefined) v = r; load()[k] = v; save(); fire(k); },
    reset: function (k) { var d = defaults(); if (k) { load()[k] = d[k]; } else { cache = d; } save(); fire(k || '*'); },
    onChange: function (f) { listeners.push(f); },
    SIZES: { min: 0.7, s: 0.85, m: 1, l: 1.2, xl: 1.45, xxl: 1.9 },
    addHistory: function (q) {
      q = String(q || '').trim(); if (!q) return;
      var h = load().history.filter(function (x) { return x !== q; });
      h.unshift(q); load().history = h.slice(0, 60); save();
    }
  };
});
