/* crystal.js — 水晶球：设置里加图、选当前图、预览，三个按钮：美化 / 正常 / 本机。
 * 美化 = 缩放 + 浮雕感（高光、阴影）+ 提亮去灰 + 细边和软投影；正常 = 只缩放；本机 = 回到原来的渐变球。
 * 所有处理在网页里用 canvas 完成，不联网。浏览器里挂在 window.PSCrystal。 */
(function (root) {
  'use strict';
  var SIZE = 240;                 // 输出边长（按钮 46px，高分屏够用，也不大）

  function loadImg(url) {
    return new Promise(function (res, rej) {
      var im = new Image(); im.crossOrigin = 'anonymous';
      im.onload = function () { res(im); }; im.onerror = function () { rej(new Error('图片打不开')); };
      im.src = url;
    });
  }

  // 把图居中、等比缩进正方形画布（保留透明底）
  function fitSquare(im, size) {
    var c = document.createElement('canvas'); c.width = c.height = size;
    var g = c.getContext('2d');
    var s = Math.min(size / im.naturalWidth, size / im.naturalHeight);
    var w = im.naturalWidth * s, h = im.naturalHeight * s;
    g.drawImage(im, (size - w) / 2, (size - h) / 2, w, h);
    return c;
  }

  // 圆形遮罩：按钮是圆的，超出圆的部分去掉，边缘留一点余量
  function circleMask(c) {
    var g = c.getContext('2d'), r = c.width / 2;
    g.globalCompositeOperation = 'destination-in';
    g.beginPath(); g.arc(r, r, r - 2, 0, Math.PI * 2); g.fill();
    g.globalCompositeOperation = 'source-over';
    return c;
  }

  // 提亮去灰：略微提高亮度和饱和度，压一压发灰的部分
  function brightenDesaturate(c) {
    var g = c.getContext('2d'), d = g.getImageData(0, 0, c.width, c.height), p = d.data;
    for (var i = 0; i < p.length; i += 4) {
      if (p[i + 3] === 0) continue;
      var r = p[i], gg = p[i + 1], b = p[i + 2];
      var avg = (r + gg + b) / 3;
      r = avg + (r - avg) * 1.12; gg = avg + (gg - avg) * 1.12; b = avg + (b - avg) * 1.12;   // 饱和度稍增
      r += 10; gg += 10; b += 10;                                                             // 亮度稍增
      p[i] = Math.max(0, Math.min(255, r)); p[i + 1] = Math.max(0, Math.min(255, gg)); p[i + 2] = Math.max(0, Math.min(255, b));
    }
    g.putImageData(d, 0, 0);
    return c;
  }

  // 浮雕：左上高光、右下阴影，让球体有立体感
  function emboss(c) {
    var g = c.getContext('2d'), w = c.width, h = c.height, r = w / 2;
    var hl = g.createRadialGradient(r * 0.7, r * 0.6, r * 0.05, r * 0.7, r * 0.6, r * 1.1);
    hl.addColorStop(0, 'rgba(255,255,255,0.55)'); hl.addColorStop(1, 'rgba(255,255,255,0)');
    g.globalCompositeOperation = 'source-atop'; g.fillStyle = hl; g.fillRect(0, 0, w, h);
    var sh = g.createRadialGradient(r * 1.25, r * 1.35, r * 0.2, r * 1.1, r * 1.1, r * 1.3);
    sh.addColorStop(0, 'rgba(0,0,0,0)'); sh.addColorStop(1, 'rgba(0,0,0,0.38)');
    g.fillStyle = sh; g.fillRect(0, 0, w, h);
    g.globalCompositeOperation = 'source-over';
    return c;
  }

  // 细边 + 软投影：圆形边缘一圈很淡的高光边，底下一点软阴影，像浮在纸上
  function rimAndShadow(c) {
    var w = c.width, r = w / 2;
    var out = document.createElement('canvas'); out.width = out.height = w + 16;
    var g = out.getContext('2d');
    g.shadowColor = 'rgba(40,30,15,0.35)'; g.shadowBlur = 10; g.shadowOffsetY = 4;
    g.drawImage(c, 8, 8);
    g.shadowColor = 'transparent';
    g.beginPath(); g.arc(r + 8, r + 8, r - 1, 0, Math.PI * 2);
    g.strokeStyle = 'rgba(255,255,255,0.55)'; g.lineWidth = 1.5; g.stroke();
    return out;
  }

  // 三个按钮对应的处理
  async function render(url, mode) {
    if (mode === 'local') return null;                     // 本机：用原来的渐变，不用图
    var im = await loadImg(root.PSNative ? root.PSNative.toPageUrl(url) : url);
    var c = fitSquare(im, SIZE);                           // 所有模式都先缩放到水晶球大小
    if (mode === 'normal') return c.toDataURL('image/png');   // 正常：只缩放，不做圆形裁切、不做美化
    // 美化：缩放 + 提亮去灰 + 浮雕 + 圆形 + 细边和软投影
    brightenDesaturate(c); emboss(c); circleMask(c);
    return rimAndShadow(c).toDataURL('image/png');
  }

  // 把结果应用到三个水晶球上（本机 = 清掉自定义图，回到原来的渐变）
  function apply(dataUrl) {
    var els = [document.getElementById('btnSet'), document.getElementById('leftOrb'), document.getElementById('pOrb')];
    els.forEach(function (e) {
      if (!e) return;
      if (dataUrl) { e.style.background = 'url("' + dataUrl + '") center / contain no-repeat'; e.style.boxShadow = 'none'; }
      else { e.style.background = ''; e.style.boxShadow = ''; }
    });
  }

  async function applyCurrent() {
    var c = root.PSSettings.get('crystal') || {};
    // 本机 / 没选图：不动固定的绿球和白球，保留它们
    if (!c.url || c.mode === 'local') { return; }
    try { apply(await render(c.url, c.mode)); }
    catch (e) {
      // 不再悄悄吞掉：提示原因。固定的绿球和白球保留，不清掉
      if (root.PSUI && root.PSUI.toast) root.PSUI.toast('水晶球换不上：' + (e && e.message ? e.message : '图片处理失败') + '。已回到本机的。');
      try { console.warn('crystal:', e); } catch (_) {}
    }
  }

  // 固定的两张球（Derek 指定）：首页两个用绿色球，诗页用白色球。不随设置变，设置里的水晶球选图另算。
  function setBall(el, file) {
    if (!el) return;
    el.style.background = 'url("img/' + file + '") center / contain no-repeat';
    el.style.boxShadow = 'none';
  }
  function applyFixed() {
    setBall(document.getElementById('btnSet'), 'ball-green.png');
    setBall(document.getElementById('leftOrb'), 'ball-green.png');
  }
  function applyPoem() {
    setBall(document.getElementById('pOrb'), 'ball-white.png');
  }

  root.PSCrystal = { render: render, apply: apply, applyCurrent: applyCurrent, applyFixed: applyFixed, applyPoem: applyPoem, SIZE: SIZE };
})(window);
