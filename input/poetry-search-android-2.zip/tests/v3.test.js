// 第三版核心逻辑测试：搜索规则、简繁展开、数据库清单、搜索调度
const assert = require('assert');
const A = '../app/src/main/assets/';
const Core = require(A + 'js/core.js');
const Conv = require(A + 'js/convert.js');
const Sources = require(A + 'js/sources.js');
const Search = require(A + 'js/search.js');
Conv.init({ t2cn: require(A + 'vendor/opencc/t2cn.js'), cn2t: require(A + 'vendor/opencc/cn2t.js') });

let pass = 0, fail = 0;
async function t(name, fn) {
  try { await fn(); pass++; console.log('  ok   ' + name); }
  catch (e) { fail++; console.log('  FAIL ' + name + '\n       ' + (e && e.stack || e).split('\n').slice(0, 4).join('\n       ')); }
}
const P = (q) => Core.parseQuery(q);
const T = (q, vf) => Core.buildTerms(P(q), vf);
const M = (content, q, vf) => Core.matchContent(content, P(q), T(q, vf), 6);

(async () => {
  console.log('搜索框怎么理解');
  await t('紧挨着 = 一个词', () => { const p = P('云月'); assert.equal(p.mode, 'plain'); assert.deepEqual(p.tokens, ['云月']); });
  await t('一个空格 = 同一句', () => { const p = P('云 月'); assert.equal(p.mode, 'same'); assert.deepEqual(p.groups, [['云', '月']]); });
  await t('全角空格也算一个空格', () => assert.equal(P('云　月').mode, 'same'));
  await t('两个空格 = 相邻句；再多也只是下一句', () => { assert.equal(P('云  月').mode, 'adj'); assert.deepEqual(P('云     月').groups, [['云'], ['月']]); });
  await t('半角加全角空格 = 两个', () => assert.equal(P('云 　月').mode, 'adj'));
  await t('任意标点（中英文）= 下一句', () => { ['云，月', '云,月', '云/月', '云。月', '云-月', '云；月', '云·月', '云！月', '云~月'].forEach(q => assert.equal(P(q).mode, 'adj', q)); });
  await t('标点两边的空格不改变意思', () => assert.deepEqual(P('云 ， 月').groups, [['云'], ['月']]));
  await t('可以连用：云 月，风', () => assert.deepEqual(P('云 月，风').groups, [['云', '月'], ['风']]));
  await t('开头结尾的间隔忽略', () => { assert.equal(P('  云 ').mode, 'plain'); assert.equal(P('云，').mode, 'plain'); assert.equal(P('').mode, 'empty'); assert.equal(P('，，').mode, 'empty'); });
  await t('词可以是任意长度', () => assert.deepEqual(P('云月 风雨').groups, [['云月', '风雨']]));
  await t('识别提示', () => { assert.equal(Core.describe(P('云月')), ''); assert.ok(Core.describe(P('云 月')).startsWith('同一句')); assert.ok(Core.describe(P('云，月')).startsWith('相邻两句')); });

  console.log('内容匹配');
  const poem = '白云生远岫，明月照高楼。清风徐来，水波不兴。';
  await t('同一句：云 岫 命中，标出词的位置', () => { const h = M(poem, '云 岫'); assert.equal(h.length, 1); assert.equal(h[0].lines[0].t, '白云生远岫'); assert.deepEqual(h[0].lines[0].m, [[1, 2], [4, 5]]); });
  await t('同一句：云 月 不在同一句 → 没有', () => assert.equal(M(poem, '云 月').length, 0));
  await t('相邻句：云，月 命中，上下两句并排', () => { const h = M(poem, '云，月'); assert.equal(h.length, 1); assert.deepEqual(h[0].lines.map(l => l.t), ['白云生远岫', '明月照高楼']); });
  await t('相邻句：顺序不限；两个空格一样；隔一句不算', () => { assert.equal(M(poem, '月，云').length, 1); assert.equal(M(poem, '云  月').length, 1); assert.equal(M(poem, '云，风').length, 0); });
  await t('连用、三句连着', () => { assert.equal(M(poem, '云 岫，月').length, 1); assert.equal(M(poem, '云，月，风').length, 1); });
  await t('词组：云月 没有；明月 照 同一句', () => { assert.equal(M(poem, '云月').length, 0); assert.equal(M(poem, '明月 照').length, 1); });
  await t('单个词：显示所在一句 + 一句相邻句', () => { const h = M(poem, '清风'); assert.equal(h[0].lines[0].t, '清风徐来'); assert.equal(h[0].nb.t, '水波不兴'); });
  await t('超过 14 字：只显示 14 字窗口', () => { const h = M('一二三四五六七八九十甲乙丙丁戊己庚辛壬癸云，其他', '云'); const l = h[0].lines[0]; assert.equal(l.t.length, 14); assert.ok(l.t.includes('云')); assert.equal(l.l, true); });
  await t('超过 14 字且隔得太远 → 不算；够近 → 算', () => { assert.equal(M('云一二三四五六七八九十甲乙丙丁戊月，其他', '云 月').length, 0); assert.equal(M('一二三四五六七八云月丙丁戊己庚辛壬癸，其他', '云 月').length, 1); });

  console.log('字段、范围');
  const rec = { title: '静夜思', author: '李白', dynasty: '唐', content: poem };
  const run = (q, scope) => Core.matchPoem(rec, P(q), T(q), scope);
  await t('诗题、诗人（空格 = 都包含）、朝代', () => { assert.equal(run('静夜', 'title').kind, 'title'); assert.ok(run('李 白', 'author')); assert.equal(run('李 杜', 'author'), null); assert.equal(run('唐', 'dynasty').kind, 'dynasty'); });
  await t('全部：内容优先；只搜内容时诗题里的词不算', () => { assert.equal(run('云', 'all').kind, 'content'); assert.equal(run('李白', 'all').kind, 'author'); assert.equal(run('静夜', 'content'), null); });

  console.log('简繁');
  const vf = Conv.variants;
  await t('简体词搜繁体句、繁体词搜简体句、后↔後', () => {
    assert.equal(M('此地乾淨，明月在天', '干净', vf).length, 1); assert.equal(M('此地干净，明月在天', '乾淨', vf).length, 1);
    assert.equal(M('日後相逢', '后', vf).length, 1); assert.equal(M('皇后临朝', '後', vf).length, 1); assert.equal(M('白雲生遠岫，明月照高樓。', '云，月', vf).length, 1);
  });
  await t('显示转换', () => { Conv.setMode('s'); assert.equal(Conv.show('乾淨後面'), '干净后面'); Conv.setMode('t'); assert.equal(Conv.show('干净后面'), '乾淨後面'); Conv.setMode('s'); });

  console.log('数据库清单');
  const tree = Sources.build(require('../app/src/main/assets/data/datasets-manifest.json'));
  await t('五个库；不收作者、介绍、数据库文件、压缩包', () => {
    assert.deepEqual(tree.map(n => n.id), ['repo:cp', 'repo:wn', 'repo:cv', 'repo:yg', 'repo:vm']);
    assert.equal(Sources.allFiles().filter(f => /authors?\.|intro\.|\.db$|\.z01|\.zip|\.npy/i.test(f.name)).length, 0);
  });
  await t('Werneror 34 个 CSV；VMIJUNV 只收"部分诗词数据"；默认文件存在', () => { assert.equal(tree[1].count, 34); assert.ok(tree[4].files.every(f => f.path.startsWith('部分诗词数据/'))); assert.ok(Sources.getFile('wn:唐.csv')); });
  await t('超过 20MB 的文件优先走 raw；其余走 jsDelivr；中文会编码', () => {
    const big = Sources.allFiles().filter(f => f.size > Sources.MIB20); assert.ok(big.length >= 4);
    big.forEach(f => assert.ok(Sources.urls(f)[0].startsWith('https://raw.githubusercontent.com/'), f.id));
    const u = Sources.urls(Sources.getFile('wn:唐.csv'))[0]; assert.ok(u.startsWith('https://cdn.jsdelivr.net/gh/Werneror/Poetry@master/') && u.includes(encodeURIComponent('唐')));
  });
  await t('朝代、书名', () => { assert.deepEqual(Sources.guess('cp', '全唐诗/poet.song.12.json'), { dynasty: '宋', book: '全宋诗' }); assert.deepEqual(Sources.guess('yg', '宋词/data2.json'), { dynasty: '宋', book: '全宋诗' }); });

  console.log('搜索调度');
  const csvA = Buffer.from('题目,朝代,作者,内容\n静夜思,唐,李白,"床前明月光，疑是地上霜。\n举头望明月，低头思故乡。"\n春晓,唐,孟浩然,"春眠不觉晓，处处闻啼鸟。"\n', 'utf-8');
  const jsonB = Buffer.from(JSON.stringify([{ title: '静夜思', author: '李白', paragraphs: ['牀前看月光，疑是地上霜。', '舉頭望山月，低頭思故鄉。'] }]), 'utf-8');
  const ab = (b) => b.buffer.slice(b.byteOffset, b.byteOffset + b.byteLength);
  const fakeFetch = async (url) => { const b = /\.csv/.test(decodeURIComponent(url)) ? csvA : jsonB; return { ok: true, body: null, arrayBuffer: async () => ab(b) }; };
  const fA = { id: 'x:a.csv', repo: 'o/r', branch: 'master', path: 'a.csv', name: 'a.csv', size: csvA.length, kind: 'csv', dynasty: '唐', book: '', label: '甲库 · a.csv' };
  const fB = { id: 'y:b.json', repo: 'o/r', branch: 'master', path: 'b.json', name: 'b.json', size: jsonB.length, kind: 'json', dynasty: '唐', book: '全唐诗', label: '乙库 · b.json' };
  const go = async (o) => { const got = []; const r = await Search.run(Object.assign({ scope: 'content', variantFn: vf, fetch: fakeFetch, onHits: (b) => got.push(...b) }, o)); return { got, r }; };
  await t('两个库同名诗都保留，不去重，并标明来源', async () => { const { got, r } = await go({ query: '思 故乡', files: [fA, fB] }); assert.equal(r.total, 2); assert.deepEqual(got.map(x => x.srcLabel).sort(), ['乙库 · b.json', '甲库 · a.csv']); });
  await t('简体搜繁体库；相邻句搜索', async () => { assert.equal((await go({ query: '故乡', files: [fB] })).got.length, 1); const { got } = await go({ query: '明月，故乡', files: [fA] }); assert.equal(got.length, 1); assert.equal(got[0].hits[0].lines.length, 2); });
  await t('已下载的文件优先用本地，不联网', async () => {
    let net = 0; const store = { getFileData: async (k) => (k === fA.id ? ab(csvA) : null) };
    const { got } = await go({ query: '春眠', files: [fA], store, fetch: async () => { net++; throw new Error('不该联网'); } }); assert.equal(got.length, 1); assert.equal(net, 0);
  });
  await t('导入的文集一起搜', async () => {
    const store = { getFileData: async () => null, getChunk: async (id, no) => (no === 0 ? [{ title: '自编', author: '我', dynasty: '', book: '我的集', content: '云深不知处，月落乌啼霜。' }] : []) };
    const { got } = await go({ query: '云，月', files: [], datasets: [{ id: 'd1', name: '我的集', chunks: 1 }], store }); assert.equal(got.length, 1); assert.equal(got[0].srcLabel, '我的集');
  });
  await t('一个库失败不影响其他库；会先试第一个网址再试备用网址', async () => {
    const f = async (url) => { if (/b\.json/.test(url)) throw new Error('boom'); return fakeFetch(url); };
    const { got, r } = await go({ query: '思', files: [fA, fB], fetch: f }); assert.equal(got.length, 1); assert.equal(r.errors.length, 1);
    const seen = []; const f2 = async (url) => { seen.push(url); if (seen.length === 1) throw new Error('挂了'); return fakeFetch(url); };
    const x = await go({ query: '春眠', files: [fA], fetch: f2 }); assert.equal(x.got.length, 1); assert.ok(/jsdelivr/.test(seen[0]) && /raw\.githubusercontent/.test(seen[1]));
  });
  await t('可以取消；命中多于旧的 400 上限也都保留', async () => {
    const r1 = await Search.run({ query: '思', scope: 'content', files: [fA], fetch: fakeFetch, signal: { aborted: true } }); assert.equal(r1.total, 0); assert.equal(r1.cancelled, true);
    const rows = ['题目,朝代,作者,内容']; for (let i = 0; i < 1500; i++) rows.push('诗' + i + ',唐,某,"云在青天水在瓶。"');
    const b = Buffer.from(rows.join('\n'), 'utf-8');
    const { got } = await go({ query: '云', files: [fA], fetch: async () => ({ ok: true, body: null, arrayBuffer: async () => ab(b) }) }); assert.equal(got.length, 1500);
  });
  await t('下载量估算：已下载的不算', () => assert.equal(Search.estimate([{ id: 'a', size: 10 }, { id: 'b', size: 5 }], ['a']), 5));

  console.log('\n' + pass + ' 通过，' + fail + ' 失败');
  process.exit(fail ? 1 : 0);
})();
