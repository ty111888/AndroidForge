const { chromium } = require('playwright');
const { serve, mock } = require('./helpers3');
(async () => {
  const srv = await serve(); const base = 'http://127.0.0.1:' + srv.address().port + '/index.html';
  const browser = await chromium.launch(); const page = await (await browser.newContext({ viewport: { width: 390, height: 844 }, hasTouch: true, isMobile: true })).newPage(); page.setDefaultTimeout(3000);
  const errs = []; page.on('pageerror', (e) => errs.push(e.message));
  await mock(page); await page.goto(base); await page.waitForTimeout(800);
  const wait = (ms) => new Promise((r) => setTimeout(r, ms));
  await page.setInputFiles('#fileIn', { name: '我的诗.csv', mimeType: 'text/csv', buffer: Buffer.from('题目,作者,朝代,内容\n夜坐,某某,清,"灯下读书声，窗前明月影。"\n晨起,某某,清,"鸟鸣山更幽。"\n', 'utf-8') });
  await wait(800);
  console.log('sheet title:', await page.textContent('#sheetTitle'));
  console.log('sheet buttons:', await page.$$eval('#sheetBody button', (b) => b.map((x) => x.textContent.trim())));
  console.log('sheet text:', (await page.textContent('#sheetBody')).replace(/\s+/g, ' ').slice(0, 300));
  console.log('errors', errs);
  await browser.close(); srv.close();
})();
