const fs = require('fs');
const path = require('path');
const http = require('http');
const ASSETS = path.join(__dirname, '..', 'app', 'src', 'main', 'assets');
const SHOTS = '/tmp/shots3';
fs.mkdirSync(SHOTS, { recursive: true });
const JPG = fs.readFileSync(path.join(__dirname, 'fixtures', 'mock.jpg'));
const CORS = { 'access-control-allow-origin': '*' };
const TYPES = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.jpg': 'image/jpeg', '.webp': 'image/webp', '.json': 'application/json', '.wasm': 'application/wasm' };

function serve() {
  return new Promise((res) => {
    const srv = http.createServer((req, rsp) => {
      let p = decodeURIComponent(req.url.split('?')[0]); if (p === '/') p = '/index.html';
      const f = path.join(ASSETS, p);
      if (!f.startsWith(ASSETS) || !fs.existsSync(f) || fs.statSync(f).isDirectory()) { rsp.writeHead(404); rsp.end('nf'); return; }
      rsp.writeHead(200, { 'content-type': TYPES[path.extname(f)] || 'application/octet-stream' });
      rsp.end(fs.readFileSync(f));
    }).listen(0, '127.0.0.1', () => res(srv));
  });
}

const netLog = [];
const WN_TANG = '题目,朝代,作者,内容\r\n' +
  '静夜思,唐,李白,"床前明月光，疑是地上霜。\n举头望明月，低头思故乡。"\r\n' +
  '山居,唐,某人,"云开见月明，山色空蒙雨亦奇。"\r\n' +
  '春晓,唐,孟浩然,"春眠不觉晓，处处闻啼鸟。\n夜来风雨声，花落知多少。"\r\n' +
  '登高,唐,杜甫,"风急天高猿啸哀，渚清沙白鸟飞回。"\r\n';
const WN_SONG1 = '题目,朝代,作者,内容\r\n水调歌头,宋,苏轼,"明月几时有，把酒问青天。\n不知天上宫阙，今夕是何年。"\r\n';
const CP_TANG0 = [{ title: '靜夜思', author: '李白', paragraphs: ['牀前看月光，疑是地上霜。', '舉頭望山月，低頭思故鄉。'] }, { title: '山居', author: '某人', paragraphs: ['雲開見月明，山色空濛雨亦奇。'] }];
async function mock(page) {
  await page.route('**/*', async (route) => {
    const url = route.request().url();
    if (url.startsWith('http://127.0.0.1')) return route.continue();
    netLog.push(url);
    const dec = decodeURIComponent(url);
    const json = (o, st) => route.fulfill({ status: st || 200, headers: Object.assign({ 'content-type': 'application/json' }, CORS), body: JSON.stringify(o) });
    const text = (t, ct) => route.fulfill({ status: 200, headers: Object.assign({ 'content-type': ct || 'text/plain; charset=utf-8' }, CORS), body: t });
    let m;
    if ((m = dec.match(/(?:jsdelivr\.net\/gh|raw\.githubusercontent\.com)\/Werneror\/Poetry[@/]master\/(.+)$/))) {
      const f = m[1].replace(/^master\//, '');
      if (f === '唐.csv') return text(WN_TANG, 'text/csv; charset=utf-8');
      if (f === '宋_1.csv') return text(WN_SONG1, 'text/csv; charset=utf-8');
      return text('题目,朝代,作者,内容\r\n', 'text/csv; charset=utf-8');
    }
    if (/chinese-poetry\/chinese-poetry[@/]master\/全唐诗\/poet\.tang\.0\.json$/.test(dec)) return json(CP_TANG0);
    if (/\/(chinese-poetry|llm-dataset-chinese-poetry|Poetry)[@/]/.test(dec)) return json([]);
    if (dec.includes('collectionapi.metmuseum.org') && dec.includes('/search')) return json({ total: 2, objectIDs: [101, 102] });
    if ((m = dec.match(/collectionapi\.metmuseum\.org\/public\/collection\/v1\/objects\/(\d+)/))) return json({ objectID: Number(m[1]), isPublicDomain: true, primaryImageSmall: 'https://images.metmuseum.org/x' + m[1] + '.jpg', title: '山水图' + m[1], artistDisplayName: '某画家', culture: 'China', classification: 'Paintings', objectName: 'Hanging scroll', objectURL: 'https://www.metmuseum.org/art/collection/search/' + m[1] });
    if (dec.includes('api.artic.edu/api/v1/artworks/search')) return json({ config: { iiif_url: 'https://www.artic.edu/iiif/2' }, data: [{ id: 7, title: 'Landscape', artist_display: 'Anon', image_id: 'abc', place_of_origin: 'China' }] });
    if (dec.includes('openaccess-api.clevelandart.org')) return json({ data: [{ id: 9, title: 'Moon', creators: [{ description: 'X (Chinese)' }], images: { web: { url: 'https://openaccess-cdn.clevelandart.org/9.jpg' } }, url: 'https://clevelandart.org/9' }] });
    if (/images\.metmuseum\.org|artic\.edu\/iiif|openaccess-cdn/.test(dec)) return route.fulfill({ status: 200, headers: Object.assign({ 'content-type': 'image/jpeg' }, CORS), body: JPG });
    return route.fulfill({ status: 404, body: 'mock 404' });
  });
}
module.exports = { serve, mock, netLog, ASSETS, SHOTS, JPG, CORS };
