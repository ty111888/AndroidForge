// 第三版界面端到端测试：手机尺寸的无头 Chromium，网络用模拟数据（见 helpers3.js）
const assert = require('assert');
const { chromium } = require('playwright');
const { serve, mock, netLog, SHOTS } = require('./helpers3');

let pass = 0, fail = 0; const errs = [];
async function t(name, fn) {
  try { await fn(); pass++; console.log('  ok   ' + name); }
  catch (e) { fail++; console.log('  FAIL ' + name + '\n       ' + String(e && e.message || e).split('\n').slice(0, 4).join('\n       ')); }
}
const wait = (ms) => new Promise((r) => setTimeout(r, ms));
const TOP = '#layers > .page-layer:last-child';

(async () => {
  const srv = await serve(); const base = 'http://127.0.0.1:' + srv.address().port + '/index.html';
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true, locale: 'zh-CN' });
  const page = await ctx.newPage(); page.setDefaultTimeout(4000);
  page.on('pageerror', (e) => errs.push('pageerror: ' + e.message));
  page.on('console', (m) => { if (m.type() === 'error' && !/mock 404|Failed to load resource/.test(m.text())) errs.push('console: ' + m.text()); });
  await page.addInitScript(() => { window.__opened = []; window.open = (u) => { window.__opened.push(u); return null; }; });
  await mock(page); await page.goto(base); await page.waitForSelector('#titleV'); await wait(800);

  const resetUI = async () => { for (let i = 0; i < 12; i++) { const d = await page.evaluate(() => PSUI.depth()); if (!d) break; await page.evaluate(() => history.back()); await wait(140); } };
  const search = async (q, scope) => {
    await resetUI();
    await page.selectOption('#scope', scope || 'all'); await page.fill('#q', q);
    await page.evaluate(() => { document.getElementById('status').textContent = ''; });
    await page.click('#go');
    await page.waitForSelector('#resultsView:not(.hidden)');
    await page.waitForFunction(() => /共找到|已停止/.test(document.getElementById('status').textContent), null, { timeout: 8000 });
  };
  const cards = () => page.$$eval('.card', (c) => c.map((x) => x.innerText.replace(/\s+/g, ' ')));
  const openNav = async (act) => { await page.click('#leftNav button[data-act=' + act + ']'); await wait(300); };
  const back = async () => { await page.evaluate(() => history.back()); await wait(250); };
  const rowByText = async (sel, text) => { for (const r of await page.$$(sel)) { if ((await r.textContent()).includes(text)) return r; } return null; };

  console.log('首页');
  await t('竖排的"搜诗"、左侧六个按钮、右上角 简 和 设置', async () => {
    assert.equal((await page.textContent('#titleV')).trim(), '搜诗');
    assert.deepEqual(await page.$$eval('#leftNav button', (b) => b.map((x) => x.textContent)), ['数据库', '文集', '诗词网站', '搜索引擎', '收藏', '换背景']);
    assert.equal(await page.textContent('#btnConv'), '简');
    assert.ok(/vertical/.test(await page.$eval('#titleV', (e) => getComputedStyle(e).writingMode)));
    const r1 = await page.$eval('#btnConv', (e) => e.getBoundingClientRect().left), r2 = await page.$eval('#btnSet', (e) => e.getBoundingClientRect().left);
    assert.ok(r1 < r2, '简繁在设置的左边');
    const nav = await page.$eval('#leftNav', (e) => e.getBoundingClientRect()); assert.ok(nav.left < 30 && nav.width < 140);
  });
  await t('搜索框下拉：全部、内容、诗题、诗人、朝代', async () => { assert.deepEqual(await page.$$eval('#scope option', (o) => o.map((x) => x.textContent)), ['全部', '内容', '诗题', '诗人', '朝代']); });
  await t('页面铺满整个屏幕，用了安全区（刘海）', async () => {
    const m = await page.evaluate(() => ({ vp: document.querySelector('meta[name=viewport]').content, css: [...document.styleSheets].map((s) => [...s.cssRules].map((r) => r.cssText).join('')).join('').includes('safe-area-inset-top') }));
    assert.ok(/viewport-fit=cover/.test(m.vp)); assert.ok(m.css);
  });
  await t('搜索框下面显示"同一句／相邻两句"的识别提示', async () => {
    await page.fill('#q', '云 月'); assert.ok((await page.textContent('#hint')).startsWith('同一句'));
    await page.fill('#q', '云，月'); assert.ok((await page.textContent('#hint')).startsWith('相邻两句'));
    await page.fill('#q', '云  月'); assert.ok((await page.textContent('#hint')).startsWith('相邻两句'));
    await page.fill('#q', '云月'); assert.equal((await page.textContent('#hint')).trim(), '');
  });

  console.log('搜索');
  await t('默认选中的库在线搜索，结果标明来源，搜完不保存到手机', async () => {
    netLog.length = 0; await search('明月');
    const c = await cards(); assert.equal(c.length, 1); assert.ok(/静夜思/.test(c[0]) && /Werneror/.test(c[0]) && /明月/.test(c[0]));
    assert.ok(netLog.some((u) => /jsdelivr/.test(u)));
    assert.equal(await page.evaluate(async () => (await PSStore.listFiles()).length), 0);
  });
  await t('相邻句：明月，故乡（标点）和 明月  故乡（两个空格）都能搜到', async () => {
    await search('明月，故乡'); assert.equal((await cards()).length, 1);
    await search('明月  故乡'); const c = await cards(); assert.equal(c.length, 1); assert.ok(/举头望明月/.test(c[0]) && /低头思故乡/.test(c[0]));
  });
  await t('同一句：床前 明月 能搜到；明月 故乡（不在同一句）没有', async () => { await search('床前 明月'); assert.equal((await cards()).length, 1); await search('明月 故乡'); assert.equal((await cards()).length, 0); });
  await t('范围：诗题、诗人、朝代', async () => {
    await search('静夜', 'title'); assert.equal((await cards()).length, 1);
    await search('李白', 'author'); assert.equal((await cards()).length, 1);
    await search('唐', 'dynasty'); assert.equal((await cards()).length, 4);
    await search('静夜', 'content'); assert.equal((await cards()).length, 0);
  });
  await t('安卓返回键：结果 → 首页', async () => { await search('明月'); assert.ok(await page.$('#resultsView:not(.hidden)')); await back(); assert.ok(await page.$('#resultsView.hidden')); assert.ok(await page.$('#app.landing')); });
  await t('不选任何库就搜：提示先选库', async () => {
    await resetUI(); await page.evaluate(() => PSSettings.set('selDb', [])); await page.fill('#q', '明月'); await page.click('#go'); await wait(400);
    assert.ok(await page.$('.page-layer')); await resetUI(); await page.evaluate(() => PSSettings.set('selDb', ['wn:唐.csv']));
  });

  console.log('数据库与文集');
  await resetUI();
  await t('点数据库：顶部有"全部"，五个库', async () => {
    await openNav('db'); assert.ok((await page.textContent('.tr.top')).includes('全部'));
    const repos = await page.$$eval('.tr:not(.d1):not(.d2):not(.top) .n', (n) => n.map((x) => x.textContent)); assert.equal(repos.length, 5, repos.join('|'));
  });
  await t('展开 Werneror，能看到文件夹和 34 个文件', async () => {
    await (await rowByText('.tr', 'Werneror')).click(); await wait(150);
    const dir = await page.$('.tr.d1'); assert.ok(dir); assert.ok((await dir.textContent()).includes('34 个文件'));
    await page.click('.tr.d1 .arrow'); await wait(200); assert.equal((await page.$$('.tr.d2')).length, 34);
  });
  await t('选择先暂存，点"完成"才生效；返回键放弃', async () => {
    const before = await page.evaluate(() => PSSettings.get('selDb').join());
    await page.click('.tr.d1 .cb'); await wait(100); await back();
    assert.equal(await page.evaluate(() => PSSettings.get('selDb').join()), before, '返回 = 放弃');
    await openNav('db'); await page.click('.tr.top .cb'); await page.click(TOP + ' .page-act'); await wait(300);
    const n = await page.evaluate(() => PSSettings.get('selDb').length); assert.ok(n > 1000, '完成后全部选中：' + n);
    await page.evaluate(() => PSSettings.set('selDb', ['wn:唐.csv']));
  });
  await t('同名的全宋诗来自不同库，都保留并标明来源', async () => {
    await page.evaluate(() => PSSettings.set('selDb', ['wn:唐.csv', 'cp:全唐诗/poet.tang.0.json']));
    await search('静夜思', 'title'); const c = await cards(); assert.equal(c.length, 2, c.join('\n'));
    assert.ok(c.some((x) => /Werneror/.test(x)) && c.some((x) => /原始库/.test(x)));
  });
  await t('简体搜繁体库：故乡 搜到 故鄉', async () => { await search('故乡', 'content'); assert.equal((await cards()).length, 2); });
  await t('下载到手机：点 ⬇ 后存进手机，再搜不联网', async () => {
    await page.evaluate(() => PSSettings.set('selDb', ['wn:唐.csv']));
    await resetUI(); await openNav('db');
    await (await rowByText('.tr', 'Werneror')).click(); await wait(150);
    await page.click('.tr.d1 .arrow'); await wait(200);
    let btn = null; for (const r of await page.$$('.tr.d2')) { if ((await r.textContent()).startsWith('唐.csv')) { btn = await r.$('.dl'); break; } }
    assert.ok(btn); await btn.click(); await wait(600);
    assert.ok((await btn.textContent()).includes('已下载'), await btn.textContent());
    assert.equal(await page.evaluate(async () => (await PSStore.listFiles()).length), 1);
    await resetUI(); netLog.length = 0; await search('明月'); assert.equal((await cards()).length, 1);
    assert.equal(netLog.filter((u) => /jsdelivr|raw\.github/.test(u)).length, 0, '没有联网');
    await page.evaluate(() => PSStore.clearFiles());
  });
  await t('本地导入 CSV：进入文集、自动勾选、能搜到', async () => {
    await resetUI();
    await page.setInputFiles('#fileIn', { name: '我的诗.csv', mimeType: 'text/csv', buffer: Buffer.from('题目,作者,朝代,内容\n夜坐,某某,清,"灯下读书声，窗前明月影。"\n晨起,某某,清,"鸟鸣山更幽。"\n', 'utf-8') });
    await wait(700); assert.ok((await page.textContent('#sheetTitle')).includes('导入'));
    await page.click('#sheetBody button'); await wait(1500);
    await resetUI(); assert.equal(await page.evaluate(() => PSSettings.get('selCol').length), 1, '导入后自动勾选');
    await openNav('col'); assert.ok((await page.textContent(TOP + ' .page-body')).includes('我的诗')); await back();
    await search('明月', 'content'); const c = await cards(); assert.ok(c.some((x) => /夜坐/.test(x)), c.join('|'));
    await resetUI(); await page.evaluate(async () => { for (const d of await PSStore.getDatasets()) await PSStore.deleteDataset(d.id); PSSettings.set('selCol', []); });
  });
  await t('点文集：没有导入时有提示，顶部有"全部"', async () => {
    await resetUI(); await openNav('col'); assert.ok((await page.textContent('.tr.top')).includes('全部')); assert.ok((await page.textContent(TOP + ' .page-body')).includes('导入')); await back();
  });

  console.log('简繁按钮');
  await resetUI();
  await t('点一下：全文变繁体，按钮变"繁"；再点：变回，按钮变"简"', async () => {
    await search('明月'); assert.ok(/静夜思/.test((await cards())[0]));
    await page.click('#btnConv'); await wait(300); assert.equal(await page.textContent('#btnConv'), '繁');
    const c = await cards(); assert.ok(/靜夜思/.test(c[0]) && /舉頭望明月/.test(c[0]), c[0]);
    assert.ok((await page.textContent('#btnHome')).includes('首頁'), '界面文字也变繁体');
    await page.click('#btnConv'); await wait(300); assert.equal(await page.textContent('#btnConv'), '简'); assert.ok(/静夜思/.test((await cards())[0]));
  });
  await t('繁体显示时用简体搜，照样搜得到；状态记在手机里', async () => {
    await page.click('#btnConv'); await wait(200); await search('故乡 思'); assert.equal((await cards()).length, 1);
    assert.equal(await page.evaluate(() => JSON.parse(localStorage.getItem('ps.conv')).mode), 't'); await page.click('#btnConv'); await wait(200);
  });

  console.log('诗词全文页');
  await resetUI();
  await t('打开一首诗：文字直接写在背景图上，没有纸张色块', async () => {
    await search('明月', 'content'); await page.click('.card'); await wait(700);
    assert.equal((await page.textContent('#pTitle')).trim(), '静夜思'); assert.equal(await page.$$eval('#pText .p-line', (l) => l.length), 2);
    assert.ok(/rgba\(0, 0, 0, 0\)|transparent/.test(await page.$eval('#pIn', (e) => getComputedStyle(e).backgroundColor)));
    assert.ok(await page.$eval('#pBg', (e) => /url\(/.test(e.style.backgroundImage)));
    assert.ok(['dark', 'light', 'unk'].includes(await page.$eval('.poem-layer', (e) => e.dataset.tone)));
    await page.screenshot({ path: SHOTS + '/10-poem.png' });
  });
  await t('收藏：点 ☆ 变 ★，收藏页里能看到', async () => {
    await page.click('#pFav'); await wait(250); assert.equal(await page.textContent('#pFav'), '★');
    await resetUI(); await openNav('favs'); assert.ok((await page.textContent(TOP + ' .page-body')).includes('静夜思')); await back();
  });
  await t('全屏：隐藏所有按钮，点一下屏幕才恢复', async () => {
    await search('明月', 'content'); await page.click('.card'); await wait(500);
    await page.click('#pFull'); await wait(150);
    assert.ok(await page.$eval('#pBar', (e) => getComputedStyle(e).display === 'none'), '按钮条消失');
    await page.mouse.click(190, 400); await wait(250);
    assert.ok(await page.$eval('#pBar', (e) => getComputedStyle(e).display !== 'none'), '点屏幕后恢复');
  });
  await t('上下滑动看上一首、下一首', async () => {
    await resetUI(); await search('月', 'content'); assert.ok((await cards()).length >= 2);
    await page.click('.card'); await wait(500); const t1 = await page.textContent('#pTitle');
    await page.evaluate(() => {
      const sc = document.getElementById('pScroll'); sc.scrollTop = sc.scrollHeight;
      const mk = (type, y) => { const tc = new Touch({ identifier: 1, target: sc, clientX: 200, clientY: y }); sc.dispatchEvent(new TouchEvent(type, { touches: type === 'touchend' ? [] : [tc], changedTouches: [tc], bubbles: true })); };
      mk('touchstart', 600); mk('touchmove', 520); mk('touchmove', 430); mk('touchend', 430);
    });
    await wait(500); assert.notEqual(t1, await page.textContent('#pTitle'), '切到了另一首'); assert.ok((await page.textContent('#pPos')).includes('/'));
  });
  await t('换图：四个选项', async () => {
    await page.click('#pSwap'); await wait(250);
    assert.deepEqual(await page.$$eval('#sheetBody .row .row-t', (r) => r.map((x) => x.textContent)), ['网络图库', 'AI 生成', '自带水墨图片', '手机本地']);
  });
  await t('自带水墨：36 张缩略图，点一张预览后设为这首诗的背景', async () => {
    await page.click('#sheetBody .row:nth-child(3)'); await wait(400);
    assert.equal(await page.$$eval(TOP + ' .thumb', (x) => x.length), 36);
    await page.click(TOP + ' .thumb:nth-child(7)'); await wait(250); await page.click('#sheetBody .btn.primary'); await wait(600);
    assert.ok(/bg07\.webp/.test(await page.$eval('#pBg', (e) => e.style.backgroundImage)));
  });
  await t('手机本地：先问"相册"还是"文件"', async () => {
    await page.click('#pSwap'); await wait(250); await page.click('#sheetBody .row:nth-child(4)'); await wait(250);
    assert.deepEqual(await page.$$eval('#sheetBody .row .row-t', (r) => r.map((x) => x.textContent)), ['相册', '文件']); await back();
  });
  await t('网络图库：三个预设链接；AI 生成：已配置的 AI 链接', async () => {
    await page.click('#pSwap'); await wait(250); await page.click('#sheetBody .row:nth-child(1)'); await wait(300);
    assert.equal(await page.$$eval(TOP + ' .row', (r) => r.length), 3); await back();
    await page.click('#pSwap'); await wait(250); await page.click('#sheetBody .row:nth-child(2)'); await wait(300);
    assert.ok((await page.$$eval(TOP + ' .row .row-t', (r) => r.map((x) => x.textContent))).some((x) => /Pollinations/.test(x))); await back();
  });

  console.log('首页背景、网站、搜索引擎');
  await resetUI();
  await t('换背景：自带水墨、手机本地、恢复默认', async () => {
    await openNav('bg'); assert.deepEqual(await page.$$eval('#sheetBody .row .row-t', (r) => r.map((x) => x.textContent)), ['自带水墨图片', '手机本地', '恢复默认']);
    await page.click('#sheetBody .row:nth-child(1)'); await wait(400); await page.click(TOP + ' .thumb:nth-child(12)'); await wait(250);
    await page.click('#sheetBody .btn.primary'); await wait(500);
    assert.ok(/bg12\.webp/.test(await page.$eval('#homeBg', (e) => e.style.backgroundImage)));
  });
  await t('诗词网站：10 个，点一个在 App 内打开', async () => {
    await openNav('sites'); assert.equal(await page.$$eval(TOP + ' .row', (r) => r.length), 10);
    await page.click(TOP + ' .row:nth-child(7)'); await wait(150); assert.ok((await page.evaluate(() => window.__opened)).includes('https://ytenx.org/')); await back();
  });
  await t('搜索引擎：8 个；港台引擎把关键字转成繁体并带本地参数', async () => {
    await page.fill('#q', '云月 软件'); await openNav('engines');
    assert.deepEqual(await page.$$eval(TOP + ' .row .row-t', (r) => r.map((x) => x.textContent)), ['百度', '谷歌', '必应', 'DuckDuckGo', '谷歌香港', '谷歌台湾', 'Yahoo香港', 'Yahoo台湾']);
    const subs = await page.$$eval(TOP + ' .row .row-s', (r) => r.map((x) => x.textContent));
    assert.ok(/udm=14/.test(subs[1]), subs.join(' | '));
    assert.ok(/%E9%9B%B2%E6%9C%88/.test(subs[4]) && /hl=zh-HK/.test(subs[4]) && /gl=hk/.test(subs[4]) && /lr=lang_zh-TW/.test(subs[4]), subs[4]);
    assert.ok(/%E8%BB%9F%E9%AB%94/.test(subs[5]) && /hl=zh-TW/.test(subs[5]), subs[5]);
    await page.click(TOP + ' .row:nth-child(7)'); await wait(150);      // 第一个子元素是提示文字，所以谷歌台湾是第 7 个
    const o = await page.evaluate(() => window.__opened); assert.ok(/gl=tw/.test(o[o.length - 1]), o[o.length - 1]); await back();
  });

  console.log('设置');
  await resetUI();
  await t('设置页八项', async () => {
    await page.click('#btnSet'); await wait(300);
    assert.deepEqual(await page.$$eval(TOP + ' .row .row-t', (r) => r.map((x) => x.textContent)), ['导入', '数据库', '字体与字号', '诗词网站', '搜索引擎', '网络图库', 'AI生图网站', '其他']);
  });
  await t('字体与字号：四处文字；点一项出"默认／字体／字号"，改了立刻生效', async () => {
    await page.click(TOP + ' .row:nth-child(3)'); await wait(300);
    assert.deepEqual(await page.$$eval(TOP + ' .row .row-t', (r) => r.map((x) => x.textContent)), ['首页搜诗文字', '首页其他文字', '搜索记录显示文字', '诗词全文页面文字']);
    await page.click(TOP + ' .row:nth-child(4)'); await wait(250);
    assert.deepEqual(await page.$$eval('#sheetBody .row .row-t', (r) => r.map((x) => x.textContent)), ['默认', '字体', '字号']);
    await page.click('#sheetBody .row:nth-child(3)'); await wait(300); await page.click('#sheetBody .opt:nth-child(3)'); await wait(300);
    assert.equal(await page.evaluate(() => getComputedStyle(document.documentElement).getPropertyValue('--s-poem').trim()), '1.2');
    assert.ok((await page.textContent(TOP + ' .row:nth-child(4) .row-s')).includes('大'));
    await page.click(TOP + ' .row:nth-child(4)'); await wait(250); await page.click('#sheetBody .row:nth-child(2)'); await wait(300);
    assert.deepEqual(await page.$$eval('#sheetBody .opt', (r) => r.map((x) => x.textContent.replace(/\s*✓/, ''))), ['系统字体（手机自带）', '其他：选择字体文件（.ttf .otf）']);
    await page.click('#sheetBody .opt:nth-child(1)'); await wait(300);
    assert.ok(/system-ui/.test(await page.evaluate(() => getComputedStyle(document.documentElement).getPropertyValue('--f-poem'))));
    await page.click(TOP + ' .row:nth-child(4)'); await wait(250); await page.click('#sheetBody .row:nth-child(1)'); await wait(400);
    assert.equal(await page.evaluate(() => getComputedStyle(document.documentElement).getPropertyValue('--s-poem').trim()), '1'); await back();
  });
  await t('诗词网站列表：添加、修改、删除', async () => {
    await page.click(TOP + ' .row:nth-child(4)'); await wait(300); await page.click(TOP + ' .page-act'); await wait(250);
    const ins = await page.$$('#sheetBody input'); await ins[0].fill('测试站'); await ins[1].fill('https://example.org/');
    await page.click('#sheetBody .btn.primary'); await wait(300); assert.equal(await page.evaluate(() => PSSettings.get('sites').length), 11);
    await page.click(TOP + ' .row:last-of-type'); await wait(250); await page.click('#sheetBody .btn.danger'); await wait(300);
    assert.equal(await page.evaluate(() => PSSettings.get('sites').length), 10); await back();
  });
  await t('搜索引擎设置：本地化强度、关闭谷歌 AI 概览', async () => {
    await page.click(TOP + ' .row:nth-child(5)'); await wait(300);
    const txt = await page.textContent(TOP + ' .page-body'); assert.ok(txt.includes('本地内容优先的强度') && txt.includes('AI 概览')); await back();
  });
  await t('其他：关于与诊断、繁体写法、搜索记录、备份与恢复', async () => {
    await page.click(TOP + ' .row:nth-child(8)'); await wait(300);
    const rows = await page.$$eval(TOP + ' .row .row-t', (r) => r.map((x) => x.textContent)); assert.ok(['关于与诊断', '繁体写法', '搜索记录', '备份与恢复'].every((x) => rows.includes(x)), rows.join());
    await page.click(TOP + ' .row:nth-child(1)'); await wait(300); assert.ok((await page.textContent(TOP + ' .page-body')).includes('WebView')); await back(); await back(); await back();
  });

  console.log('\nJS 错误：' + (errs.length ? '\n' + errs.join('\n') : '无'));
  console.log(pass + ' 通过，' + fail + ' 失败');
  await browser.close(); srv.close();
  process.exit(fail || errs.length ? 1 : 0);
})();
