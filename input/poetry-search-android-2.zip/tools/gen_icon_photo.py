#!/usr/bin/env python3
"""tools/gen_icon_photo.py — 用 tools/icon_src_A.jpg（你选定的墨竹画局部）生成 Android 启动图标。
自适应图标（新手机）：背景 = 画面的模糊延展；前景 = 清晰的画，边缘羽化，和背景融在一起。圆形、方形、水滴形遮罩都好看。
老图标（旧手机）：圆角方形和圆形各一张。
用法：python3 tools/gen_icon_photo.py app/src/main/res"""
import os, sys
from PIL import Image, ImageDraw, ImageFilter, ImageOps

SRC = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'icon_src_A.jpg')
DENS = {'mdpi': 1.0, 'hdpi': 1.5, 'xhdpi': 2.0, 'xxhdpi': 3.0, 'xxxhdpi': 4.0}
INSET = 92 / 108          # 前景画占 108dp 画布的比例：圆形遮罩（72dp）只看到画中间约 78%，羽化的接缝落在遮罩外面


def layers(src, S=1024):
    bg = src.resize((S, S), Image.LANCZOS).filter(ImageFilter.GaussianBlur(S * 0.04))
    n = int(S * INSET)
    sharp = src.resize((n, n), Image.LANCZOS).convert('RGBA')
    f = int(n * 0.05)
    m = Image.new('L', (n, n), 0)
    ImageDraw.Draw(m).rectangle([f, f, n - f, n - f], fill=255)
    m = m.filter(ImageFilter.GaussianBlur(f * 0.55))
    fg = Image.new('RGBA', (S, S), (0, 0, 0, 0))
    sharp.putalpha(m)
    fg.paste(sharp, ((S - n) // 2, (S - n) // 2), sharp)
    return bg.convert('RGB'), fg


def shaped(img, size, kind, r=0.2):
    big = img.resize((size, size), Image.LANCZOS).convert('RGBA')
    k = 4
    m = Image.new('L', (size * k, size * k), 0)
    d = ImageDraw.Draw(m)
    if kind == 'circle': d.ellipse([0, 0, size * k - 1, size * k - 1], fill=255)
    else: d.rounded_rectangle([0, 0, size * k - 1, size * k - 1], radius=int(size * k * r), fill=255)
    m = m.resize((size, size), Image.LANCZOS)
    out = Image.new('RGBA', (size, size), (0, 0, 0, 0)); out.paste(big, (0, 0), m)
    return out


XML = ('<?xml version="1.0" encoding="utf-8"?>\n<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">\n'
       '    <background android:drawable="@mipmap/ic_launcher_background"/>\n'
       '    <foreground android:drawable="@mipmap/ic_launcher_foreground"/>\n</adaptive-icon>\n')


def main(res):
    src = ImageOps.autocontrast(Image.open(SRC).convert('RGB'), cutoff=1)
    bg, fg = layers(src)
    for dens, k in DENS.items():
        d = os.path.join(res, 'mipmap-' + dens); os.makedirs(d, exist_ok=True)
        shaped(src, int(48 * k), 'rounded').save(os.path.join(d, 'ic_launcher.png'), optimize=True)
        shaped(src, int(48 * k), 'circle').save(os.path.join(d, 'ic_launcher_round.png'), optimize=True)
        n = int(108 * k)
        fg.resize((n, n), Image.LANCZOS).save(os.path.join(d, 'ic_launcher_foreground.png'), optimize=True)
        bg.resize((n, n), Image.LANCZOS).save(os.path.join(d, 'ic_launcher_background.png'), optimize=True)
    v = os.path.join(res, 'mipmap-anydpi-v26'); os.makedirs(v, exist_ok=True)
    for name in ('ic_launcher.xml', 'ic_launcher_round.xml'):
        open(os.path.join(v, name), 'w', encoding='utf-8').write(XML)
    comp = bg.convert('RGBA'); comp.alpha_composite(fg)
    c = int(1024 * 72 / 108); o = (1024 - c) // 2
    prev = Image.new('RGBA', (1100, 560), (224, 224, 224, 255))
    prev.alpha_composite(shaped(comp.crop((o, o, o + c, o + c)), 512, 'circle'), (30, 24))
    prev.alpha_composite(shaped(src, 512, 'rounded'), (558, 24))
    prev.convert('RGB').save('/tmp/icon_final_preview.png')
    print('icons written to', res)

if __name__ == '__main__':
    main(sys.argv[1])
