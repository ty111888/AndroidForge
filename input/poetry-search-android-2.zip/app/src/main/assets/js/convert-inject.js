/* convert-inject.js — 由 App 注入到"在 App 内打开的网站"里：把整个网页的文字在简体、繁体之间转换，并跟踪之后出现的新文字 */
(function () {
  'use strict';
  if (window.__psConv) return;
  var HAN = /[\u3400-\u9fff\uf900-\ufaff]/;
  var VAR = { std: 't', tw: 'tw', hk: 'hk' };
  var mode = 's', variant = 'std', texts = new WeakMap(), busy = false, obs = null, t2 = null, c2 = {};
  function toS(s) { if (!window.__t2cn) return s; if (!t2) t2 = window.__t2cn.Converter({ from: 't', to: 'cn' }); return t2(s); }
  function toT(s) { if (!window.__cn2t) return s; var k = VAR[variant] || 't'; if (!c2[k]) c2[k] = window.__cn2t.Converter({ from: 'cn', to: k }); return c2[k](s); }
  function show(s) { return mode === 's' ? toS(s) : toT(s); }
  function skip(n) {
    for (var p = n.parentNode; p && p.nodeType === 1; p = p.parentNode) {
      var t = p.nodeName;
      if (t === 'SCRIPT' || t === 'STYLE' || t === 'TEXTAREA' || t === 'NOSCRIPT' || t === 'INPUT') return true;
      if (p.isContentEditable) return true;
    }
    return false;
  }
  function one(n) {
    var v = n.nodeValue;
    if (!v || !HAN.test(v) || skip(n)) return;
    var r = texts.get(n), o = v;
    if (r && r.out === v) o = r.orig;
    var out = show(o);
    texts.set(n, { orig: o, out: out });
    if (out !== v) n.nodeValue = out;
  }
  function walk(root) {
    if (!root || !document.body) return;
    busy = true;
    try {
      if (root.nodeType === 3) { one(root); return; }
      if (root.nodeType !== 1 && root.nodeType !== 9) return;
      var w = document.createTreeWalker(root, 4), n;
      while ((n = w.nextNode())) one(n);
    } finally { busy = false; }
  }
  window.__psConv = function (m, v) {
    mode = m === 't' ? 't' : 's'; variant = v || 'std';
    walk(document.body);
    if (!obs && window.MutationObserver && document.body) {
      obs = new MutationObserver(function (ms) {
        if (busy) return;
        ms.forEach(function (x) { if (x.type === 'characterData') walk(x.target); else x.addedNodes.forEach(walk); });
      });
      obs.observe(document.body, { childList: true, subtree: true, characterData: true });
    }
  };
})();
