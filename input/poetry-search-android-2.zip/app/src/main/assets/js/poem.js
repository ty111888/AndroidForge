/* poem.js — 诗词全文页：文字直接透明地写在背景图上；上下滑动看上一首/下一首；收藏；换图；全屏（点屏幕恢复）；明暗；简繁 */
(function (root) {
  'use strict';
  var UI = root.PSUI, ST = root.PSSettings, St = root.PSStore, I = root.PSImages, Bg = root.PSBg, N = root.PSNative, Cv = root.PSConvert;
  var el = UI.el, S = { list: [], i: 0, layer: null, full: false, open: false, handle: null, bg: null, token: 0, onClose: null };
  var $ = function (id) { return document.getElementById(id); };

  function lines(c) {
    c = String(c || '').replace(/\r\n?/g, '\n');
    if (c.indexOf('\n') >= 0) return c.split('\n').filter(function (s) { return s.trim(); });
    return c.split(/(?<=[。！？；])/).filter(function (s) { return s.trim(); });
  }
  function slim(p) { return { src: p.src, srcLabel: p.srcLabel, book: p.book, title: p.title, author: p.author, dynasty: p.dynasty, content: p.content, tr: p.tr, an: p.an, cm: p.cm }; }

  function build() {
    if (S.layer) return;
    var L = el('div', 'poem-layer hidden');
    L.innerHTML =
      '<div class="p-bg" id="pBg"></div><div class="p-shade" id="pShade"></div>' +
      '<div class="p-scroll" id="pScroll"><div class="p-in" id="pIn"><h2 id="pTitle"></h2><div id="pMeta"></div><div id="pText"></div><div id="pExtra"></div><div id="pCredit"></div></div></div>' +
      '<div class="p-bar" id="pBar"><button id="pBack" aria-label="返回">‹</button><span class="sp"></span>' +
      '<button id="pFav">☆</button><button id="pSwap">换图</button><button id="pDim">明暗</button><button id="pFull">全屏</button><button id="pConv" data-noconv>简</button></div>' +
      '<div class="p-dim hidden" id="pDimRow"><input type="range" min="-50" max="50" step="5" id="pDimR"></div><div class="p-pos" id="pPos"></div>';
    document.body.appendChild(L); S.layer = L;
    $('pBack').onclick = function () { UI.closeTop(); };
    $('pFav').onclick = toggleFav;
    $('pSwap').onclick = function () {
      var p = S.list[S.i];
      Bg.openSourceDialog(p, function () { return (S.bg && S.bg.url) || ''; }, function () { loadBg(p); });
    };
    $('pDim').onclick = function () { $('pDimRow').classList.toggle('hidden'); };
    $('pDimR').oninput = function () { ST.set('dim', +this.value); shade(); };
    $('pFull').onclick = function (e) { e.stopPropagation(); enterFull(); };
    $('pConv').onclick = function () { Cv.toggle(); };
    Cv.onChange(syncConv);
    // 上下滑动：到边之后再滑，切到下一首/上一首
    var sc = $('pScroll'), y0 = 0, x0 = 0, moved = false;
    sc.addEventListener('touchstart', function (e) { var t = e.touches[0]; y0 = t.clientY; x0 = t.clientX; moved = false; }, { passive: true });
    sc.addEventListener('touchmove', function (e) { var t = e.touches[0]; if (Math.abs(t.clientY - y0) > 8 || Math.abs(t.clientX - x0) > 8) moved = true; }, { passive: true });
    sc.addEventListener('touchend', function (e) {
      var t = e.changedTouches[0], dy = t.clientY - y0, dx = t.clientX - x0;
      if (!moved) return;
      if (Math.abs(dy) < 70 || Math.abs(dx) > 80) return;
      var atBottom = sc.scrollTop + sc.clientHeight >= sc.scrollHeight - 3, atTop = sc.scrollTop <= 3;
      if (dy < 0 && atBottom) go(1); else if (dy > 0 && atTop) go(-1);
    }, { passive: true });
    L.addEventListener('click', function (e) {                                             // 全屏时点一下屏幕：恢复按钮
      if (e.target.closest && e.target.closest('#pBar, #pDimRow')) return;
      if (S.full && !moved) UI.closeTop();
    });
  }

  function syncConv() { var b = $('pConv'); if (b) b.textContent = Cv.getMode() === 's' ? '简' : '繁'; }

  function shade() {
    var sh = $('pShade'), d = ST.get('dim') || 0, base = (S.layer.dataset.tone === 'unk') ? 0.22 : 0;
    sh.style.background = d >= 0 ? 'rgba(0,0,0,' + (base + d / 100).toFixed(2) + ')' : 'rgba(255,255,255,' + (-d / 100).toFixed(2) + ')';
    $('pDimR').value = d;
  }
  function measure(url) {                                  // 量一下背景图明暗，决定字用浅色还是深色
    return new Promise(function (res) {
      var im = new Image(); im.crossOrigin = 'anonymous';
      im.onload = function () {
        try {
          var c = document.createElement('canvas'); c.width = c.height = 24;
          var g = c.getContext('2d'); g.drawImage(im, 0, 0, 24, 24);
          var d = g.getImageData(0, 0, 24, 24).data, s = 0;
          for (var i = 0; i < d.length; i += 4) s += 0.299 * d[i] + 0.587 * d[i + 1] + 0.114 * d[i + 2];
          res(s / (d.length / 4) < 120 ? 'dark' : 'light');   // 图暗 → 字浅；图亮 → 字深
        } catch (e) { res('unk'); }
      };
      im.onerror = function () { res('unk'); };
      im.src = url;
    });
  }
  async function setBg(bg) {
    S.bg = bg;
    $('pBg').style.backgroundImage = 'url("' + bg.url + '")';
    var tone = await measure(bg.url);
    S.layer.dataset.tone = tone; shade();
    $('pCredit').textContent = bg.credit ? '图：' + bg.credit : '';
    if (Cv.isReady()) Cv.apply($('pCredit'));
  }
  async function loadBg(p) {
    var tk = ++S.token;
    if (S.handle) S.handle.cancel();
    var h = await Bg.forPoem(p, function (nb) { if (tk === S.token) setBg(nb); });
    if (tk !== S.token) { h.cancel(); return; }
    S.handle = h; setBg(h.bg);
  }

  async function refreshFav() {
    var p = S.list[S.i]; if (!p) return;
    var r = null; try { r = await St.getFav(I.poemKey(p)); } catch (e) { r = null; }
    $('pFav').textContent = r ? '★' : '☆';
  }
  async function toggleFav() {
    var p = S.list[S.i], key = I.poemKey(p), r = await St.getFav(key);
    if (r) { await St.deleteFav(key); UI.toast('已取消收藏'); }
    else { await St.putFav({ key: key, poem: slim(p), at: Date.now() }); UI.toast('已收藏'); }
    refreshFav();
    if (S.onFavChange) S.onFavChange();
  }

  function render(dir) {
    var p = S.list[S.i];
    $('pTitle').textContent = p.title || '（无题）';
    $('pMeta').textContent = [p.author, p.dynasty, p.srcLabel && (p.srcLabel + (p.book ? ' · ' + p.book : ''))].filter(Boolean).join('  ·  ');
    var t = $('pText'); t.innerHTML = '';
    lines(p.content).forEach(function (ln) { var d = el('div', 'p-line'); d.textContent = ln; t.appendChild(d); });
    var ex = $('pExtra'); ex.innerHTML = '';
    [['译文', p.tr], ['注释', p.an], ['赏析', p.cm]].forEach(function (x) {
      if (!x[1]) return;
      var d = el('details', 'p-ex'), s = el('summary'); s.textContent = x[0]; d.appendChild(s);
      var b = el('div', 'p-ex-b'); b.textContent = x[1]; d.appendChild(b); ex.appendChild(d);
    });
    $('pPos').textContent = S.list.length > 1 ? (S.i + 1) + ' / ' + S.list.length : '';
    $('pScroll').scrollTop = 0;
    var inn = $('pIn'); inn.classList.remove('enter-up', 'enter-down'); void inn.offsetWidth;
    if (dir) inn.classList.add(dir > 0 ? 'enter-up' : 'enter-down');
    if (Cv.isReady()) Cv.apply(S.layer);
    syncConv(); refreshFav(); loadBg(p);
  }
  function go(d) {
    var n = S.i + d;
    if (n < 0) { UI.toast('已经是第一首'); return; }
    if (n >= S.list.length) { UI.toast('已经是最后一首'); return; }
    S.i = n; render(d);
  }

  function enterFull() {
    if (S.full) return;
    S.full = true; S.layer.classList.add('full'); N.immersive(true);
    UI.pushOverlay(function () { S.full = false; S.layer.classList.remove('full'); N.immersive(false); });
  }

  // list：当前这批诗（搜索结果或收藏）；index：先看哪一首
  function open(list, index, opts) {
    build();
    S.list = list; S.i = Math.max(0, Math.min(index || 0, list.length - 1)); S.onClose = opts && opts.onClose; S.onFavChange = opts && opts.onFavChange;
    S.layer.style.zIndex = UI.nextZ(); S.layer.classList.remove('hidden', 'full'); S.open = true; S.full = false;
    $('pDimRow').classList.add('hidden');
    N.statusIcons(false);                                    // 背景图多是深色：状态栏图标用白色
    UI.pushOverlay(function () {
      S.layer.classList.add('hidden'); S.open = false; S.token++; if (S.handle) S.handle.cancel(); N.immersive(false); N.statusIcons(true);
      if (S.onClose) S.onClose();
    });
    render(0);
  }
  root.PSPoem = { open: open, isOpen: function () { return S.open; }, lines: lines };
})(window);
