/* store.js — 浏览器本地存储（IndexedDB）：导入的文集、下载到手机的数据文件、保存的图片、每首诗用哪张图、收藏
 * 数据只存在这台手机的 App 里，不上传。第三版升级到数据库版本 2，旧数据（导入的文集、图片）原样保留。 */
(function (root) {
  'use strict';
  var DB_NAME = 'ps-data', VER = 2, dbp = null;

  function open() {
    if (dbp) return dbp;
    dbp = new Promise(function (res, rej) {
      var r = indexedDB.open(DB_NAME, VER);
      r.onupgradeneeded = function () {
        var db = r.result;
        function mk(name, key) { if (!db.objectStoreNames.contains(name)) db.createObjectStore(name, { keyPath: key }); }
        mk('datasets', 'id'); mk('chunks', 'key'); mk('images', 'id'); mk('imgmap', 'key');
        mk('filemeta', 'key'); mk('filedata', 'key'); mk('favs', 'key');
      };
      r.onsuccess = function () { res(r.result); };
      r.onerror = function () { rej(r.error); };
    });
    return dbp;
  }
  function wrap(r) { return new Promise(function (res, rej) { r.onsuccess = function () { res(r.result); }; r.onerror = function () { rej(r.error); }; }); }
  function done(t) { return new Promise(function (res, rej) { t.oncomplete = function () { res(); }; t.onerror = function () { rej(t.error); }; t.onabort = function () { rej(t.error); }; }); }
  async function store(name, mode) { var db = await open(); var t = db.transaction(name, mode); return { s: t.objectStore(name), t: t }; }
  function pad(n) { return String(n).padStart(6, '0'); }

  var Store = {
    open: open,
    async putDataset(meta) { var x = await store('datasets', 'readwrite'); x.s.put(meta); await done(x.t); },
    async getDatasets() { var x = await store('datasets', 'readonly'); var r = await wrap(x.s.getAll()); return r.sort(function (a, b) { return (a.createdAt || 0) - (b.createdAt || 0); }); },
    async putChunk(id, no, records) { var x = await store('chunks', 'readwrite'); x.s.put({ key: id + ':' + pad(no), id: id, no: no, records: records }); await done(x.t); },
    async getChunk(id, no) { var x = await store('chunks', 'readonly'); var r = await wrap(x.s.get(id + ':' + pad(no))); return r ? r.records : []; },
    async deleteDataset(id) {
      var db = await open(); var t = db.transaction(['datasets', 'chunks'], 'readwrite');
      t.objectStore('datasets').delete(id); t.objectStore('chunks').delete(IDBKeyRange.bound(id + ':', id + ':\uffff'));
      await done(t);
    },

    // 下载到手机的数据文件（离线搜索用；默认一个都不下载）
    async putFile(meta, buf) {
      var db = await open(); var t = db.transaction(['filemeta', 'filedata'], 'readwrite');
      t.objectStore('filemeta').put({ key: meta.key, repo: meta.repo, path: meta.path, size: buf.byteLength, at: Date.now() });
      t.objectStore('filedata').put({ key: meta.key, buf: buf });
      await done(t);
    },
    async getFileData(key) { var x = await store('filedata', 'readonly'); var r = await wrap(x.s.get(key)); return r ? r.buf : null; },
    async listFiles() { var x = await store('filemeta', 'readonly'); return wrap(x.s.getAll()); },
    async deleteFile(key) {
      var db = await open(); var t = db.transaction(['filemeta', 'filedata'], 'readwrite');
      t.objectStore('filemeta').delete(key); t.objectStore('filedata').delete(key); await done(t);
    },
    async clearFiles() {
      var db = await open(); var t = db.transaction(['filemeta', 'filedata'], 'readwrite');
      t.objectStore('filemeta').clear(); t.objectStore('filedata').clear(); await done(t);
    },

    // 收藏
    async putFav(rec) { var x = await store('favs', 'readwrite'); x.s.put(rec); await done(x.t); },
    async deleteFav(key) { var x = await store('favs', 'readwrite'); x.s.delete(key); await done(x.t); },
    async getFav(key) { var x = await store('favs', 'readonly'); return wrap(x.s.get(key)); },
    async listFavs() { var x = await store('favs', 'readonly'); var r = await wrap(x.s.getAll()); return r.sort(function (a, b) { return (b.at || 0) - (a.at || 0); }); },

    // 图片
    async putImage(rec) { var x = await store('images', 'readwrite'); x.s.put(rec); await done(x.t); },
    async getImage(id) { var x = await store('images', 'readonly'); return wrap(x.s.get(id)); },
    async listImages() { var x = await store('images', 'readonly'); return wrap(x.s.getAll()); },
    async deleteImage(id) { var x = await store('images', 'readwrite'); x.s.delete(id); await done(x.t); },
    async clearImages() {
      var db = await open(); var t = db.transaction(['images', 'imgmap'], 'readwrite');
      t.objectStore('images').clear(); t.objectStore('imgmap').clear(); await done(t);
    },
    async setMap(key, ref) { var x = await store('imgmap', 'readwrite'); x.s.put({ key: key, ref: ref }); await done(x.t); },
    async getMap(key) { var x = await store('imgmap', 'readonly'); var r = await wrap(x.s.get(key)); return r ? r.ref : null; },
    async usage() { try { var e = await navigator.storage.estimate(); return { usage: e.usage || 0, quota: e.quota || 0 }; } catch (e) { return null; } }
  };
  root.PSStore = Store;
})(typeof self !== 'undefined' ? self : this);
