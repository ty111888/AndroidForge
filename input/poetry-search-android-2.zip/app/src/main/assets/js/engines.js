/* engines.js — 搜索引擎网址：关键字放进网址；港台搜索把关键字转成对应的繁体写法，并加上让"本地内容优先"的参数
 * 谷歌已把各国域名统一跳转到 google.com，所以港台不靠域名，靠 hl、gl（语言和地区）、lr（只要繁体网页）、cr（只要当地网页）。 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory(root);
  else root.PSEngines = factory(root);
})(typeof self !== 'undefined' ? self : this, function (root) {
  'use strict';
  // opts: { local: normal|prefer|strict, noAI: bool, conv: bool, convert: PSConvert }
  function build(engine, q, opts) {
    opts = opts || {};
    var id = engine.id || '', cv = opts.convert, query = String(q || '').trim();
    var hk = /-hk$/.test(id), tw = /-tw$/.test(id), params = [];
    if (/^google/.test(id) && opts.noAI !== false) params.push('udm=14');                 // 网页结果，不显示 AI 概览
    if ((hk || tw) && opts.conv !== false && cv && cv.isReady()) query = cv.toTrad(cv.toSimp(query), hk ? 'hk' : 'twp');
    if (/^google-(hk|tw)$/.test(id)) {
      params.push('hl=' + (hk ? 'zh-HK' : 'zh-TW'), 'gl=' + (hk ? 'hk' : 'tw'));
      var lv = opts.local || 'prefer';
      if (lv !== 'normal') params.push('lr=lang_zh-TW', 'pws=0');                          // 只显示繁体网页、关个性化
      if (lv === 'strict') params.push('cr=' + (hk ? 'countryHK' : 'countryTW'));         // 只显示当地网页（结果会少）
    }
    var tpl = engine.url || '';
    if (!query) {                                                                           // 没有关键字：打开引擎首页
      try { return new URL(tpl.replace('{q}', '')).origin + '/'; } catch (e) { return tpl.replace('{q}', ''); }
    }
    var url = tpl.replace('{q}', encodeURIComponent(query));
    if (params.length) url += (url.indexOf('?') >= 0 ? '&' : '?') + params.join('&');
    return url;
  }
  return { build: build };
});
