/* sources.js — 数据库清单（按 datasets-manifest.json 生成"仓库 → 文件夹 → 文件"）、网址、下载、读成诗词记录
 * 默认全部在线读取：边下载边搜，搜完不保存；只有你点了"下载到手机"的文件才存在手机里（见 store.js 的 putFile）。
 * 浏览器里挂在 window.PSSources，Node 里用 require 引入（方便测试）。 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory(root);
  else root.PSSources = factory(root);
})(typeof self !== 'undefined' ? self : this, function (root) {
  'use strict';

  var MIB20 = 20 * 1024 * 1024;       // jsDelivr 取不到超过 20MB 的文件，这类文件改走 raw.githubusercontent.com
  var REPOS = [
    { repo: 'chinese-poetry/chinese-poetry', id: 'cp', branch: 'master', label: '原始库（chinese-poetry）', note: '全唐诗、全宋诗是繁体' },
    { repo: 'Werneror/Poetry', id: 'wn', branch: 'master', label: 'Werneror（简体）', note: '简体；生僻字被换成"?"' },
    { repo: 'CanvaChen/llm-dataset-chinese-poetry', id: 'cv', branch: 'main', label: '校对库 CanvaChen（简体）', note: '与原始库同源，只能发现整理时的出入' },
    { repo: 'Yonggie/chinese-poetry', id: 'yg', branch: 'master', label: 'Yonggie（简体）', note: '宋词/data2.json 实为全宋诗' },
    { repo: 'VMIJUNV/chinese-poetry-and-prose', id: 'vm', branch: 'master', label: '部分诗词数据 VMIJUNV', note: '早期朝代，带译文、注释；全量请从百度盘下载后导入' }
  ];
  var byRepo = {}; REPOS.forEach(function (r) { byRepo[r.repo] = r; });
  var files = [], byId = {}, tree = [];

  function kindOf(repoId, path) {
    var parts = path.split('/'), name = parts[parts.length - 1];
    if (repoId === 'vm' && parts[0] !== '部分诗词数据') return null;
    if (/^authors?[._]/i.test(name) || /^authors?\.json$/i.test(name) || /^intro\./i.test(name)) return null;
    if (/(^|\/)(rank|strains|loader|images)(\/|$)/.test(path)) return null;
    if (/\.csv$/i.test(name)) return 'csv';
    if (/\.json$/i.test(name)) return 'json';
    return null;                      // .db、压缩包、.npy 等先不读（SQLite 要装功能包，下一阶段加）
  }

  function guess(id, path) {
    var p = path.split('/'), name = p[p.length - 1], base = name.replace(/\.[^.]+$/, '');
    var d = '', b = '';
    if (id === 'cp') {
      var top = p[0];
      if (top === '全唐诗') { if (/^poet\.tang/.test(name)) { d = '唐'; b = '全唐诗'; } else if (/^poet\.song/.test(name)) { d = '宋'; b = '全宋诗'; } }
      else if (top === '宋词') { d = '宋'; b = '宋词'; }
      else if (top === '御定全唐詩') { d = '唐'; b = '御定全唐詩'; }
      else if (top === '元曲') { d = '元'; b = '元曲'; }
      else if (top === '五代诗词') { d = '五代'; b = p[1] === 'huajianji' ? '花间集' : '南唐词'; }
      else if (top === '曹操诗集') { d = '汉'; b = '曹操诗集'; }
      else if (top === '楚辞') { d = '先秦'; b = '楚辞'; }
      else if (top === '水墨唐诗') { d = '唐'; b = '水墨唐诗'; }
      else if (top === '纳兰性德') { d = '清'; b = '纳兰性德诗集'; }
      else if (top === '诗经') { d = '先秦'; b = '诗经'; }
    } else if (id === 'wn') {
      d = base.replace(/_\d+$/, '');
    } else if (id === 'cv') {
      if (p[0] === 'data2') d = base.replace(/_\d+$/, '');
      else if (p[1] === '全唐诗') {
        if (/^poet\.tang/.test(name)) { d = '唐'; b = '全唐诗'; }
        else if (/^poet\.song/.test(name)) { d = '宋'; b = '全宋诗'; }
        else { d = '唐'; b = base; }
      } else if (p[1] === '宋词') { d = '宋'; b = base === 'ci.song' ? '宋词' : base; }
      else if (p[1] === '御定全唐诗') { d = '唐'; b = '御定全唐诗'; }
      else if (p[1] === '五代诗词') { d = '五代'; b = base; }
      else if (p[1] === '元曲') { d = '元'; b = '元曲'; }
      else if (p[1] === '曹操诗集') { d = '汉'; b = '曹操诗集'; }
      else if (p[1] === '楚辞') { d = '先秦'; b = '楚辞'; }
      else if (p[1] === '诗经') { d = '先秦'; b = '诗经'; }
      else if (p[1] === '水墨唐诗') { d = '唐'; b = '水墨唐诗'; }
      else if (p[1] === '纳兰性德') { d = '清'; b = base; }
    } else if (id === 'yg') {
      var t2 = p[0];
      if (t2 === '唐诗') { d = '唐'; b = '全唐诗'; }
      else if (t2 === '宋词') { d = '宋'; b = name === 'data2.json' ? '全宋诗' : '宋词'; }
      else if (t2 === '五代的词') { d = '五代'; b = '五代词'; }
      else if (t2 === '元曲') { d = '元'; b = '元曲'; }
      else if (t2 === '千家诗') { b = '千家诗'; }
      else if (t2 === '曹操诗集') { d = '汉'; b = t2; }
      else if (t2 === '楚辞') { d = '先秦'; b = t2; }
      else if (t2 === '纳兰性德') { d = '清'; b = '纳兰性德诗集'; }
      else if (t2 === '诗经') { d = '先秦'; b = t2; }
    } else if (id === 'vm') {
      d = base.replace(/^works/, '');
    }
    return { dynasty: d, book: b };
  }

  function dirLabel(id, dir) {
    if (id === 'cp' && dir === '全唐诗') return '全唐诗（含全宋诗，繁体）';
    if (id === 'cp' && dir === '御定全唐詩/json') return '御定全唐詩（繁体）';
    if (id === 'cv' && dir === 'data/全唐诗') return 'data/全唐诗（含全宋诗，简体）';
    if (id === 'cv' && dir === 'data2') return 'data2（Werneror 的 JSON 版）';
    if (id === 'yg' && dir === '宋词') return '宋词（data2.json 实为全宋诗）';
    return dir || '（根目录）';
  }
  function build(manifest) {
    files = []; byId = {}; tree = [];
    var perRepo = {};
    manifest.forEach(function (e) {
      var rp = byRepo[e.repo]; if (!rp) return;
      var kind = kindOf(rp.id, e.path); if (!kind) return;
      var parts = e.path.split('/'), name = parts.pop(), dir = parts.join('/');
      var g = guess(rp.id, e.path);
      var f = {
        id: rp.id + ':' + e.path, repoId: rp.id, repo: rp.repo, branch: rp.branch, path: e.path, name: name, dir: dir,
        size: e.size || 0, kind: kind, dynasty: g.dynasty, book: g.book, label: rp.label.replace(/（.*）/, '') + ' · ' + name
      };
      files.push(f); byId[f.id] = f;
      var R = perRepo[rp.id] || (perRepo[rp.id] = { rp: rp, dirs: {}, order: [] });
      if (!R.dirs[dir]) { R.dirs[dir] = []; R.order.push(dir); }
      R.dirs[dir].push(f);
    });
    REPOS.forEach(function (rp) {
      var R = perRepo[rp.id]; if (!R) return;
      var kids = R.order.map(function (dir) {
        var fs = R.dirs[dir];
        return { id: 'dir:' + rp.id + ':' + dir, kind: 'dir', label: dirLabel(rp.id, dir), files: fs, size: fs.reduce(function (a, f) { return a + f.size; }, 0), count: fs.length };
      });
      var all = [].concat.apply([], kids.map(function (k) { return k.files; }));
      tree.push({ id: 'repo:' + rp.id, kind: 'repo', label: rp.label, note: rp.note, children: kids, files: all, size: all.reduce(function (a, f) { return a + f.size; }, 0), count: all.length });
    });
    return tree;
  }
  async function loadManifest(fetchFn) {
    var f = fetchFn || root.fetch.bind(root);
    var r = await f('data/datasets-manifest.json');
    return build(await r.json());
  }

  function urls(file) {
    var enc = file.path.split('/').map(encodeURIComponent).join('/');
    var js = 'https://cdn.jsdelivr.net/gh/' + file.repo + '@' + file.branch + '/' + enc;
    var raw = 'https://raw.githubusercontent.com/' + file.repo + '/' + file.branch + '/' + enc;
    return file.size > MIB20 ? [raw, js] : [js, raw];
  }
  async function readAll(r, onBytes) {
    if (!r.body || !r.body.getReader) { var b = await r.arrayBuffer(); if (onBytes) onBytes(b.byteLength); return b; }
    var rd = r.body.getReader(), chunks = [], n = 0;
    for (;;) {
      var x = await rd.read(); if (x.done) break;
      chunks.push(x.value); n += x.value.length; if (onBytes) onBytes(x.value.length);
    }
    var out = new Uint8Array(n), o = 0;
    chunks.forEach(function (c) { out.set(c, o); o += c.length; });
    return out.buffer;
  }
  async function fetchBuffer(file, opt) {
    opt = opt || {};
    var f = opt.fetch || root.fetch.bind(root), list = urls(file), err = null;
    // fetch 只认真正的 AbortSignal（传别的东西会直接报错，这是第二版踩过的坑）
    var sig = (opt.signal && typeof AbortSignal !== 'undefined' && opt.signal instanceof AbortSignal) ? opt.signal : undefined;
    for (var i = 0; i < list.length; i++) {
      try {
        var init = { cache: 'no-store' };                                        // no-store：不留在手机的缓存里
        if (sig) init.signal = sig;
        var r = await f(list[i], init);
        if (!r.ok) throw new Error('HTTP ' + r.status);
        return await readAll(r, opt.onBytes);
      } catch (e) {
        if ((sig && sig.aborted) || (opt.cancelled && opt.cancelled())) throw e;
        err = e;
      }
    }
    throw err || new Error('下载失败');
  }

  function pick(r, keys) { for (var i = 0; i < keys.length; i++) { var v = r[keys[i]]; if (v != null && v !== '') return String(v); } return ''; }
  function normRec(r, file) {
    var content = pick(r, ['content', 'Content', 'paragraphs', '内容', 'text', '正文']);
    if (!content) return null;
    var o = {
      title: pick(r, ['title', 'Title', '题目', 'rhythmic', 'chapter', 'name', '标题']),
      author: pick(r, ['author', 'Author', '作者', 'poet']),
      dynasty: pick(r, ['dynasty', 'Dynasty', '朝代']) || file.dynasty || '',
      book: file.book || '', content: content
    };
    var tr = pick(r, ['Translation', 'translation', '译文']); if (tr) o.tr = tr;
    var an = pick(r, ['Annotation', 'annotation', '注释']); if (an) o.an = an;
    var cm = pick(r, ['Comment', 'comment', '赏析']); if (cm) o.cm = cm;
    return o;
  }
  function parsers() { if (root.PSParsers) return root.PSParsers; return require('./parsers.js'); }
  async function loadRecords(file, buf) {
    var blob = new Blob([buf]); blob.name = file.name;
    var P = parsers(), recs;
    if (file.kind === 'csv') recs = (await P.readCsvRecords(blob, 'utf-8', true)).records;
    else recs = await P.readJsonRecords(blob, 'utf-8');
    var out = [];
    for (var i = 0; i < recs.length; i++) { var n = normRec(recs[i], file); if (n) out.push(n); }
    return out;
  }

  return {
    REPOS: REPOS, MIB20: MIB20, kindOf: kindOf, guess: guess, build: build, loadManifest: loadManifest,
    getTree: function () { return tree; }, getFile: function (id) { return byId[id] || null; },
    allFiles: function () { return files; },
    urls: urls, fetchBuffer: fetchBuffer, normRec: normRec, loadRecords: loadRecords,
    filesOf: function (node) { return node.files || [].concat.apply([], (node.children || []).map(function (c) { return c.files; })); }
  };
});
