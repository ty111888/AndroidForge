/* ui.js — 界面小工具：提示、底部抽屉（"完成"才生效）、确认框、全屏页面层，都和安卓返回键配合 */
(function (root) {
  'use strict';
  var $ = function (id) { return document.getElementById(id); };

  // 层栈：打开层时 pushState，安卓返回键 → popstate → 关掉最上面一层
  var stack = [], z = 40;
  function nextZ() { return ++z; }                                    // 后打开的层盖在先打开的上面（页面层、诗页互相叠放）
  function pushOverlay(closeFn) { stack.push(closeFn); history.pushState({ ps: stack.length }, ''); }
  window.addEventListener('popstate', function () { var c = stack.pop(); if (c) c(); if (!stack.length) z = 40; });
  function closeTop() { if (stack.length) history.back(); }
  function depth() { return stack.length; }

  var toastTimer = null;
  function toast(msg, ms) {
    var t = $('toast'); if (!t) return;
    t.textContent = msg; t.classList.add('on');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { t.classList.remove('on'); }, ms || 2400);
  }

  // 底部抽屉：onClose(ok) —— ok=true 表示按了"完成"；返回键、点空白处关闭 ok=false（放弃改动）
  var sheetDone = null, sheetOkd = false;
  function openSheet(title, build, opts) {
    opts = opts || {};
    $('sheetTitle').textContent = title;
    var body = $('sheetBody'); body.innerHTML = '';
    build(body);
    $('sheetOk').textContent = opts.okLabel || '完成';
    $('sheetOk').style.display = opts.hideOk ? 'none' : '';
    sheetDone = opts.onClose || null; sheetOkd = false;
    $('sheet').classList.remove('hidden');
    if (root.PSConvert) root.PSConvert.apply($('sheet'));
    pushOverlay(function () {
      $('sheet').classList.add('hidden');
      var f = sheetDone, ok = sheetOkd; sheetDone = null; sheetOkd = false;
      if (f) f(ok);
    });
  }
  function closeSheet() { if (!$('sheet').classList.contains('hidden')) closeTop(); }

  function confirmBox(message, okLabel) {
    return new Promise(function (resolve) {
      var answered = false;
      openSheet('请确认', function (b) {
        var p = document.createElement('p'); p.className = 'confirm-msg'; p.style.whiteSpace = 'pre-wrap'; p.textContent = message; b.appendChild(p);
        var row = document.createElement('div'); row.className = 'btn-row';
        var no = document.createElement('button'); no.className = 'btn'; no.textContent = '取消';
        var yes = document.createElement('button'); yes.className = 'btn danger'; yes.textContent = okLabel || '确定';
        no.onclick = function () { closeSheet(); };
        yes.onclick = function () { answered = true; closeSheet(); };
        row.appendChild(no); row.appendChild(yes); b.appendChild(row);
      }, { hideOk: true, onClose: function () { resolve(answered); } });
    });
  }

  function el(tag, cls, html) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (html != null) e.innerHTML = html;
    return e;
  }

  // 全屏页面层：左上角返回，标题，右侧可放按钮。返回键关闭最上面一层
  function openPage(title, build, opts) {
    opts = opts || {};
    var layer = el('div', 'page-layer'), head = el('div', 'page-head'), back = el('button', 'page-back', '‹'),
      h = el('div', 'page-title'), acts = el('div', 'page-acts'), body = el('div', 'page-body');
    h.textContent = title; back.setAttribute('aria-label', '返回');
    (opts.actions || []).forEach(function (a) {
      var b = el('button', 'page-act'); b.textContent = a.label; b.onclick = function () { a.fn(api); }; acts.appendChild(b);
    });
    head.appendChild(back); head.appendChild(h); head.appendChild(acts);
    layer.style.zIndex = nextZ(); layer.appendChild(head); layer.appendChild(body); $('layers').appendChild(layer);
    var closed = false;
    var api = {
      body: body, layer: layer, title: h,
      close: function () { if (!closed) closeTop(); },
      setTitle: function (t) { h.textContent = t; if (root.PSConvert) root.PSConvert.apply(h); }
    };
    back.onclick = function () { api.close(); };
    build(body, api);
    if (root.PSConvert) root.PSConvert.apply(layer);
    pushOverlay(function () { closed = true; layer.remove(); if (opts.onClose) opts.onClose(); });
    return api;
  }

  document.addEventListener('DOMContentLoaded', function () {
    $('sheetOk').addEventListener('click', function () { sheetOkd = true; closeSheet(); });
    document.querySelector('#sheet .sheet-mask').addEventListener('click', closeSheet);
  });

  root.PSUI = { $: $, el: el, toast: toast, openSheet: openSheet, closeSheet: closeSheet, confirmBox: confirmBox, openPage: openPage, pushOverlay: pushOverlay, closeTop: closeTop, depth: depth, nextZ: nextZ };
})(window);
