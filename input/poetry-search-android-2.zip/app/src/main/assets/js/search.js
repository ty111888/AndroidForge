/* search.js — 搜索调度：选中的数据库文件（在线或已下载）+ 选中的文集（导入的）一起搜，结果边搜边出
 * 没有 400 条上限；不同数据库的同名文集全部保留，不合并、不去重，每条结果标明来自哪个库。
 * 浏览器里挂在 window.PSSearch，Node 里用 require 引入（方便测试）。 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory(root);
  else root.PSSearch = factory(root);
})(typeof self !== 'undefined' ? self : this, function (root) {
  'use strict';

  function mods() {
    if (typeof module === 'object' && module.exports) return { Core: require('./core.js'), Sources: require('./sources.js') };
    return { Core: root.PSCore, Sources: root.PSSources };
  }
  function yieldUI() { return new Promise(function (r) { setTimeout(r, 0); }); }

  function estimate(files, downloadedKeys) {
    var have = {}; (downloadedKeys || []).forEach(function (k) { have[k] = 1; });
    return files.reduce(function (a, f) { return a + (have[f.id] ? 0 : f.size); }, 0);
  }

  /* o: { query, scope, files:[文件], datasets:[导入的文集], variantFn, signal:{aborted}, store, fetch,
   *      onHits(items), onProgress({done,total,label,bytes,hits}), cap, perPoem } */
  async function run(o) {
    var M = mods(), Core = M.Core, Sources = M.Sources;
    var pq = Core.parseQuery(o.query);
    if (pq.mode === 'empty') return { total: 0, errors: [], capped: false, bytes: 0, pq: pq };
    var terms = Core.buildTerms(pq, o.variantFn);
    var signal = o.signal || { aborted: false };
    var cap = o.cap || 50000, perPoem = o.perPoem || 6;
    var jobs = [];
    (o.files || []).forEach(function (f) { jobs.push({ kind: 'file', file: f, label: f.label, heavy: f.size > 8 * 1024 * 1024 }); });
    (o.datasets || []).forEach(function (d) { jobs.push({ kind: 'ds', ds: d, label: d.name }); });
    var state = { total: 0, done: 0, bytes: 0, errors: [], capped: false, seq: 0 };
    var heavyBusy = false;
    var ctl = (typeof AbortController !== 'undefined') ? new AbortController() : null;      // 真正的取消开关，用来打断正在下载的文件

    function progress(label) {
      if (o.onProgress) o.onProgress({ done: state.done, total: jobs.length, label: label || '', bytes: state.bytes, hits: state.total });
    }
    async function scan(recs, srcId, srcLabel) {
      var batch = [];
      function flush() { if (batch.length && o.onHits) o.onHits(batch); batch = []; }
      for (var i = 0; i < recs.length; i++) {
        if (signal.aborted) { flush(); throw new Error('cancel'); }
        if (state.total >= cap) { state.capped = true; break; }
        var rec = recs[i], m = Core.matchPoem(rec, pq, terms, o.scope, perPoem);
        if (m) {
          state.total++;
          batch.push({
            id: srcId + '#' + (state.seq++), src: srcId, srcLabel: srcLabel, book: rec.book || '', title: rec.title || '', author: rec.author || '',
            dynasty: rec.dynasty || '', content: rec.content, tr: rec.tr, an: rec.an, cm: rec.cm,
            kind: m.kind, hits: m.hits || [], marks: m.marks || null
          });
          if (batch.length >= 100) flush();
        }
        if ((i & 1023) === 1023) { flush(); await yieldUI(); }
      }
      flush();
    }
    async function doJob(job) {
      if (job.kind === 'file') {
        var f = job.file, buf = null;
        if (o.store) { try { buf = await o.store.getFileData(f.id); } catch (e) { buf = null; } }
        if (!buf) buf = await Sources.fetchBuffer(f, {
          signal: ctl ? ctl.signal : undefined, fetch: o.fetch, cancelled: function () { return signal.aborted; },
          onBytes: function (n) { state.bytes += n; progress(job.label); if (signal.aborted && ctl) ctl.abort(); }
        });
        var recs = await Sources.loadRecords(f, buf); buf = null;
        await scan(recs, f.id, f.label);
        recs = null;
      } else {
        var ds = job.ds;
        for (var no = 0; no < (ds.chunks || 0); no++) {
          if (signal.aborted) throw new Error('cancel');
          await scan(await o.store.getChunk(ds.id, no), 'ds:' + ds.id, ds.name);
        }
      }
    }
    var queue = jobs.slice();
    async function worker() {
      for (;;) {
        if (signal.aborted || state.total >= cap) return;
        var idx = -1;
        for (var k = 0; k < queue.length; k++) { if (!queue[k].heavy || !heavyBusy) { idx = k; break; } }
        if (idx < 0) { if (!queue.length) return; await yieldUI(); continue; }
        var job = queue.splice(idx, 1)[0];
        if (job.heavy) heavyBusy = true;
        try { progress(job.label); await doJob(job); }
        catch (e) { if (!(e && e.message === 'cancel') && !signal.aborted) state.errors.push({ label: job.label, msg: String((e && e.message) || e) }); }
        finally { if (job.heavy) heavyBusy = false; state.done++; progress(job.label); }
      }
    }
    var n = Math.min(3, Math.max(1, jobs.length)), ws = [];
    for (var w = 0; w < n; w++) ws.push(worker());
    await Promise.all(ws);
    return { total: state.total, errors: state.errors, capped: state.capped, bytes: state.bytes, pq: pq, cancelled: !!signal.aborted };
  }

  return { run: run, estimate: estimate };
});
