/* settings-ui.js — 设置页：导入、数据库、字体与字号、诗词网站、搜索引擎、网络图库、AI生图网站、其他 */
(function (root) {
  'use strict';
  var UI = root.PSUI, ST = root.PSSettings, St = root.PSStore, Cv = root.PSConvert, N = root.PSNative, I = root.PSImages, F = root.PSFonts, Src = root.PSSources;
  var $ = UI.$, el = UI.el;
  function txt(tag, cls, t) { var e = el(tag, cls); e.textContent = t; return e; }
  function mb(n) { return root.PSApp.mb(n); }
  function next(fn) { UI.closeSheet(); setTimeout(fn, 60); }            // 先关掉当前抽屉，再开下一个（避免返回键错乱）
  function rowBtn(title, sub, fn) { var r = el('button', 'row'); r.appendChild(txt('div', 'row-t', title)); if (sub) r.appendChild(txt('div', 'row-s', sub)); r.onclick = fn; return r; }
  function optBtn(label, on, fn) { var b = el('button', 'opt' + (on ? ' on' : '')); b.textContent = label; b.onclick = fn; return b; }
  function field(label, input) { var l = el('label', 'field'); l.appendChild(txt('span', '', label)); l.appendChild(input); return l; }
  function input(type, value, ph) { var i = el('input'); i.type = type; i.value = value == null ? '' : value; if (ph) i.placeholder = ph; return i; }
  function switchRow(label, on, fn) {
    var r = el('div', 'switch'); r.appendChild(txt('span', '', label));
    var c = el('input'); c.type = 'checkbox'; c.checked = !!on; c.onchange = function () { fn(c.checked); }; r.appendChild(c); return r;
  }

  // ---------------------------------------------------------------- 设置首页
  function openSettings() {
    UI.openPage('设置', function (body) {
      body.appendChild(rowBtn('导入', '本地导入文件；GitHub 在线导入', openImport));
      body.appendChild(rowBtn('数据库', '已下载到手机的文件、流量提醒', openDbSettings));
      body.appendChild(rowBtn('字体与字号', '首页、搜索记录、诗词全文各自设置', openFonts));
      body.appendChild(rowBtn('诗词网站', '添加、删除、修改', function () { openListEditor(SITES); }));
      body.appendChild(rowBtn('搜索引擎', '添加、删除、修改；港台本地化', function () { openListEditor(ENGINES); }));
      body.appendChild(rowBtn('网络图库', '背景图来源', function () { openListEditor(GALLERIES); }));
      body.appendChild(rowBtn('AI生图网站', '一键出图或打开网站', function () { openListEditor(AISITES); }));
      body.appendChild(rowBtn('其他', '关于与诊断、繁体写法、搜索记录、备份与恢复', openOther));
    });
  }

  // ---------------------------------------------------------------- 导入
  function openImport() {
    UI.openPage('导入', function (body) {
      body.appendChild(rowBtn('本地导入', '从手机选文件：txt、csv、json、dbf+fpt……导入后进入"文集"', function () { $('fileIn').click(); }));
      body.appendChild(rowBtn('在线导入（GitHub 网址）', '粘贴 github.com 上数据库的网址，挑要导入的文件（下一阶段加入）', function () { UI.toast('在线导入将在下一阶段加入', 3000); }));
      body.appendChild(txt('p', 'tip', '导入成功的数据文件，会加到首页左侧"文集"的列表里，可以单独勾选作为搜索范围。'));
    });
  }

  // ---------------------------------------------------------------- 数据库（已下载的文件）
  function openDbSettings() {
    UI.openPage('数据库', function (body) {
      body.appendChild(txt('p', 'tip', '默认在线搜索：边下载边搜，搜完不保存。只有你在首页"数据库"里点 ⬇ 下载的文件，才保存在手机里。'));
      var use = txt('div', 'tip', '读取存储用量……'); body.appendChild(use);
      St.usage().then(function (u) { use.textContent = u ? '本 App 已占用约 ' + mb(u.usage) + '（手机分给 App 的额度约 ' + mb(u.quota) + '）' : ''; });
      var th = input('number', ST.get('confirmMB'));
      th.onchange = function () { var v = Math.max(1, parseInt(th.value, 10) || 60); ST.set('confirmMB', v); th.value = v; };
      body.appendChild(field('一次搜索要从网上下载超过多少 MB，就先问我', th));
      var box = el('div'); body.appendChild(box);
      async function draw() {
        box.innerHTML = '';
        var list = await St.listFiles();
        box.appendChild(txt('div', 'row-t', '已下载到手机的文件（' + list.length + ' 个，' + mb(list.reduce(function (a, m) { return a + m.size; }, 0)) + '）'));
        if (!list.length) box.appendChild(txt('p', 'tip', '还没有。'));
        list.forEach(function (m) {
          var f = Src.getFile(m.key), r = el('div', 'switch');
          r.appendChild(txt('span', '', (f ? f.label : m.key) + ' · ' + mb(m.size)));
          var d = el('button', 'dl'); d.textContent = '删除';
          d.onclick = async function () { await St.deleteFile(m.key); draw(); UI.toast('已删除'); };
          r.appendChild(d); box.appendChild(r);
        });
        if (list.length) {
          var all = el('button', 'btn danger wide'); all.textContent = '删除全部已下载文件';
          all.onclick = async function () { if (await UI.confirmBox('删除手机里全部已下载的数据文件？', '全部删除')) { await St.clearFiles(); draw(); UI.toast('已清空'); } };
          box.appendChild(all);
        }
        if (Cv.isReady()) Cv.apply(box);
      }
      draw();
    });
  }

  // ---------------------------------------------------------------- 字体与字号
  var SIZE_ORDER = ['s', 'm', 'l', 'xl'], fontsRedraw = null;
  function setFont(key, patch) { ST.update('fonts', function (f) { f[key] = Object.assign({}, f[key], patch); }); F.apply(); if (fontsRedraw) fontsRedraw(); }
  function openFonts() {
    UI.openPage('字体与字号', function (body) {
      function draw() {
        body.innerHTML = '';
        F.KEYS.forEach(function (k) {
          var f = ST.get('fonts')[k] || {}, desc = (f.font === 'system' ? '系统字体' : f.font === 'file' ? '自选字体文件' : '默认字体') + ' · ' + F.SIZE_NAMES[f.size || 'm'];
          body.appendChild(rowBtn(F.NAMES[k], desc, function () { openFontItem(k); }));
        });
        body.appendChild(txt('p', 'tip', '点任意一项，可选"默认""字体""字号"。'));
        if (Cv.isReady()) Cv.apply(body);
      }
      fontsRedraw = draw; draw();
    }, { onClose: function () { fontsRedraw = null; } });
  }
  function openFontItem(key) {
    UI.openSheet(F.NAMES[key], function (b) {
      b.appendChild(rowBtn('默认', '恢复默认字体和字号', function () { setFont(key, { font: 'default', file: '', size: 'm' }); next(function () { UI.toast('已恢复默认'); }); }));
      b.appendChild(rowBtn('字体', '系统字体，或选一个字体文件', function () { next(function () { openFontPick(key); }); }));
      b.appendChild(rowBtn('字号', '小、中、大、特大', function () { next(function () { openSizePick(key); }); }));
    }, { hideOk: true });
  }
  function openFontPick(key) {
    var cur = (ST.get('fonts')[key] || {}).font;
    UI.openSheet(F.NAMES[key] + ' · 字体', function (b) {
      b.appendChild(optBtn('系统字体（手机自带）', cur === 'system', function () { setFont(key, { font: 'system', file: '' }); next(function () { UI.toast('已用系统字体'); }); }));
      b.appendChild(optBtn('其他：选择字体文件（.ttf .otf）', cur === 'file', async function () {
        UI.closeSheet();
        var r = await N.pickFont();
        if (r && r.url) { setFont(key, { font: 'file', file: r.url }); UI.toast('已使用 ' + (r.name || '所选字体')); }
      }));
    }, { hideOk: true });
  }
  function openSizePick(key) {
    var cur = (ST.get('fonts')[key] || {}).size || 'm';
    UI.openSheet(F.NAMES[key] + ' · 字号', function (b) {
      SIZE_ORDER.forEach(function (s) { b.appendChild(optBtn(F.SIZE_NAMES[s], cur === s, function () { setFont(key, { size: s }); next(function () { UI.toast('字号：' + F.SIZE_NAMES[s]); }); })); });
    }, { hideOk: true });
  }

  // ---------------------------------------------------------------- 可编辑列表（诗词网站、搜索引擎、网络图库、AI生图网站）
  var SITES = { title: '诗词网站', key: 'sites', sub: function (it) { return it.url; }, fields: [['name', '名称', 'text'], ['url', '链接', 'url']], blank: function () { return { name: '', url: 'https://' }; }, check: function (it) { return /^https?:\/\//.test(it.url) ? '' : '链接要以 http:// 或 https:// 开头'; } };
  var ENGINES = {
    title: '搜索引擎', key: 'engines', sub: function (it) { return it.url; },
    fields: [['name', '名称', 'text'], ['url', '网址（用 {q} 代表关键字）', 'url']],
    blank: function () { return { id: 'custom-' + Date.now(), name: '', url: 'https://example.com/search?q={q}' }; },
    check: function (it) { return /^https?:\/\//.test(it.url) && it.url.indexOf('{q}') >= 0 ? '' : '网址要以 http 开头，并包含 {q}'; },
    extra: function (body) {
      body.appendChild(txt('div', 'row-t', '港台搜索'));
      var sel = el('select'); [['normal', '普通：只转繁体关键字'], ['prefer', '偏好本地：再加语言、地区参数（默认）'], ['strict', '严格本地：只要当地网页，结果会少']].forEach(function (o) { var op = el('option'); op.value = o[0]; op.textContent = o[1]; sel.appendChild(op); });
      sel.value = ST.get('engineLocal'); sel.onchange = function () { ST.set('engineLocal', sel.value); };
      body.appendChild(field('本地内容优先的强度（谷歌香港、谷歌台湾）', sel));
      body.appendChild(switchRow('谷歌结果页去掉 AI 概览（网址加 udm=14）', ST.get('googleNoAI'), function (v) { ST.set('googleNoAI', v); }));
      body.appendChild(switchRow('港台搜索时，把关键字转成对应的繁体写法', ST.get('engineConv'), function (v) { ST.set('engineConv', v); }));
    }
  };
  var GALLERIES = { title: '网络图库', key: 'galleries', noAdd: true, sub: function (it) { return it.enabled ? '已开启' : '已关闭'; }, fields: [['name', '名称', 'text']], blank: function () { return null; }, check: function () { return ''; }, toggle: true, tip: '这三家是公有领域图库。新增图库要先知道它的接口格式，把网址告诉我，我来适配。' };
  var AISITES = {
    title: 'AI生图网站', key: 'aiSites', sub: function (it) { return (it.mode === 'api' ? '一键出图 · ' : '网页 · ') + it.url; },
    fields: [['name', '名称', 'text'], ['url', '链接（一键出图的链接里用 {prompt} 代表提示词）', 'url'], ['mode', '用法', 'mode']],
    blank: function () { return { name: '', url: 'https://', mode: 'web' }; },
    check: function (it) { return !/^https?:\/\//.test(it.url) ? '链接要以 http 开头' : (it.mode === 'api' && it.url.indexOf('{prompt}') < 0 ? '"一键出图"的链接里要有 {prompt}' : ''); }
  };

  function openListEditor(cfg) {
    UI.openPage(cfg.title, function (body, api) {
      var wrap = el('div'); body.appendChild(wrap);
      function draw() {
        wrap.innerHTML = '';
        ST.get(cfg.key).forEach(function (it, i) {
          var r = el('button', 'row'); r.appendChild(txt('div', 'row-t', it.name || '（未命名）')); r.appendChild(txt('div', 'row-s', cfg.sub(it)));
          r.onclick = function () { editItem(cfg, i, draw); };
          wrap.appendChild(r);
        });
        if (cfg.tip) wrap.appendChild(txt('p', 'tip', cfg.tip));
        if (Cv.isReady()) Cv.apply(wrap);
      }
      draw();
      if (cfg.extra) cfg.extra(body);
      api.redraw = draw;
    }, { actions: cfg.noAdd ? [] : [{ label: '＋添加', fn: function (api) { editItem(cfg, -1, api.redraw); } }] });
  }
  function editItem(cfg, idx, done) {
    var list = ST.get(cfg.key).slice(), isNew = idx < 0, it = isNew ? cfg.blank() : Object.assign({}, list[idx]), ins = {};
    UI.openSheet(isNew ? '添加' : '修改', function (b) {
      cfg.fields.forEach(function (f) {
        var k = f[0], w;
        if (f[2] === 'mode') { w = el('select'); [['web', '打开网站（提示词自动复制）'], ['api', '一键出图（链接里有 {prompt}）']].forEach(function (o) { var op = el('option'); op.value = o[0]; op.textContent = o[1]; w.appendChild(op); }); w.value = it.mode || 'web'; }
        else w = input(f[2] === 'url' ? 'url' : 'text', it[k]);
        ins[k] = w; b.appendChild(field(f[1], w));
      });
      if (cfg.toggle) b.appendChild(switchRow('开启这个图库', it.enabled, function (v) { it.enabled = v; }));
      var row = el('div', 'btn-row'), save = el('button', 'btn primary'); save.textContent = '保存';
      save.onclick = function () {
        cfg.fields.forEach(function (f) { it[f[0]] = ins[f[0]].value.trim(); });
        if (!it.name) { UI.toast('请填名称'); return; }
        var err = cfg.check(it); if (err) { UI.toast(err, 3500); return; }
        if (isNew) list.push(it); else list[idx] = it;
        ST.set(cfg.key, list); UI.closeSheet(); done(); UI.toast('已保存');
      };
      row.appendChild(save);
      if (!isNew && !cfg.noAdd) {
        var up = el('button', 'btn'); up.textContent = '上移'; up.onclick = function () { if (idx > 0) { var t = list[idx - 1]; list[idx - 1] = list[idx]; list[idx] = t; ST.set(cfg.key, list); UI.closeSheet(); done(); } };
        var dn = el('button', 'btn'); dn.textContent = '下移'; dn.onclick = function () { if (idx < list.length - 1) { var t = list[idx + 1]; list[idx + 1] = list[idx]; list[idx] = t; ST.set(cfg.key, list); UI.closeSheet(); done(); } };
        var del = el('button', 'btn danger'); del.textContent = '删除'; del.onclick = function () { list.splice(idx, 1); ST.set(cfg.key, list); UI.closeSheet(); done(); UI.toast('已删除'); };
        row.appendChild(up); row.appendChild(dn); row.appendChild(del);
      }
      b.appendChild(row);
    }, { hideOk: true });
  }

  // ---------------------------------------------------------------- 其他
  function openOther() {
    UI.openPage('其他', function (body) {
      body.appendChild(rowBtn('关于与诊断', '版本、手机 WebView 版本、各库和图库连通测试', openAbout));
      body.appendChild(rowBtn('繁体写法', '简繁按钮转出的繁体：标准、台湾、香港', function () {
        var cur = Cv.getVariant();
        UI.openSheet('繁体写法', function (b) {
          [['std', '标准繁体'], ['tw', '台湾写法'], ['hk', '香港写法']].forEach(function (o) { b.appendChild(optBtn(o[1], cur === o[0], function () { Cv.setMode(Cv.getMode(), o[0]); next(function () { UI.toast('已设为' + o[1]); }); })); });
        }, { hideOk: true });
      }));
      body.appendChild(rowBtn('搜索记录', '共 ' + (ST.get('history') || []).length + ' 条，点这里清除', async function () { if (await UI.confirmBox('清除全部搜索记录？', '清除')) { ST.set('history', []); UI.toast('已清除'); } }));
      body.appendChild(rowBtn('备份与恢复', '把设置、各个链接列表复制出来，或粘贴回来', openBackup));
      body.appendChild(rowBtn('恢复默认设置', '链接列表、字体字号等恢复成出厂样子（不删数据和收藏）', async function () { if (await UI.confirmBox('恢复全部设置为默认？', '恢复')) { ST.reset(); F.apply(); root.PSBg.applyHome(); UI.toast('已恢复默认'); } }));
    });
  }
  function openBackup() {
    UI.openPage('备份与恢复', function (body) {
      var ta = el('textarea'); ta.rows = 12; ta.style.cssText = 'width:100%;border:1px solid var(--line);border-radius:10px;padding:8px;font-size:12px';
      ta.value = JSON.stringify(ST.all(), null, 1);
      body.appendChild(txt('p', 'tip', '下面是当前设置。"复制"可以保存到备忘录；换手机或重装后，把它粘贴回来点"恢复"。'));
      body.appendChild(ta);
      var cp = el('button', 'btn wide'); cp.textContent = '复制'; cp.onclick = function () { ta.select(); try { document.execCommand('copy'); UI.toast('已复制'); } catch (e) { UI.toast('请长按文字手动复制'); } };
      var rs = el('button', 'btn primary wide'); rs.textContent = '用上面的内容恢复';
      rs.onclick = function () {
        try { var o = JSON.parse(ta.value); if (!o || typeof o !== 'object') throw new Error('x'); Object.keys(o).forEach(function (k) { ST.set(k, o[k]); }); F.apply(); root.PSBg.applyHome(); UI.toast('已恢复'); }
        catch (e) { UI.toast('内容不是有效的设置'); }
      };
      body.appendChild(cp); body.appendChild(rs);
    });
  }
  function openAbout() {
    UI.openPage('关于与诊断', function (body) {
      var info = txt('div', 'tip', '读取中……'); body.appendChild(info);
      N.info().then(function (v) { info.textContent = '搜诗 ' + (v.app || '') + '\nWebView：' + (v.webview || '未知') + (v.device ? '\n设备：' + v.device : '') + '\n浏览器内核标识：' + navigator.userAgent; info.style.whiteSpace = 'pre-wrap'; });
      var out = el('div');
      var b1 = el('button', 'btn wide'); b1.textContent = '测试三家图库';
      b1.onclick = async function () {
        out.innerHTML = ''; out.appendChild(txt('p', 'tip', '测试中，请稍等……'));
        try {
          var r = await I.testGalleries(); var arr = Array.isArray(r) ? r : Object.keys(r || {}).map(function (k) { return Object.assign({ name: k }, r[k]); });
          out.innerHTML = '';
          arr.forEach(function (x) { out.appendChild(rowBtn((x.name || x.id || '图库') + (x.ok ? '：正常' : '：失败'), [x.ms ? x.ms + ' 毫秒' : '', x.error || x.msg || x.detail || ''].filter(Boolean).join(' · '), function () { })); });
        } catch (e) { out.innerHTML = ''; out.appendChild(txt('p', 'tip', '测试出错：' + (e.message || e))); }
        if (Cv.isReady()) Cv.apply(out);
      };
      var b2 = el('button', 'btn wide'); b2.textContent = '测试数据源连通（jsDelivr、GitHub 原始文件）';
      b2.onclick = async function () {
        out.innerHTML = ''; var f = Src.getFile('wn:唐.csv') || Src.allFiles()[0];
        if (!f) { out.appendChild(txt('p', 'tip', '没有读到数据库清单')); return; }
        var urls = Src.urls(f);
        for (var i = 0; i < urls.length; i++) {
          var t0 = Date.now(), msg;
          try { var rr = await fetch(urls[i], { headers: { Range: 'bytes=0-1023' }, cache: 'no-store' }); msg = rr.ok ? '正常 ' + (Date.now() - t0) + ' 毫秒' : '失败 HTTP ' + rr.status; }
          catch (e) { msg = '失败：' + (e.message || e); }
          out.appendChild(rowBtn(urls[i].split('/')[2], msg, function () { }));
        }
        if (Cv.isReady()) Cv.apply(out);
      };
      body.appendChild(b1); body.appendChild(b2); body.appendChild(out);
      body.appendChild(txt('p', 'tip', '联网的功能出问题时，把这里的结果截图发给我，我能更快找到原因。'));
    });
  }

  root.PSApp = root.PSApp || {};
  root.PSApp.openSettings = openSettings;
})(window);
