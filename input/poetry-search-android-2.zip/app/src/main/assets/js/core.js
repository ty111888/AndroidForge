/* core.js — 搜诗搜索规则（第三版）
 * 一个空格 = 同一句；任意标点/符号（中英文）或两个及以上空格 = 相邻的下一句；可连用；顺序不限；
 * 永远不搜"整首诗范围"。关键字可以是任意长度的词。一句 = 两个标点之间的文字；超过 14 字只显示含关键字的 14 字，
 * 隔得太远就不算。浏览器里挂在 window.PSCore，Node 里用 require 引入（方便测试）。 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.PSCore = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  var MAXWIN = 14;
  var RE_GAP = /[\s\u3000\p{P}\p{S}]/u;
  var RE_PUNCT = /[\p{P}\p{S}]/u;
  var RE_SENT = /[\p{P}\p{S}\r\n\t]+/gu;

  function classifyGap(g) {
    if (RE_PUNCT.test(g)) return 'next';
    return Array.from(g).length >= 2 ? 'next' : 'same';
  }

  function parseQuery(q) {
    q = String(q == null ? '' : q);
    var tokens = [], gaps = [], cur = '', gap = '';
    for (var ch of q) {
      if (RE_GAP.test(ch)) {
        if (cur) { tokens.push(cur); cur = ''; }
        gap += ch;
      } else {
        if (gap && tokens.length) gaps.push(classifyGap(gap));
        gap = '';
        cur += ch;
      }
    }
    if (cur) tokens.push(cur);
    var groups = tokens.length ? [[tokens[0]]] : [];
    for (var i = 1; i < tokens.length; i++) {
      if (gaps[i - 1] === 'same') groups[groups.length - 1].push(tokens[i]);
      else groups.push([tokens[i]]);
    }
    var mode = !tokens.length ? 'empty' : groups.length > 1 ? 'adj' : tokens.length > 1 ? 'same' : 'plain';
    return { tokens: tokens, groups: groups, mode: mode };
  }

  function describe(pq) {
    if (pq.mode === 'empty' || pq.mode === 'plain') return '';
    if (pq.mode === 'same') return '同一句：' + pq.tokens.join(' ＋ ');
    var n = pq.groups.length;
    return '相邻' + (n === 2 ? '两' : n) + '句：' + pq.groups.map(function (g) { return g.join(' ＋ '); }).join(' ｜ ');
  }

  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }   // 导入向导里要用
  function uniq(a) { var s = {}, o = []; a.forEach(function (x) { if (x && !s[x]) { s[x] = 1; o.push(x); } }); return o; }

  function buildTerms(pq, variantFn) {
    var vf = variantFn || function (t) { return [t]; };
    var groups = pq.groups.map(function (g) {
      return g.map(function (tok) { return { tok: tok, vars: uniq([tok].concat(vf(tok) || [])) }; });
    });
    var flat = [];
    groups.forEach(function (g) { g.forEach(function (t) { flat.push(t); }); });
    return { groups: groups, flat: flat };
  }

  function occurrences(str, vars) {
    var out = [];
    for (var v = 0; v < vars.length; v++) {
      var w = vars[v]; if (!w) continue;
      var i = str.indexOf(w);
      while (i >= 0) { out.push([i, i + w.length]); i = str.indexOf(w, i + 1); }
    }
    out.sort(function (a, b) { return a[0] - b[0] || b[1] - a[1]; });
    var m = [];
    out.forEach(function (r) {
      var l = m[m.length - 1];
      if (l && r[0] <= l[1]) { if (r[1] > l[1]) l[1] = r[1]; } else m.push([r[0], r[1]]);
    });
    return m;
  }

  function splitSentences(text) {
    var out = [], last = 0, m;
    RE_SENT.lastIndex = 0;
    while ((m = RE_SENT.exec(text)) !== null) {
      if (m.index > last) out.push({ t: text.slice(last, m.index), s: last });
      last = m.index + m[0].length;
    }
    if (last < text.length) out.push({ t: text.slice(last), s: last });
    return out;
  }

  function pickSpan(sent, terms) {
    var occ = terms.map(function (t) { return occurrences(sent, t.vars); });
    for (var k = 0; k < occ.length; k++) if (!occ[k].length) return null;
    var best = null;
    occ[0].forEach(function (a) {
      var lo = a[0], hi = a[1];
      for (var j = 1; j < occ.length; j++) {
        var bj = null, bd = 1e9;
        occ[j].forEach(function (r) {
          var d = r[0] > hi ? r[0] - hi : (r[1] < lo ? lo - r[1] : 0);
          if (d < bd) { bd = d; bj = r; }
        });
        lo = Math.min(lo, bj[0]); hi = Math.max(hi, bj[1]);
      }
      if (!best || hi - lo < best.span) best = { span: hi - lo, lo: lo, hi: hi };
    });
    return best;
  }

  function mergeMarks(a) {
    a.sort(function (x, y) { return x[0] - y[0] || y[1] - x[1]; });
    var m = [];
    a.forEach(function (r) { var l = m[m.length - 1]; if (l && r[0] <= l[1]) { if (r[1] > l[1]) l[1] = r[1]; } else m.push([r[0], r[1]]); });
    return m;
  }

  function lineFor(sent, terms) {
    for (var q = 0; q < terms.length; q++) if (!occurrences(sent, terms[q].vars).length) return null;   // 缺一个词就不算
    var len = sent.length, win;
    if (len <= MAXWIN) win = { s: 0, e: len };
    else {
      var sp = pickSpan(sent, terms);
      if (!sp || sp.span > MAXWIN) return null;
      var left = Math.floor((MAXWIN - sp.span) / 2);
      var s = Math.max(0, sp.lo - left), e = s + MAXWIN;
      if (e > len) { e = len; s = e - MAXWIN; }
      win = { s: s, e: e };
    }
    var piece = sent.slice(win.s, win.e), marks = [];
    terms.forEach(function (t) { occurrences(piece, t.vars).forEach(function (r) { marks.push([r[0], r[1]]); }); });
    if (!marks.length) return null;
    return { t: piece, m: mergeMarks(marks), l: win.s > 0, r: win.e < len };
  }
  function plainLine(sent) { return { t: sent.slice(0, MAXWIN), m: [], l: false, r: sent.length > MAXWIN }; }

  var PERMS = { 2: [[0, 1], [1, 0]], 3: [[0, 1, 2], [0, 2, 1], [1, 0, 2], [1, 2, 0], [2, 0, 1], [2, 1, 0]] };

  function matchContent(content, pq, terms, maxHits) {
    maxHits = maxHits || 6;
    var sents = splitSentences(content), hits = [], n = sents.length;
    if (!n || pq.mode === 'empty') return hits;
    if (pq.mode === 'plain' || pq.mode === 'same') {
      for (var i = 0; i < n && hits.length < maxHits; i++) {
        var ln = lineFor(sents[i].t, terms.flat);
        if (!ln) continue;
        var nbi = i + 1 < n ? i + 1 : (i - 1 >= 0 ? i - 1 : -1);
        hits.push({ lines: [ln], nb: nbi >= 0 ? plainLine(sents[nbi].t) : null, at: i });
      }
      return hits;
    }
    var G = pq.groups.length, perms = PERMS[G] || [pq.groups.map(function (_, k) { return k; })];
    for (var a = 0; a + G <= n && hits.length < maxHits; a++) {
      for (var p = 0; p < perms.length; p++) {
        var perm = perms[p], lines = [], ok = true;
        for (var k = 0; k < G; k++) {
          var l2 = lineFor(sents[a + k].t, terms.groups[perm[k]]);
          if (!l2) { ok = false; break; }
          lines.push(l2);
        }
        if (ok) { hits.push({ lines: lines, nb: null, at: a }); break; }
      }
    }
    return hits;
  }

  function matchField(text, terms) {
    text = String(text || '');
    if (!text) return null;
    var marks = [];
    for (var i = 0; i < terms.flat.length; i++) {
      var occ = occurrences(text, terms.flat[i].vars);
      if (!occ.length) return null;
      marks = marks.concat(occ);
    }
    return mergeMarks(marks);
  }

  function matchPoem(poem, pq, terms, scope, maxHits) {
    if (pq.mode === 'empty') return null;
    scope = scope || 'all';
    if (scope === 'all' || scope === 'content') {
      var h = matchContent(poem.content || '', pq, terms, maxHits);
      if (h.length) return { kind: 'content', hits: h };
    }
    if (scope === 'all' || scope === 'title') { var tm = matchField(poem.title, terms); if (tm) return { kind: 'title', marks: tm }; }
    if (scope === 'all' || scope === 'author') { var am = matchField(poem.author, terms); if (am) return { kind: 'author', marks: am }; }
    if (scope === 'all' || scope === 'dynasty') { var dm = matchField(poem.dynasty, terms); if (dm) return { kind: 'dynasty', marks: dm }; }
    return null;
  }

  return {
    MAXWIN: MAXWIN, parseQuery: parseQuery, describe: describe, buildTerms: buildTerms,
    splitSentences: splitSentences, occurrences: occurrences, lineFor: lineFor,
    matchContent: matchContent, matchField: matchField, matchPoem: matchPoem, uniq: uniq, esc: esc
  };
});
