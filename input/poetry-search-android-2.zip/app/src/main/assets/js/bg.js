/* bg.js — 背景图：自动配图（网络图库 → AI → 自带水墨 → 手机本地）、换图的各个选项、首页背景 */
(function (root) {
  'use strict';
  var UI = root.PSUI, I = root.PSImages, St = root.PSStore, ST = root.PSSettings, N = root.PSNative;
  var el = UI.el;

  function enabledMap() { var m = {}; ST.get('galleries').forEach(function (g) { m[g.id] = !!g.enabled; }); return m; }
  function ink(n) { return I.localUrl(n); }
  function dayInk() { return ((new Date().getDate() + new Date().getMonth() * 3) % I.LOCAL_COUNT) + 1; }

  // 首页背景
  function homeUrl() { var h = ST.get('homeBg') || {}; if (h.type === 'local' && h.url) return h.url; return ink(h.n || dayInk()); }
  function applyHome() { var e = UI.$('homeBg'); if (e) e.style.backgroundImage = 'url("' + homeUrl() + '")'; }

  // 这首诗用哪张图
  async function refToBg(ref, key) {
    if (!ref) return null;
    if (ref.kind === 'local') return { kind: 'ink', url: ink(ref.n), credit: '' };
    if (ref.kind === 'phone' && ref.url) return { kind: 'phone', url: ref.url, credit: '' };
    if (ref.kind === 'blob') {
      try { var rec = await St.getImage(ref.id); if (rec && rec.blob) return { kind: 'blob', url: URL.createObjectURL(rec.blob), credit: rec.credit || '', link: rec.link || '' }; } catch (e) { /* 往下走 */ }
    }
    if (ref.kind === 'url' && ref.url) return { kind: 'url', url: ref.url, credit: ref.credit || '', link: ref.link || '', fallback: ink(I.localIndexFor(key)) };
    return null;
  }
  function aiSite() { return (ST.get('aiSites') || []).filter(function (s) { return s.mode === 'api'; })[0] || null; }
  function aiUrl(site, poem, seedAdd) {
    var p = I.aiPrompt(poem).en, seed = (I.hash(I.poemKey(poem)) + (seedAdd || 0)) % 1000000;
    var u = site.url.replace('{prompt}', encodeURIComponent(p));
    return u + (u.indexOf('?') >= 0 ? '&' : '?') + 'seed=' + seed;
  }
  function timeout(ms) { return new Promise(function (res) { setTimeout(function () { res('timeout'); }, ms); }); }

  // 先给出能立刻显示的背景（已选定的 / 自带水墨），再在后台尝试：网络图库 → AI；成功就换上并记住
  async function forPoem(poem, onUpdate) {
    var key = I.poemKey(poem), ref = null, cancelled = false, ctl = new AbortController();
    try { ref = await St.getMap(key); } catch (e) { ref = null; }
    var saved = await refToBg(ref, key);
    var handle = { cancel: function () { cancelled = true; try { ctl.abort(); } catch (e) { /* ignore */ } } };
    if (saved) { handle.bg = saved; return handle; }
    handle.bg = { kind: 'ink', url: ink(I.localIndexFor(key)), credit: '' };
    (async function upgrade() {
      try {
        if (ST.get('autoGallery') && navigator.onLine !== false) {
          var r = await Promise.race([I.autoMatch(poem, enabledMap(), ctl.signal), timeout(3500)]);
          if (r && r !== 'timeout' && !cancelled && await I.loadImage(r.url, 4000) && !cancelled) {
            try { await St.setMap(key, { kind: 'url', url: r.url, credit: r.credit, link: r.link || '' }); } catch (e) { /* ignore */ }
            onUpdate({ kind: 'gallery', url: r.url, credit: r.credit, link: r.link || '' }); return;
          }
        }
        var site = aiSite();
        if (ST.get('autoAI') && site && !cancelled && navigator.onLine !== false) {
          var u = aiUrl(site, poem);
          if (await I.loadImage(u, 60000) && !cancelled) {
            try { await St.setMap(key, { kind: 'url', url: u, credit: 'AI 生成' }); } catch (e) { /* ignore */ }
            onUpdate({ kind: 'ai', url: u, credit: 'AI 生成' });
          }
        }
      } catch (e) { /* 后台尝试失败就保持自带水墨 */ }
    })();
    return handle;
  }
  async function setPoemRef(poem, ref) { await St.setMap(I.poemKey(poem), ref); }

  function btn(label, cls, fn) { var b = el('button', cls || 'btn'); b.textContent = label; b.onclick = fn; return b; }
  function listRow(title, sub, fn) {
    var r = el('button', 'row'); var t = el('div', 'row-t'); t.textContent = title; r.appendChild(t);
    if (sub) { var s = el('div', 'row-s'); s.textContent = sub; r.appendChild(s); }
    r.onclick = fn; return r;
  }

  // 自带水墨：缩略图列表，点一张预览，再设为首页背景或这首诗的背景
  function openInkGrid(opts) {
    UI.openPage('自带水墨图片', function (body) {
      var g = el('div', 'grid');
      for (var n = 1; n <= I.LOCAL_COUNT; n++) (function (n) {
        var c = el('button', 'thumb'); var im = new Image(); im.loading = 'lazy'; im.src = ink(n); im.alt = '水墨 ' + n; c.appendChild(im);
        c.onclick = function () {
          UI.openSheet('预览 · 第 ' + n + ' 张', function (b) {
            var big = new Image(); big.src = ink(n); big.className = 'preview'; b.appendChild(big);
            b.appendChild(btn(opts.label, 'btn primary wide', function () { UI.closeSheet(); setTimeout(function () { opts.onPick(n); }, 60); }));
          }, { hideOk: true });
        };
        g.appendChild(c);
      })(n);
      body.appendChild(g);
    });
  }

  // 手机本地：先问"相册"还是"文件"
  function openPhoneDialog(onPicked) {
    UI.openSheet('手机本地图片', function (b) {
      b.appendChild(listRow('相册', '缩略图预览，最新保存的在前面', function () { UI.closeSheet(); setTimeout(function () { pick('gallery'); }, 60); }));
      b.appendChild(listRow('文件', '从手机存储的根目录开始，一层层翻文件夹', function () { UI.closeSheet(); setTimeout(function () { pick('files'); }, 60); }));
    }, { hideOk: true });
    async function pick(mode) { var r = await N.pickImage(mode); if (r && r.url) onPicked(r); }
  }

  // 网络图库：先列出预设的图库链接，选一个，再看这个图库里和这首诗意象相合的图
  function openGalleryList(poem, applied) {
    UI.openPage('网络图库', function (body) {
      ST.get('galleries').forEach(function (g) {
        body.appendChild(listRow(g.name, g.enabled ? '' : '（已在设置里关闭）', function () { openCandidates(poem, g, applied); }));
      });
      var tip = el('p', 'tip'); tip.textContent = '图库列表可在 设置 → 网络图库 里添加、删除、修改。'; body.appendChild(tip);
    });
  }
  function openCandidates(poem, g, applied) {
    var ctl = new AbortController();
    UI.openPage(g.name, function (body) {
      var st = el('p', 'tip'); st.textContent = '正在查找与这首诗意象相合的图片……'; body.appendChild(st);
      var m = {}; m[g.id] = true;
      I.candidates(poem, m, ctl.signal).then(function (r) {
        st.textContent = r.list.length ? ('找到 ' + r.list.length + ' 张（意象：' + r.terms.join('、') + '），点一张预览') : '这个图库这次没有找到，可能打不开或没有合适的图。';
        var gr = el('div', 'grid');
        r.list.forEach(function (c) {
          var t = el('button', 'thumb'), im = new Image(); im.loading = 'lazy'; im.src = c.thumb || c.url; t.appendChild(im);
          t.onclick = function () {
            UI.openSheet('预览', function (b) {
              var big = new Image(); big.src = c.url; big.className = 'preview'; b.appendChild(big);
              var cr = el('p', 'tip'); cr.textContent = '来源：' + (c.credit || g.name); b.appendChild(cr);
              b.appendChild(btn('用这张', 'btn primary wide', async function () {
                try { await I.saveCandidate(St, poem, c); } catch (e) { try { await setPoemRef(poem, { kind: 'url', url: c.url, credit: c.credit, link: c.link || '' }); } catch (e2) { /* ignore */ } }
                UI.closeSheet(); applied(); UI.toast('已换成这张');
              }));
            }, { hideOk: true });
          };
          gr.appendChild(t);
        });
        body.appendChild(gr);
        if (root.PSConvert) root.PSConvert.apply(body);
      }).catch(function () { st.textContent = '这个图库打不开。'; });
    }, { onClose: function () { try { ctl.abort(); } catch (e) { /* ignore */ } } });
  }

  // AI 生成：已配置好的 AI 链接。能一键出图的（链接里有 {prompt}）直接生成并和当前背景对比；其余的复制提示词后打开网站
  function openAiList(poem, getCurrentUrl, applied) {
    UI.openPage('AI 生成', function (body) {
      (ST.get('aiSites') || []).forEach(function (s) {
        body.appendChild(listRow(s.name, s.mode === 'api' ? '一键生成，可与当前背景对比' : '打开网站，提示词已复制', function () {
          if (s.mode === 'api') openAiCompare(poem, s, getCurrentUrl, applied);
          else {
            var p = I.aiPrompt(poem).zh;
            try { navigator.clipboard.writeText(p); } catch (e) { /* ignore */ }
            UI.toast('提示词已复制，到网站粘贴；生成后保存图片，再回来选"手机本地"', 5000);
            N.openBrowser(s.url, s.name, root.PSConvert.getMode(), root.PSConvert.getVariant());
          }
        }));
      });
      var tip = el('p', 'tip'); tip.textContent = 'AI 网站列表可在 设置 → AI生图网站 里添加、删除、修改。免费的一键出图每 15 秒只能一次，图上可能有水印。'; body.appendChild(tip);
    });
  }
  function openAiCompare(poem, site, getCurrentUrl, applied) {
    var seedAdd = 0;
    UI.openPage('AI 出图对比', function (body) {
      var row = el('div', 'compare'), a = el('div', 'cmp'), b = el('div', 'cmp');
      var ia = new Image(), ib = new Image();
      ia.src = getCurrentUrl(); ia.className = 'preview'; ib.className = 'preview';
      a.appendChild(ia); var la = el('div', 'tip'); la.textContent = '当前背景'; a.appendChild(la);
      var lb = el('div', 'tip'); lb.textContent = '正在生成……（可能要十几秒）'; b.appendChild(ib); b.appendChild(lb);
      row.appendChild(a); row.appendChild(b); body.appendChild(row);
      var use = btn('用这张', 'btn primary wide', async function () {
        var u = ib.dataset.url; if (!u) return;
        try {
          var blob = await I.downloadBlob(u), id = 'ai-' + I.hash(u);
          await St.putImage({ id: id, blob: blob, credit: 'AI 生成', link: '', source: 'ai', added: Date.now() });
          await setPoemRef(poem, { kind: 'blob', id: id });
        } catch (e) { await setPoemRef(poem, { kind: 'url', url: u, credit: 'AI 生成' }); }
        applied(); UI.toast('已换成 AI 生成的图'); UI.closeTop();
      });
      use.disabled = true;
      var again = btn('再来一张', 'btn wide', function () { gen(); });
      body.appendChild(use); body.appendChild(again);
      function gen() {
        seedAdd += 1; var u = aiUrl(site, poem, seedAdd); use.disabled = true; lb.textContent = '正在生成……（可能要十几秒）'; ib.removeAttribute('src');
        I.loadImage(u, 90000).then(function (ok) {
          if (ok) { ib.src = u; ib.dataset.url = u; lb.textContent = 'AI 生成'; use.disabled = false; }
          else lb.textContent = '没有生成出来（可能太频繁或网站忙），稍等 15 秒再点"再来一张"。';
        });
      }
      gen();
    });
  }

  // 诗页"换图"：四个选项
  function openSourceDialog(poem, getCurrentUrl, applied) {
    UI.openSheet('换图', function (b) {
      b.appendChild(listRow('网络图库', '预设的图库链接，任选一个', function () { UI.closeSheet(); setTimeout(function () { openGalleryList(poem, applied); }, 60); }));
      b.appendChild(listRow('AI 生成', '已配置好的 AI 生成链接', function () { UI.closeSheet(); setTimeout(function () { openAiList(poem, getCurrentUrl, applied); }, 60); }));
      b.appendChild(listRow('自带水墨图片', '缩略图列表，任选一张', function () {
        UI.closeSheet(); setTimeout(function () {
          openInkGrid({ label: '设为这首诗的背景', onPick: async function (n) { await setPoemRef(poem, { kind: 'local', n: n }); applied(); UI.closeTop(); UI.toast('已换成这张'); } });
        }, 60);
      }));
      b.appendChild(listRow('手机本地', '相册或文件', function () {
        UI.closeSheet(); setTimeout(function () {
          openPhoneDialog(async function (r) { await setPoemRef(poem, { kind: 'phone', url: r.url }); applied(); UI.toast('已换成你选的图'); });
        }, 60);
      }));
    }, { hideOk: true });
  }

  // 首页"换背景"：自带水墨、手机本地
  function openHomeDialog() {
    UI.openSheet('换背景', function (b) {
      b.appendChild(listRow('自带水墨图片', '缩略图列表，任选一张', function () {
        UI.closeSheet(); setTimeout(function () {
          openInkGrid({ label: '设为首页背景', onPick: function (n) { ST.set('homeBg', { type: 'ink', n: n, url: '' }); applyHome(); UI.closeTop(); UI.toast('首页背景已换'); } });
        }, 60);
      }));
      b.appendChild(listRow('手机本地', '相册或文件', function () {
        UI.closeSheet(); setTimeout(function () {
          openPhoneDialog(function (r) { ST.set('homeBg', { type: 'local', n: 0, url: r.url }); applyHome(); UI.toast('首页背景已换'); });
        }, 60);
      }));
      b.appendChild(listRow('恢复默认', '每天换一张自带水墨', function () { ST.set('homeBg', { type: 'ink', n: 0, url: '' }); applyHome(); UI.closeSheet(); UI.toast('已恢复默认'); }));
    }, { hideOk: true });
  }

  root.PSBg = { applyHome: applyHome, homeUrl: homeUrl, forPoem: forPoem, ink: ink, openSourceDialog: openSourceDialog, openHomeDialog: openHomeDialog, openInkGrid: openInkGrid, openPhoneDialog: openPhoneDialog };
})(window);
