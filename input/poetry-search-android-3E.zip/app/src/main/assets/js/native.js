/* native.js — 和安卓外壳（MainActivity）通话：选图（相册/文件）、选字体文件、整屏沉浸、在 App 内打开网站、版本信息
 * 在电脑浏览器或测试里没有外壳，就退回成普通的网页做法。 */
(function (root) {
  'use strict';
  var seq = 0, pending = {};

  function has() { return !!root.PSBridge; }
  function call(method /*, args */) {
    var args = Array.prototype.slice.call(arguments, 1);
    return new Promise(function (res) {
      var id = String(++seq); pending[id] = res;
      try { root.PSBridge[method].apply(root.PSBridge, [id].concat(args)); }
      catch (e) { delete pending[id]; res(null); }
    });
  }
  function onResult(id, json) {                                // 外壳办完事后调用
    var r = pending[id]; if (!r) return;
    delete pending[id];
    var v = null; try { v = json ? JSON.parse(json) : null; } catch (e) { v = null; }
    r(v);
  }
  function webPick(accept) {                                   // 没有外壳时用 <input type=file>
    return new Promise(function (res) {
      var inp = document.createElement('input'); inp.type = 'file'; inp.accept = accept || '*/*'; inp.style.display = 'none';
      inp.onchange = function () { var f = inp.files && inp.files[0]; inp.remove(); res(f ? { url: URL.createObjectURL(f), name: f.name, web: true } : null); };
      document.body.appendChild(inp); inp.click();
    });
  }

  root.PSNative = {
    has: has, onResult: onResult,
    // mode: 'gallery' 相册（缩略图，最新在前）/ 'files' 文件（从根目录一层层翻）→ {url, name} 或 null
    pickImage: function (mode) { return has() ? call('pickImage', mode) : webPick('image/*'); },
    // 选一个手机文件夹（自动更换用）→ {uri, name} 或 null
    pickFolder: function () { return has() ? call('pickFolder') : Promise.resolve(null); },
    // 列出已引用文件夹里的图片（自动更换用）→ [content://…] 数组，失败则为空数组
    listFolderImages: async function (treeUri) { if (!has()) return []; var v = await call('listFolderImages', treeUri); return Array.isArray(v) ? v : []; },
    // 选开屏文件（GIF/MP4/MKV）→ {url, name, size} 或 null；mode: gallery 相册 / files 文件
    // 把选中的原文件地址（content://）换成网页能读的 /ref/ 地址（不复制）
    toPageUrl: function (u) {
      if (!u) return u;
      if (u.indexOf("content://") === 0) return "https://appassets.androidplatform.net/ref/" + encodeURIComponent(u);
      return u;
    },
    pickMedia: function (mode) { return has() ? call('pickMedia', mode) : webPick('video/*,image/gif,.mkv'); },
    pickFont: function () { return has() ? call('pickFile', 'font') : webPick('.ttf,.otf,.ttc,.woff,.woff2'); },
    immersive: function (on) { if (has()) { try { root.PSBridge.setImmersive(!!on); } catch (e) { /* ignore */ } } },
    statusIcons: function (dark) { if (has()) { try { root.PSBridge.setStatusIcons(!!dark); } catch (e) { /* ignore */ } } },
    // 在 App 内打开网站：另开一个带"简繁"按钮的页面，搜诗本身不动
    openBrowser: function (url, title, mode, variant) {
      if (has()) { try { root.PSBridge.openBrowser(url, title || '', mode || 's', variant || 'std'); return; } catch (e) { /* 往下退回 */ } }
      root.open(url, '_blank');
    },
    info: async function () {
      var v = has() ? await call('info') : null;
      return v || { app: '网页版', webview: (navigator.userAgent.match(/Chrome\/([\d.]+)/) || [])[1] || '', device: '' };
    }
  };
})(window);
