package com.example.poetry;

import android.app.Activity;
import android.content.ClipData;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.webkit.WebViewAssetLoader;

import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class MainActivity extends Activity {
    private static final int REQ_FILE = 1001;     // 网页 <input type=file> 弹出的文件选择器（导入文件）
    private static final int REQ_IMAGE = 2001;    // 选背景图（相册 / 文件）
    private static final int REQ_FONT = 2002;     // 选字体文件
    private static final int REQ_FOLDER = 2003;   // 选一个手机文件夹（自动更换：直接引用）
    private static final int REQ_MEDIA = 2004;
    private boolean keepAlphaNext = false;     // 这次选图是否为水晶球（存透明 PNG）
    // 选开屏文件（视频 / GIF / MKV）
    private static final String SITE = "https://appassets.androidplatform.net";

    // 这些网站的接口/图片不一定允许网页跨域读取，所以由 App 代为请求，并补上跨域许可。
    private static final Set<String> PROXY_HOSTS = new HashSet<String>(Arrays.asList(
            "collectionapi.metmuseum.org", "images.metmuseum.org",
            "api.artic.edu", "www.artic.edu",
            "openaccess-api.clevelandart.org", "openaccess-cdn.clevelandart.org",
            "image.pollinations.ai"));

    WebView w;
    private ValueCallback<Uri[]> filePathCallback;
    private String userAgent = "";
    private String pendingId = null;            // 正在等结果的选图 / 选字体请求
    private int insetTop = 0, insetBottom = 0;
    private boolean darkStatusIcons = true;     // true = 状态栏图标用深色（浅色背景上）

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setupEdgeToEdge();
        final File localDir = new File(getFilesDir(), "local");
        localDir.mkdirs();
        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .addPathHandler("/local/", new WebViewAssetLoader.InternalStoragePathHandler(this, localDir))
                .build();
        w = new WebView(this);
        setContentView(w);
        applyBarFlags(false);                       // 内容视图建好之后再设一次状态栏图标颜色
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);   // 视频和声音不用先点一下，能自动播（开屏要用）
        s.setDomStorageEnabled(true);
        userAgent = s.getUserAgentString();
        w.addJavascriptInterface(new Bridge(), "PSBridge");

        // 让网页知道状态栏、导航栏有多高（刘海屏也算），页面用 --sat / --sab 避开
        w.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override
            public WindowInsets onApplyWindowInsets(View v, WindowInsets insets) {
                readInsets(insets);
                pushInsets();
                return v.onApplyWindowInsets(insets);
            }
        });

        w.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                // /ref/<编码后的 content uri>：把用户选的原文件（不复制）读出来给网页
                if (r.getUrl().getPath() != null && r.getUrl().getPath().startsWith("/ref/")) {
                    WebResourceResponse rr = refResponse(r.getUrl());
                    if (rr != null) return rr;
                }
                WebResourceResponse res = loader.shouldInterceptRequest(r.getUrl());
                if (res != null) return res;
                return proxy(r);
            }

            @Override
            public void onPageFinished(WebView v, String url) {
                pushInsets();
            }

            // psext://open?u=<网址> ：用手机自带浏览器打开（比如去 AI 网站生成图片后保存到相册）
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if ("psext".equals(u.getScheme())) {
                    String target = u.getQueryParameter("u");
                    if (target != null && (target.startsWith("https://") || target.startsWith("http://"))) {
                        try {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(target)));
                        } catch (Exception e) {
                            // 没有可用的浏览器就算了
                        }
                    }
                    return true;
                }
                return false;
            }
        });

        // 让网页里的 <input type="file"> 能弹出系统的文件选择器（导入文件用）
        w.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = cb;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                try {
                    startActivityForResult(Intent.createChooser(i, "选择文件"), REQ_FILE);
                } catch (Exception e) {
                    filePathCallback = null;
                    cb.onReceiveValue(null);
                    return false;
                }
                return true;
            }
        });

        w.loadUrl(SITE + "/assets/index.html");
    }

    // ------------------------------------------------------------------ 整屏显示（含刘海区域）
    @SuppressWarnings("deprecation")
    private void setupEdgeToEdge() {
        Window win = getWindow();
        if (Build.VERSION.SDK_INT >= 28) {
            WindowManager.LayoutParams lp = win.getAttributes();
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            win.setAttributes(lp);
        }
        win.setStatusBarColor(Color.TRANSPARENT);
        win.setNavigationBarColor(Color.TRANSPARENT);
        if (Build.VERSION.SDK_INT >= 30) {
            win.setDecorFitsSystemWindows(false);
        }
        applyBarFlags(false);
    }

    @SuppressWarnings("deprecation")
    private void applyBarFlags(boolean hide) {
        View d = getWindow().getDecorView();
        if (Build.VERSION.SDK_INT >= 30) {
            WindowInsetsController c = getWindow().getInsetsController();
            if (c != null) {
                if (hide) {
                    c.hide(WindowInsets.Type.systemBars());
                    c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                } else {
                    c.show(WindowInsets.Type.systemBars());
                }
                int mask = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS;
                c.setSystemBarsAppearance(darkStatusIcons ? mask : 0, mask);
            }
        } else {
            int f = View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION;
            if (hide) f |= View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
            if (darkStatusIcons && Build.VERSION.SDK_INT >= 23) f |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            d.setSystemUiVisibility(f);
        }
    }

    @SuppressWarnings("deprecation")
    private void readInsets(WindowInsets in) {
        insetTop = in.getSystemWindowInsetTop();
        insetBottom = in.getSystemWindowInsetBottom();
        if (Build.VERSION.SDK_INT >= 28 && in.getDisplayCutout() != null) {
            insetTop = Math.max(insetTop, in.getDisplayCutout().getSafeInsetTop());
        }
    }

    private void pushInsets() {
        final float d = getResources().getDisplayMetrics().density;
        final String js = "(function(){var s=document.documentElement.style;s.setProperty('--sat','" + Math.round(insetTop / d)
                + "px');s.setProperty('--sab','" + Math.round(insetBottom / d) + "px');})()";
        if (w != null) w.post(new Runnable() { public void run() { w.evaluateJavascript(js, null); } });
    }

    // ------------------------------------------------------------------ 网页能调用的功能
    public class Bridge {
        // mode: gallery = 相册（缩略图，最新在前）；files = 文件（从根目录一层层翻）
        @JavascriptInterface
        public void pickImage(final String id, final String mode) {
            keepAlphaNext = mode != null && mode.startsWith("crystal");   // 水晶球加图：选完存透明 PNG
            final String realMode = mode == null ? "" : mode.replace("crystal-", "");
            runOnUiThread(new Runnable() {
                public void run() {
                    Intent i;
                    if ("gallery".equals(realMode)) {
                        i = new Intent("android.provider.action.PICK_IMAGES");        // 系统相册选择器（新版安卓自带）
                        if (i.resolveActivity(getPackageManager()) == null) {
                            i = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                            i.setType("image/*");
                            if (i.resolveActivity(getPackageManager()) == null) {
                                i = new Intent(Intent.ACTION_GET_CONTENT);
                                i.addCategory(Intent.CATEGORY_OPENABLE);
                                i.setType("image/*");
                            }
                        }
                    } else {
                        i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                        i.addCategory(Intent.CATEGORY_OPENABLE);
                        i.setType("image/*");
                        if (Build.VERSION.SDK_INT >= 26) {
                            try {
                                i.putExtra("android.provider.extra.INITIAL_URI",
                                        Uri.parse("content://com.android.externalstorage.documents/document/primary%3A"));
                            } catch (Exception e) {
                                // 没有就从系统默认位置开始
                            }
                        }
                    }
                    start(i, REQ_IMAGE, id);
                }
            });
        }

        @JavascriptInterface
        public void pickFile(final String id, final String kind) {
            runOnUiThread(new Runnable() {
                public void run() {
                    Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType("*/*");
                    start(i, REQ_FONT, id);
                }
            });
        }

        // 列出一个已引用文件夹里的图片（自动更换用）：返回 JSON 数组，每项是一张图的 content:// 地址
        @JavascriptInterface
        public void listFolderImages(final String treeUri, final String id) {
            new Thread(new Runnable() {
                public void run() {
                    try {
                        Uri tree = Uri.parse(treeUri);
                        Uri docs = android.provider.DocumentsContract.buildChildDocumentsUriUsingTree(tree,
                                android.provider.DocumentsContract.getTreeDocumentId(tree));
                        org.json.JSONArray out = new org.json.JSONArray();
                        Cursor c = getContentResolver().query(docs,
                                new String[]{android.provider.DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                                             android.provider.DocumentsContract.Document.COLUMN_MIME_TYPE}, null, null, null);
                        if (c != null) {
                            while (c.moveToNext()) {
                                String docId = c.getString(0), mime = c.getString(1);
                                if (mime != null && mime.startsWith("image/")) {
                                    out.put(android.provider.DocumentsContract.buildDocumentUriUsingTree(tree, docId).toString());
                                }
                            }
                            c.close();
                        }
                        deliver(id, out.toString());
                    } catch (Exception e) {
                        deliver(id, null);
                    }
                }
            }).start();
        }

        // 选开屏文件（GIF / MP4 / MKV）：mode = gallery 相册，files 文件；返回 JSON {url, name, size}
        @JavascriptInterface
        public void pickMedia(final String id, final String mode) {
            runOnUiThread(new Runnable() {
                public void run() {
                    Intent i;
                    if ("gallery".equals(mode)) {
                        i = new Intent(Intent.ACTION_GET_CONTENT);
                        i.addCategory(Intent.CATEGORY_OPENABLE);
                        i.setType("*/*");
                        i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"video/*", "image/gif", "video/x-matroska"});   // 相册也认 MKV
                    } else {
                        i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                        i.addCategory(Intent.CATEGORY_OPENABLE);
                        i.setType("*/*");
                        i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"video/*", "image/gif", "video/x-matroska", "application/x-matroska"});
                    }
                    start(i, REQ_MEDIA, id);
                }
            });
        }

        // 选一个手机文件夹（自动更换用）：返回文件夹的地址，并申请长期访问权限，重启后还能读
        @JavascriptInterface
        public void pickFolder(final String id) {
            runOnUiThread(new Runnable() {
                public void run() {
                    Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                    start(i, REQ_FOLDER, id);
                }
            });
        }

        @JavascriptInterface
        public void setImmersive(final boolean on) {
            runOnUiThread(new Runnable() { public void run() { applyBarFlags(on); } });
        }

        // dark = true：状态栏图标用深色（浅色背景上）；false：用白色（深色背景上）
        @JavascriptInterface
        public void setStatusIcons(final boolean dark) {
            runOnUiThread(new Runnable() { public void run() { darkStatusIcons = dark; applyBarFlags(false); } });
        }

        // 在 App 内打开网站：另开一个页面（带"简／繁"按钮），搜诗本身不动
        @JavascriptInterface
        public void openBrowser(final String url, final String title, final String mode, final String variant) {
            if (url == null || !(url.startsWith("http://") || url.startsWith("https://"))) return;
            runOnUiThread(new Runnable() {
                public void run() {
                    Intent i = new Intent(MainActivity.this, WebActivity.class);
                    i.putExtra("url", url);
                    i.putExtra("title", title == null ? "" : title);
                    i.putExtra("mode", mode == null ? "s" : mode);
                    i.putExtra("variant", variant == null ? "std" : variant);
                    startActivity(i);
                }
            });
        }

        @JavascriptInterface
        public void info(final String id) {
            try {
                JSONObject o = new JSONObject();
                PackageInfo pi = getPackageManager().getPackageInfo(getPackageName(), 0);
                o.put("app", pi.versionName);
                String wv = "";
                if (Build.VERSION.SDK_INT >= 26) {
                    PackageInfo wp = WebView.getCurrentWebViewPackage();
                    if (wp != null) wv = wp.packageName + " " + wp.versionName;
                }
                o.put("webview", wv);
                o.put("device", Build.MANUFACTURER + " " + Build.MODEL + " · Android " + Build.VERSION.RELEASE + "（API " + Build.VERSION.SDK_INT + "）");
                deliver(id, o.toString());
            } catch (Exception e) {
                deliver(id, null);
            }
        }
    }

    private void start(Intent i, int req, String id) {
        if (pendingId != null) deliver(pendingId, null);
        pendingId = id;
        try {
            startActivityForResult(i, req);
        } catch (Exception e) {
            pendingId = null;
            deliver(id, null);
        }
    }

    private void deliver(final String id, final String json) {
        final String js = "window.PSNative&&PSNative.onResult(" + JSONObject.quote(id) + "," + (json == null ? "null" : JSONObject.quote(json)) + ")";
        runOnUiThread(new Runnable() { public void run() { if (w != null) w.evaluateJavascript(js, null); } });
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (req == REQ_FILE) {
            Uri[] results = null;
            if (res == RESULT_OK && data != null) {
                ClipData cd = data.getClipData();
                if (cd != null) {
                    results = new Uri[cd.getItemCount()];
                    for (int k = 0; k < results.length; k++) results[k] = cd.getItemAt(k).getUri();
                } else if (data.getData() != null) {
                    results = new Uri[]{data.getData()};
                }
            }
            if (filePathCallback != null) filePathCallback.onReceiveValue(results);
            filePathCallback = null;
            return;
        }
        if (req == REQ_MEDIA) {
            final String id = pendingId;
            pendingId = null;
            if (id == null) return;
            if (res != RESULT_OK || data == null || data.getData() == null) { deliver(id, null); return; }
            final Uri uri = data.getData();
            new Thread(new Runnable() {
                public void run() {
                    try { deliver(id, saveSplash(uri)); }
                    catch (Exception e) { deliver(id, null); }
                }
            }).start();
            return;
        }
        if (req == REQ_FOLDER) {
            final String id = pendingId;
            pendingId = null;
            if (id == null) return;
            if (res != RESULT_OK || data == null || data.getData() == null) { deliver(id, null); return; }
            Uri tree = data.getData();
            try {
                getContentResolver().takePersistableUriPermission(tree, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Exception e) {
                // 拿不到长期权限也先返回，网页会提示
            }
            JSONObject r = new JSONObject();
            try {
                r.put("uri", tree.toString());
                r.put("name", displayName(tree));
            } catch (Exception e) { /* ignore */ }
            deliver(id, r.toString());
            return;
        }
        if (req == REQ_IMAGE || req == REQ_FONT) {
            final String id = pendingId;
            pendingId = null;
            if (id == null) return;
            Uri u = null;
            if (res == RESULT_OK && data != null) {
                u = data.getData();
                if (u == null && data.getClipData() != null && data.getClipData().getItemCount() > 0) u = data.getClipData().getItemAt(0).getUri();
            }
            if (u == null) { deliver(id, null); return; }
            final Uri uri = u;
            final boolean image = (req == REQ_IMAGE);
            new Thread(new Runnable() {
                public void run() {
                    try {
                        deliver(id, image ? saveImage(uri, keepAlphaNext) : saveFont(uri));
                        keepAlphaNext = false;
                    } catch (Exception e) {
                        deliver(id, null);
                    }
                }
            }).start();
            return;
        }
        super.onActivityResult(req, res, data);
    }

    // ------------------------------------------------------------------ 把选中的图/字体复制一份存在 App 里（原文件被删了也不影响）
    private String displayName(Uri u) {
        Cursor c = null;
        try {
            c = getContentResolver().query(u, null, null, null, null);
            if (c != null && c.moveToFirst()) {
                int ix = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (ix >= 0) return c.getString(ix);
            }
        } catch (Exception e) {
            // 取不到名字就算了
        } finally {
            if (c != null) c.close();
        }
        return "";
    }

    private int exifRotation(Uri u) {
        InputStream in = null;
        try {
            in = getContentResolver().openInputStream(u);
            if (in == null) return 0;
            ExifInterface ex = new ExifInterface(in);
            int o = ex.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
            if (o == ExifInterface.ORIENTATION_ROTATE_90) return 90;
            if (o == ExifInterface.ORIENTATION_ROTATE_180) return 180;
            if (o == ExifInterface.ORIENTATION_ROTATE_270) return 270;
        } catch (Exception e) {
            // 读不到方向信息就当不用转
        } finally {
            try { if (in != null) in.close(); } catch (Exception e) { /* ignore */ }
        }
        return 0;
    }

    // 读取用户选的原文件（content://）并返回给网页。不复制到 App 目录。
    private WebResourceResponse refResponse(Uri url) {
        try {
            String enc = url.getPath().substring("/ref/".length());
            String raw = java.net.URLDecoder.decode(enc, "UTF-8");
            Uri src = Uri.parse(raw);
            InputStream in = getContentResolver().openInputStream(src);
            if (in == null) return null;
            String mime = getContentResolver().getType(src);
            if (mime == null) mime = "application/octet-stream";
            return new WebResourceResponse(mime, null, in);
        } catch (Exception e) {
            return null;
        }
    }

    // 引用原文件：申请长期读取权限，返回原文件的 uri、名字、大小。不复制，不压缩。
    private String referenceFile(Uri u) throws Exception {
        try {
            getContentResolver().takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (Exception e) { /* 个别来源不支持长期权限，仍可临时读取 */ }
        String name = displayName(u);
        long size = 0;
        android.database.Cursor c = getContentResolver().query(u, new String[]{android.provider.OpenableColumns.SIZE}, null, null, null);
        if (c != null) { try { if (c.moveToFirst() && !c.isNull(0)) size = c.getLong(0); } finally { c.close(); } }
        JSONObject r = new JSONObject();
        r.put("url", u.toString());
        r.put("name", name);
        r.put("size", size);
        return r.toString();
    }

    private String saveImage(Uri u) throws Exception { return referenceFile(u); }
    private String saveImage(Uri u, boolean keepAlpha) throws Exception { return referenceFile(u); }

    private String saveSplash(Uri u) throws Exception { return referenceFile(u); }
    private String saveFont(Uri u) throws Exception {
        String show = displayName(u);
        String ext = ".ttf";
        int dot = show.lastIndexOf('.');
        if (dot >= 0 && show.length() - dot <= 6) ext = show.substring(dot).toLowerCase();
        File dir = new File(getFilesDir(), "local/fonts");
        dir.mkdirs();
        String name = "f" + System.currentTimeMillis() + ext;
        InputStream in = getContentResolver().openInputStream(u);
        if (in == null) throw new Exception("no stream");
        OutputStream out = new FileOutputStream(new File(dir, name));
        byte[] buf = new byte[65536];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        out.close();
        in.close();
        JSONObject r = new JSONObject();
        r.put("url", SITE + "/local/fonts/" + name);
        r.put("name", show);
        return r.toString();
    }

    // ------------------------------------------------------------------ 代取白名单网站的内容（补上跨域许可）
    private WebResourceResponse proxy(WebResourceRequest r) {
        try {
            Uri u = r.getUrl();
            String host = u.getHost();
            if (host == null || !PROXY_HOSTS.contains(host)) return null;
            if (!"GET".equalsIgnoreCase(r.getMethod())) return null;
            HttpURLConnection c = (HttpURLConnection) new URL(u.toString()).openConnection();
            c.setConnectTimeout(15000);
            c.setReadTimeout(90000);
            c.setRequestProperty("User-Agent", userAgent);
            c.setRequestProperty("Accept", "*/*");
            int code = c.getResponseCode();
            if (code < 200 || code > 599 || (code >= 300 && code < 400)) return null;
            InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
            if (in == null) in = new ByteArrayInputStream(new byte[0]);
            String mime = "application/octet-stream";
            String enc = null;
            String ct = c.getContentType();
            if (ct != null) {
                String[] parts = ct.split(";");
                mime = parts[0].trim();
                for (int k = 1; k < parts.length; k++) {
                    String p = parts[k].trim();
                    if (p.toLowerCase().startsWith("charset=")) enc = p.substring(8).trim();
                }
            }
            Map<String, String> h = new HashMap<String, String>();
            h.put("Access-Control-Allow-Origin", "*");
            String reason = c.getResponseMessage();
            if (reason == null || reason.length() == 0) reason = code < 400 ? "OK" : "Error";
            return new WebResourceResponse(mime, enc, code, reason, h, in);
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public void onBackPressed() {
        if (w.canGoBack()) w.goBack(); else super.onBackPressed();
    }
}
