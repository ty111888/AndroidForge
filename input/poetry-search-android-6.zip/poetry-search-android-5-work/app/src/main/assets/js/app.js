/* app.js — 搜诗主程序：首页、搜索与结果、数据库/文集树、查词找字、诗词网站、搜索引擎、收藏 */
(function (root) {
  'use strict';
  var UI = root.PSUI, ST = root.PSSettings, St = root.PSStore, Src = root.PSSources, Cv = root.PSConvert, N = root.PSNative,
    Core = root.PSCore, Eng = root.PSEngines, Bg = root.PSBg, Poem = root.PSPoem;
  var $ = UI.$, el = UI.el;
  var R = { items: [], rendered: 0, ac: null, running: false, inResults: false, io: null };
  var lastSubmittedQuery = null, searchButtonMode = 'search', historyTimer = null, homeHistoryOpen = false;
  var PAGE = 60;

  function mb(n) { return n >= 1048576 ? (Math.round(n / 104857.6) / 10) + 'MB' : Math.max(1, Math.round(n / 1024)) + 'KB'; }
  function txt(tag, cls, t) { var e = el(tag, cls); e.textContent = t; return e; }

  // ======================================================== 启动
  async function boot() {
    // 先播开屏（有才播），播完再进首页；没有开屏就直接进
    // 先把首页准备好（字体、背景、固定水晶球），不等开屏，避免开屏出错时首页冻住
    try { root.PSFonts.apply(); } catch (e) { console.warn('fonts', e); }
    try { Bg.applyHome(); } catch (e) { console.warn('bg', e); }
    try { root.PSCrystal.applyFixed(); } catch (e) { console.warn('fixed ball', e); }
    try { root.PSCrystal.applyCurrent(); } catch (e) { console.warn('current ball', e); }
    // 开屏盖在首页上面播，不阻塞启动；播完自己收起
    try { root.PSSplash.run(function () {}); } catch (e) { console.warn('splash', e); }
    $('scope').value = ST.get('scope') || 'all';
    fillHistory();
    $('btnSet').onclick = function (e) { e.stopPropagation(); root.PSApp.openSettings(); };
    $('clearHomeHistory').onclick = function (e) { e.preventDefault(); e.stopPropagation(); ST.clearHomeHistory(); hideHomeHistory(); hideRecentHistory(); renderHomeHistory(); };
    $('leftOrb').onclick = function (e) { e.stopPropagation(); $('leftNav').classList.toggle('open'); $('leftOrbWrap').classList.toggle('nav-open', $('leftNav').classList.contains('open')); };
    // 首页空白处点一下：水晶球、搜索框、"搜诗"一起收起；再点一下出现
    document.getElementById('landingTap').addEventListener('click', function (e) {
      if (e.target.closest && e.target.closest('#leftOrbWrap, #btnSet, #searchForm, #longQueryWrap, #historyPanel, #leftNav, #resultsView, #hint')) return;
      if (!$('app').classList.contains('landing')) return;
      $('app').classList.toggle('hidden-ui');
      $('leftNav').classList.remove('open'); $('leftOrbWrap').classList.remove('nav-open');
    });
    $('searchForm').addEventListener('submit', function (e) { e.preventDefault(); $('q').blur(); startSearch(); });
    $('go').onclick = function () {
      if (searchButtonMode === 'clear' && String($('q').value || '').trim() === String(lastSubmittedQuery || '').trim()) {
        hideLongQuery(); $('q').value = ''; lastSubmittedQuery = null; setSearchButton('search'); updateHint(); $('q').focus();
      } else {
        hideLongQuery(); startSearch();
      }
    };
    // 转换库在后面加载；它挂住也不影响上面已经绑好的按钮
    Cv.start().then(function () { syncConv(); Cv.onChange(syncConv); }).catch(function () {});
    $('q').addEventListener('input', function () { updateHint(); if (searchButtonMode === 'clear' && $('q').value !== lastSubmittedQuery) setSearchButton('search'); syncLongQuery(); hideRecentHistory(); clearTimeout(historyTimer); historyTimer = setTimeout(function () { if (document.activeElement === $('q')) showRecentHistory(); }, 650); });
    $('longQuery').addEventListener('input', function () { $('q').value = $('longQuery').value; updateHint(); if (searchButtonMode === 'clear' && $('q').value !== lastSubmittedQuery) setSearchButton('search'); syncLongQuery(); hideRecentHistory(); clearTimeout(historyTimer); historyTimer = setTimeout(function () { if (document.activeElement === $('longQuery')) showRecentHistory(); }, 650); });
    $('longQuery').addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); hideLongQuery(); startSearch(); } });
    $('longQueryClear').onclick = function (e) { e.preventDefault(); e.stopPropagation(); $('q').value = ''; $('longQuery').value = ''; lastSubmittedQuery = null; setSearchButton('search'); updateHint(); hideLongQuery(); showRecentHistory(); $('longQuery').focus(); };
    // 点进搜索框输入时，左边六个按钮自动收起，不挡输入
    $('q').addEventListener('focus', function () { $('leftNav').classList.remove('open'); $('leftOrbWrap').classList.remove('nav-open'); showHomeHistory(); showRecentHistory(); });
    $('q').addEventListener('click', function () { showHomeHistory(); showRecentHistory(); });
    $('q').addEventListener('blur', scheduleSearchHistoryHide);
    $('longQuery').addEventListener('focus', function () { showHomeHistory(); showRecentHistory(); });
    $('longQuery').addEventListener('click', function () { showHomeHistory(); showRecentHistory(); });
    $('longQuery').addEventListener('blur', scheduleSearchHistoryHide);
    // 麦克风：调用手机系统自带的语音转文字，结果填进搜索框；放大镜和回车都执行搜索
    $('mic').onclick = async function () {
      if (root.PSNative && root.PSNative.has && root.PSNative.has()) {
        UI.toast('请说话…');
        var gotVoiceText = false;
        function showVoiceText(t) {
          t = String(t || '').replace(/[。.]$/, '');
          if (!t) return;
          gotVoiceText = true; $('q').value = t; setSearchButton('search'); updateHint(); syncLongQuery();
        }
        var vt = await root.PSNative.startVoice(showVoiceText);
        if (vt) showVoiceText(vt); else if (!gotVoiceText) UI.toast('没听清，请再试一次');
        return;
      }
      var SR = window.SpeechRecognition || window.webkitSpeechRecognition;
      if (!SR) { UI.toast('手机暂不支持语音输入，请直接打字'); return; }
      var rec = new SR(); rec.lang = 'zh-CN'; rec.interimResults = true; rec.maxAlternatives = 1;
      rec.onresult = function (ev) { var rs = ev.results, last = rs && rs.length ? rs[rs.length - 1] : null, t = last && last[0] ? last[0].transcript : ''; if (t) { $('q').value = t.replace(/[。.]$/, ''); setSearchButton('search'); updateHint(); syncLongQuery(); } };
      rec.onerror = function () { UI.toast('没听清，请再试一次'); };
      try { rec.start(); UI.toast('请说话…'); } catch (e) { UI.toast('语音输入暂时不能用'); }
    };
    $('scope').addEventListener('change', function () { ST.set('scope', $('scope').value); });
    Array.prototype.forEach.call(document.querySelectorAll('#leftNav button'), function (b) { b.onclick = function () { act(b.dataset.act); }; });
    $('btnHome').onclick = function () { UI.closeTop(); };
    $('btnStop').onclick = function () { if (R.ac) R.ac.aborted = true; };
    var io = ('IntersectionObserver' in root) ? new IntersectionObserver(function (es) { if (es[0].isIntersecting) renderMore(); }, { root: $('results') }) : null;
    if (io) io.observe($('sentinel')); R.io = io;
    $('results').addEventListener('scroll', function () { if (!io) { var r = $('results'); if (r.scrollTop + r.clientHeight > r.scrollHeight - 400) renderMore(); } });
    try { await Src.loadManifest(); } catch (e) { UI.toast('数据库清单读取失败：' + e.message, 4000); }
    var fin = $('fileIn');
    fin.onchange = function () { if (fin.files && fin.files.length) root.PSImport.start(fin.files); fin.value = ''; };
    root.PSImport.init({ onDone: onImported });
    if (Cv.isReady()) Cv.applyAll();
  }
  function syncConv() { var b = $('btnConv'); if (b) b.textContent = Cv.getMode() === 's' ? '简' : '繁'; }
  function setSearchButton(mode) {
    searchButtonMode = mode === 'clear' ? 'clear' : 'search';
    var b = $('go'); if (!b) return;
    if (searchButtonMode === 'clear') {
      b.setAttribute('aria-label', '清除当前关键词');
      b.innerHTML = '<span class="clear-mark" aria-hidden="true">×</span>';
    } else {
      b.setAttribute('aria-label', '搜索');
      b.innerHTML = '<img src="img/icon-search.png" alt="">';
    }
  }
  function hideLongQuery() {
    var w = $('longQueryWrap'); if (w) w.classList.add('hidden');
    if ($('app')) $('app').classList.remove('long-query-open');
  }
  function syncLongQuery() {
    var q = $('q'), w = $('longQueryWrap'), l = $('longQuery'); if (!q || !w || !l) return;
    l.value = q.value;
    if (q.value && q.scrollWidth > q.clientWidth + 1) {
      w.classList.remove('hidden');
      $('app').classList.add('long-query-open');
    } else {
      hideLongQuery();
    }
  }
  function updateHint() { $('hint').textContent = Core.describe(Core.parseQuery($('q').value)); if (Cv.isReady()) Cv.apply($('hint')); }
  function openAllHistory() {
    var all = ST.getHistory('home');
    UI.openPage('搜索记录（' + all.length + ' 条）', function (body) {
      if (!all.length) { var p = document.createElement('p'); p.className = 'tip'; p.textContent = '还没有搜索记录'; body.appendChild(p); return; }
      all.forEach(function (h) {
        var b = document.createElement('button'); b.className = 'row'; var t = document.createElement('div'); t.className = 'row-t'; t.textContent = h; b.appendChild(t);
        b.onclick = function () { ST.addHistory(h); fillHistory(); $('q').value = h; updateHint(); UI.closeTop(); };
        body.appendChild(b);
      });
    });
  }
  function hideRecentHistory() { var p = $('historyPanel'); if (p) p.classList.add('hidden'); }
  function searchInputActive() { return document.activeElement === $('q') || document.activeElement === $('longQuery'); }
  function scheduleSearchHistoryHide() {
    setTimeout(function () { if (!searchInputActive()) { hideHomeHistory(); hideRecentHistory(); } }, 180);
  }
  function syncHomeHistoryVisibility() {
    var box = $('historyHome'), clear = $('clearHomeHistory');
    if (!box) return;
    var visible = homeHistoryOpen && searchInputActive() && ST.getHistory('home').length > 0;
    box.classList.toggle('hidden', !visible);
    if (clear) clear.classList.toggle('hidden', !visible);
  }
  function showHomeHistory() { homeHistoryOpen = true; renderHomeHistory(); }
  function hideHomeHistory() {
    homeHistoryOpen = false;
    var box = $('historyHome'), clear = $('clearHomeHistory');
    if (box) box.classList.add('hidden');
    if (clear) clear.classList.add('hidden');
  }
  function showRecentHistory() {
    var p = $('historyPanel'); if (!p) return;
    p.innerHTML = '';
    ST.getHistory('recent').slice(0, 20).forEach(function (h) {
      var b = document.createElement('button'); b.type = 'button'; b.title = h; b.textContent = h;
      b.onclick = function (e) { e.preventDefault(); e.stopPropagation(); var q = $('q'); q.value = q.value ? q.value + h : h; updateHint(); setSearchButton('search'); syncLongQuery(); q.focus(); showRecentHistory(); };
      p.appendChild(b);
    });
    p.classList.toggle('hidden', !ST.getHistory('recent').length);
  }
  function renderHomeHistory() {
    var box = $('historyHome'); if (!box) return;
    box.innerHTML = '';
    ST.getHistory('home').slice(0, 50).forEach(function (h) {
      var b = document.createElement('button'); b.type = 'button'; b.textContent = h;
      b.onclick = function () {
        ST.addHistory(h); fillHistory(); $('q').value = h; lastSubmittedQuery = null; setSearchButton('search'); updateHint(); hideLongQuery(); $('q').focus(); showRecentHistory();
        // 选中一条完整历史记录后收起背景面板；再次点搜索框可重新显示。
        hideHomeHistory();
      };
      box.appendChild(b);
    });
    syncHomeHistoryVisibility();
  }
  function fillHistory() {
    renderHomeHistory();
    if (homeHistoryOpen && searchInputActive()) showRecentHistory();
  }
  function onImported(id) {
    var sel = ST.get('selCol').slice(); if (sel.indexOf(id) < 0) sel.push(id); ST.set('selCol', sel);
    UI.toast('已加入"文集"，并已勾选为搜索范围', 3500);
  }

  // ======================================================== 左侧按钮
  function act(name) {
    if (name === 'db') openTree('db');
    else if (name === 'col') openTree('col');
    else if (name === 'lookup') openLookupSites();
    else if (name === 'sites') openSites();
    else if (name === 'engines') openEngines();
    else if (name === 'favs') openFavs();
    else if (name === 'bg') Bg.openHomeDialog();
  }

  // ======================================================== 搜索
  async function downloadedKeys() { try { return (await St.listFiles()).map(function (m) { return m.key; }); } catch (e) { return []; } }

  async function startSearch() {
    var q = $('q').value.trim(), pq = Core.parseQuery(q);
    if (pq.mode === 'empty') { UI.toast('请输入关键字'); return; }
    hideHomeHistory(); hideRecentHistory();
    var scope = $('scope').value;
    var files = (ST.get('selDb') || []).map(Src.getFile).filter(Boolean);
    var all = []; try { all = await St.getDatasets(); } catch (e) { all = []; }
    var datasets = all.filter(function (d) { return (ST.get('selCol') || []).indexOf(d.id) >= 0; });
    if (!files.length && !datasets.length) { UI.toast('请先在"数据库"或"文集"里勾选要搜的库'); openTree('db'); return; }
    var est = root.PSSearch.estimate(files, await downloadedKeys());
    if (est > (ST.get('confirmMB') || 60) * 1048576) {
      var ok = await UI.confirmBox('这次搜索大约要从网上下载 ' + mb(est) + '（搜完不保存）。继续吗？\n可以先在"数据库"里缩小范围。', '继续搜索');
      if (!ok) return;
    }
    hideLongQuery(); lastSubmittedQuery = q; setSearchButton('clear');
    ST.addHistory(q); fillHistory();
    if (R.running && R.ac) R.ac.aborted = true;
    enterResults();
    R.items = []; R.rendered = 0; $('results').innerHTML = ''; $('results').scrollTop = 0;
    var ac = { aborted: false }; R.ac = ac; R.running = true;
    $('btnStop').classList.remove('hidden'); setStatus('正在搜索……', 0);
    var t0 = Date.now();
    var res = await root.PSSearch.run({
      query: q, scope: scope, files: files, datasets: datasets, variantFn: Cv.isReady() ? Cv.variants : null, store: St, signal: ac,
      onHits: function (b) { if (R.ac !== ac) return; for (var i = 0; i < b.length; i++) R.items.push(b[i]); if (R.rendered < PAGE) renderMore(); },
      onProgress: function (p) { if (R.ac === ac) setStatus('搜索中：' + p.done + '/' + p.total + ' · 已找到 ' + p.hits + ' 条' + (p.bytes ? ' · 已下载 ' + mb(p.bytes) : ''), p.total ? p.done / p.total : 0); }
    });
    if (R.ac !== ac) return;
    R.running = false; $('btnStop').classList.add('hidden');
    var sec = Math.round((Date.now() - t0) / 100) / 10;
    var st = $('status'); st.textContent = '';
    st.appendChild(document.createTextNode((res.cancelled ? '已停止，' : '') + '共找到 ' + res.total + ' 条 · 用时 ' + sec + ' 秒' + (res.bytes ? ' · 下载 ' + mb(res.bytes) : '') + (res.capped ? ' · 命中太多，只保留前面一部分，请缩小范围' : '')));
    if (res.errors.length) {
      var a = el('a'); a.textContent = ' · ' + res.errors.length + ' 个库读取失败（点看原因）'; a.onclick = function () { showErrors(res.errors); }; st.appendChild(a);
    }
    $('progress').firstChild.style.width = '0%';
    if (!R.items.length) $('results').appendChild(txt('div', 'empty', res.errors.length ? '有库读取失败，没有找到结果。' : '没有找到。可以换个词，或用空格、标点调整"同一句／相邻句"。'));
    if (Cv.isReady()) Cv.apply($('resultsView'));
  }
  function showErrors(errs) {
    UI.openSheet('读取失败的库', function (b) {
      errs.forEach(function (e) { var r = el('div', 'row'); r.appendChild(txt('div', 'row-t', e.label)); r.appendChild(txt('div', 'row-s', e.msg)); b.appendChild(r); });
      b.appendChild(txt('p', 'tip', '常见原因：网络不通、网站被限制、文件太大。可以在"数据库"里点 ⬇ 先下载到手机再搜。'));
    }, { hideOk: true });
  }
  function setStatus(t, frac) { $('status').textContent = t; $('progress').firstChild.style.width = Math.round((frac || 0) * 100) + '%'; }
  function enterResults() {
    if (R.inResults) return;
    R.inResults = true; $('app').classList.remove('landing'); $('app').classList.add('searching'); $('resultsView').classList.remove('hidden');
    UI.pushOverlay(function () { R.inResults = false; if (R.ac) R.ac.aborted = true; R.running = false; $('app').classList.remove('searching'); $('app').classList.add('landing'); $('resultsView').classList.add('hidden'); });
  }

  // ======================================================== 结果列表（往下滑自动加载更多，没有 400 条上限）
  function frag(text, marks, l, r) {
    var f = document.createDocumentFragment(), pos = 0;
    if (l) f.appendChild(document.createTextNode('…'));
    (marks || []).forEach(function (m) {
      if (m[0] > pos) f.appendChild(document.createTextNode(text.slice(pos, m[0])));
      var k = document.createElement('mark'); k.textContent = text.slice(m[0], m[1]); f.appendChild(k); pos = m[1];
    });
    if (pos < text.length) f.appendChild(document.createTextNode(text.slice(pos)));
    if (r) f.appendChild(document.createTextNode('…'));
    return f;
  }
  function card(it, idx) {
    var c = el('div', 'card'); c.dataset.i = idx;
    var meta = el('div', 'meta'), t = el('span', 'ttl'), a = el('span', 'au');
    if (it.kind === 'title' && it.marks) t.appendChild(frag(it.title, it.marks)); else t.textContent = it.title || '（无题）';
    var au = [it.author, it.dynasty].filter(Boolean).join(' · ');
    if (it.kind === 'author' && it.marks) a.appendChild(frag(it.author, it.marks)); else a.textContent = au;
    if (it.kind === 'author' && it.dynasty) a.appendChild(document.createTextNode(' · ' + it.dynasty));
    meta.appendChild(t); if (au) meta.appendChild(a);
    meta.appendChild(txt('span', 'src', it.srcLabel + (it.book && it.srcLabel.indexOf(it.book) < 0 ? ' · ' + it.book : '')));
    c.appendChild(meta);
    if (it.kind === 'content') {
      it.hits.slice(0, 3).forEach(function (h) {
        var box = el('div', 'pair');
        h.lines.forEach(function (ln) { var d = el('div', 'ln'); d.appendChild(frag(ln.t, ln.m, ln.l, ln.r)); box.appendChild(d); });
        if (h.nb) { var n = el('div', 'nb'); n.appendChild(frag(h.nb.t, [], false, h.nb.r)); box.appendChild(n); }
        c.appendChild(box);
      });
    } else {
      if (it.kind === 'dynasty' && it.marks) { var dd = el('div', 'ln'); dd.appendChild(frag(it.dynasty, it.marks)); c.appendChild(dd); }
      var first = (Poem.lines(it.content)[0] || '').slice(0, 30); if (first) c.appendChild(txt('div', 'nb', first));
    }
    c.onclick = function () { Poem.open(R.items, idx, {}); };
    return c;
  }
  function renderMore() {
    var box = $('results'), end = Math.min(R.items.length, R.rendered + PAGE);
    if (R.rendered >= R.items.length) return;
    for (var i = R.rendered; i < end; i++) box.appendChild(card(R.items[i], i));
    R.rendered = end;
    if (Cv.isReady()) Cv.apply(box);
  }

  // ======================================================== 数据库 / 文集 树
  function fmtCount(n) { return n + ' 个文件'; }
  function openTree(kind) {
    var isDb = kind === 'db', sel = {}, rows = [], dl = {}, tree = Src.getTree();
    (isDb ? ST.get('selDb') : ST.get('selCol')).forEach(function (id) { sel[id] = true; });

    function stateOf(ids) { var n = 0; ids.forEach(function (id) { if (sel[id]) n++; }); return n === 0 ? 'none' : n === ids.length ? 'all' : 'part'; }
    function paint(c, s) { c.classList.toggle('on', s === 'all'); c.classList.toggle('part', s === 'part'); }
    function refresh() { rows.forEach(function (r) { paint(r.cb, stateOf(r.ids)); }); }
    function row(cls, ids, label, sub, extra) {
      var r = el('div', 'tr ' + cls), cb = el('span', 'cb'), lab = el('div', 'lab');
      lab.appendChild(txt('div', 'n', label)); if (sub) lab.appendChild(txt('div', 's', sub));
      r.appendChild(cb); r.appendChild(lab); if (extra) r.appendChild(extra);
      rows.push({ cb: cb, ids: ids }); paint(cb, stateOf(ids));
      var toggle = function () { var s = stateOf(ids) === 'all'; ids.forEach(function (id) { if (s) delete sel[id]; else sel[id] = true; }); refresh(); };
      cb.onclick = function (e) { e.stopPropagation(); toggle(); };
      return { el: r, lab: lab, cb: cb, toggle: toggle };
    }
    function dlButton(files) {
      var b = el('button', 'dl'), ids = files.map(function (f) { return f.id; });
      function label() {
        var have = ids.filter(function (id) { return dl[id]; }).length;
        if (have === ids.length) { b.textContent = '已下载 ✓'; b.classList.add('ok'); }
        else { b.classList.remove('ok'); b.textContent = '⬇ ' + mb(files.reduce(function (a, f) { return a + (dl[f.id] ? 0 : f.size); }, 0)); }
      }
      label(); b._relabel = label;
      b.onclick = async function (e) {
        e.stopPropagation();
        var have = ids.filter(function (id) { return dl[id]; });
        if (have.length === ids.length) {
          if (await UI.confirmBox('从手机里删除已下载的 ' + ids.length + ' 个文件？删除后搜索会重新在线读取。', '删除')) {
            for (var i = 0; i < ids.length; i++) { await St.deleteFile(ids[i]); delete dl[ids[i]]; }
            label(); UI.toast('已删除');
          }
          return;
        }
        var todo = files.filter(function (f) { return !dl[f.id]; }), total = todo.reduce(function (a, f) { return a + f.size; }, 0);
        if (total > 30 * 1048576 && !(await UI.confirmBox('将下载 ' + todo.length + ' 个文件，共约 ' + mb(total) + '，保存在手机里供离线搜索。继续吗？', '下载'))) return;
        b.disabled = true; var done = 0;
        for (var j = 0; j < todo.length; j++) {
          try {
            var f = todo[j], got = 0;
            var buf = await Src.fetchBuffer(f, { onBytes: function (n) { got += n; b.textContent = '下载中 ' + mb(done + got) + '/' + mb(total); } });
            await St.putFile({ key: f.id, repo: f.repo, path: f.path }, buf); dl[f.id] = true; done += f.size;
          } catch (err) { UI.toast('下载失败：' + (err.message || err), 4000); break; }
        }
        b.disabled = false; label();
      };
      return b;
    }

    UI.openPage(isDb ? '数据库' : '文集', function (body, api) {
      function redrawDl() { body.querySelectorAll('.dl').forEach(function (b) { if (b._relabel) b._relabel(); }); }
      if (isDb) {
        var all = Src.allFiles(), allIds = all.map(function (f) { return f.id; });
        var top = row('top', allIds, '全部', '全部 ' + all.length + ' 个文件，共 ' + mb(all.reduce(function (a, f) { return a + f.size; }, 0)) + '（搜索前会先告诉你要下载多少）');
        body.appendChild(top.el); top.lab.onclick = top.toggle;
        body.appendChild(txt('p', 'tip', '默认在线搜索：边下载边搜，搜完不保存。想离线搜，点文件右边的 ⬇ 下载到手机。同名的文集（如全宋诗）来自不同的库，都保留，方便互相校对。'));
        tree.forEach(function (repo) {
          var rr = row('', repo.files.map(function (f) { return f.id; }), repo.label, fmtCount(repo.count) + ' · ' + mb(repo.size) + (repo.note ? ' · ' + repo.note : ''));
          var arrow = el('span', 'arrow'); arrow.textContent = '▸'; rr.el.insertBefore(arrow, rr.cb);
          var kids = el('div', 'kids hidden'), built = false;
          rr.lab.onclick = arrow.onclick = function () {
            kids.classList.toggle('hidden'); arrow.textContent = kids.classList.contains('hidden') ? '▸' : '▾';
            if (!built) {
              built = true;
              repo.children.forEach(function (dir) {
                var dr = row('d1', dir.files.map(function (f) { return f.id; }), dir.label, fmtCount(dir.count) + ' · ' + mb(dir.size), dlButton(dir.files));
                var ar = el('span', 'arrow'); ar.textContent = '▸'; dr.el.insertBefore(ar, dr.cb);
                var fk = el('div', 'kids hidden'), fb = false;
                dr.lab.onclick = ar.onclick = function () {
                  fk.classList.toggle('hidden'); ar.textContent = fk.classList.contains('hidden') ? '▸' : '▾';
                  if (!fb) {
                    fb = true;
                    dir.files.forEach(function (f) {
                      var fr = row('d2', [f.id], f.name, mb(f.size) + (f.dynasty ? ' · ' + f.dynasty : '') + (f.book ? ' · ' + f.book : ''), dlButton([f]));
                      fr.lab.onclick = fr.toggle; fk.appendChild(fr.el);
                    });
                    if (Cv.isReady()) Cv.apply(fk);
                  }
                };
                kids.appendChild(dr.el); kids.appendChild(fk);
              });
              if (Cv.isReady()) Cv.apply(kids);
            }
          };
          body.appendChild(rr.el); body.appendChild(kids);
        });
        St.listFiles().then(function (ms) { ms.forEach(function (m) { dl[m.key] = true; }); redrawDl(); }).catch(function () { });
      } else {
        St.getDatasets().then(function (list) {
          var ids = list.map(function (d) { return d.id; });
          var top = row('top', ids, '全部', ids.length ? '全部 ' + ids.length + ' 个文集' : '还没有导入的文集');
          body.appendChild(top.el); top.lab.onclick = top.toggle;
          if (!list.length) body.appendChild(txt('p', 'tip', '导入的文件（设置 → 导入）会出现在这里，可以单独勾选作为搜索范围。'));
          // 分两段：数据库、电子书（电子书以后用 mode=book 区分）
          var groups = [['数据库', list.filter(function (d) { return d.mode !== 'book'; })], ['电子书', list.filter(function (d) { return d.mode === 'book'; })]];
          groups.forEach(function (g) {
            if (!g[1].length) return;
            body.appendChild(txt('div', 'tip', '—— ' + g[0] + '（' + g[1].length + '）——'));
            g[1].forEach(function (d) {
              var del = el('button', 'dl'); del.textContent = '删除';
              var r = row('d1', [d.id], d.name, (d.count || 0) + ' 条' + (d.mode === 'book' ? '（整本书）' : ''), del);
              r.lab.onclick = r.toggle;
              del.onclick = async function (e) { e.stopPropagation(); if (await UI.confirmBox('删除文集"' + d.name + '"？只删手机里导入的这份，原文件不受影响。', '删除')) { await St.deleteDataset(d.id); delete sel[d.id]; r.el.remove(); ST.set('selCol', ST.get('selCol').filter(function (x) { return x !== d.id; })); } };
              body.appendChild(r.el);
            });
          });
          if (Cv.isReady()) Cv.apply(body);
        });
      }
      api.finish = function () {
        var ids = Object.keys(sel).filter(function (k) { return sel[k]; });
        if (isDb) ST.set('selDb', ids.filter(function (id) { return Src.getFile(id); })); else ST.set('selCol', ids);
        UI.toast('已选 ' + ids.length + ' 项'); api.close();
      };
    }, { actions: [{ label: '完成', fn: function (api) { api.finish(); } }] });
  }

  // ======================================================== 诗词网站、搜索引擎、收藏
  function browserView(key) { try { return localStorage.getItem('ps.browser.view.' + key) === 'tile'; } catch (e) { return false; } }
  function saveBrowserView(key, tile) { try { localStorage.setItem('ps.browser.view.' + key, tile ? 'tile' : 'list'); } catch (e) { /* 记忆失败不影响切换 */ } }
  function browserSeeds(items, group, query, makeUrl) {
    var seen = {};
    return items.map(function (it, i) {
      var raw = String(it.id || ((it.name || '网页') + '|' + (it.url || ''))), n = seen[raw] || 0;
      seen[raw] = n + 1;
      return { id: encodeURIComponent(raw) + '~' + n, title: it.name || '网页', url: makeUrl(it), mode: Cv.getMode(), variant: Cv.getVariant(), query: query || '' };
    });
  }
  function browserCount(group, base) { return Math.max(0, base + (N.browserExtraTabCount ? N.browserExtraTabCount(group) : 0)); }
  function addAction(label, aria, callback) {
    var b = el('button', 'list-add'); b.textContent = '＋'; b.setAttribute('aria-label', aria); b.onclick = callback; return b;
  }
  function openSites() {
    var tile = browserView('poetry');
    UI.openPage('诗词网站', function (body) {
      function draw() {
        var items = ST.get('sites');
        body.innerHTML = ''; body.classList.toggle('tile-mode', tile);
        var seeds = browserSeeds(items, 'poetry', '', function (s) { return s.url; });
        items.forEach(function (s, i) {
          var r = el('button', 'row'); r.appendChild(txt('div', 'row-t', s.name)); r.appendChild(txt('div', 'row-s', s.url));
          r.onclick = function () { N.openBrowser(s.url, s.name, Cv.getMode(), Cv.getVariant(), '', 'poetry', seeds, seeds[i].id); };
          body.appendChild(r);
        });
        var add = addAction('＋', '添加诗词网站', function () { if (root.PSApp.openSiteEditor) root.PSApp.openSiteEditor(function () { draw(); }); else root.PSApp.openSettings(); });
        add.className = tile ? 'tile-add' : 'list-add'; body.appendChild(add);
        if (root.PSApp.refreshBrowserCounts) root.PSApp.refreshBrowserCounts();
      }
      body._drawTiles = function () { tile = !tile; saveBrowserView('poetry', tile); draw(); };
      draw();
    }, { actions: [{ label: function () { return String(browserCount('poetry', ST.get('sites').length)); }, className: 'count-square', ariaLabel: '网页数量；点击切换列表和方块', dataGroup: 'poetry', fn: function (api) { if (api.body._drawTiles) api.body._drawTiles(); } }] });
  }
  function openLookupSites() {
    var tile = browserView('lookup');
    UI.openPage('查词找字', function (body) {
      function draw() {
        var items = ST.get('lookupSites') || [];
        body.innerHTML = ''; body.classList.toggle('tile-mode', tile);
        var seeds = browserSeeds(items, 'lookup', '', function (site) { return site.url; });
        items.forEach(function (site, i) {
          var r = el('button', 'row'); r.appendChild(txt('div', 'row-t', site.name)); r.appendChild(txt('div', 'row-s', site.url));
          r.onclick = function () { N.openBrowser(site.url, site.name, Cv.getMode(), Cv.getVariant(), '', 'lookup', seeds, seeds[i].id); };
          body.appendChild(r);
        });
        var add = addAction('＋', '添加查词找字网站', function () { if (root.PSApp.openLookupEditor) root.PSApp.openLookupEditor(function () { draw(); }); else root.PSApp.openSettings(); });
        add.className = tile ? 'tile-add' : 'list-add'; body.appendChild(add);
        if (root.PSApp.refreshBrowserCounts) root.PSApp.refreshBrowserCounts();
      }
      body._drawTiles = function () { tile = !tile; saveBrowserView('lookup', tile); draw(); };
      draw();
    }, { actions: [{ label: function () { return String(browserCount('lookup', (ST.get('lookupSites') || []).length)); }, className: 'count-square', ariaLabel: '网页数量；点击切换列表和方块', dataGroup: 'lookup', fn: function (api) { if (api.body._drawTiles) api.body._drawTiles(); } }] });
  }
  function engineOpts() { return { local: ST.get('engineLocal'), noAI: ST.get('googleNoAI'), conv: ST.get('engineConv'), convert: Cv }; }
  function openEngines() {
    var tile = browserView('engine');
    UI.openPage('搜索引擎', function (body) {
      function draw() {
        var items = ST.get('engines'), q = $('q').value.trim();
        body.innerHTML = ''; body.classList.toggle('tile-mode', tile);
        var seeds = browserSeeds(items, 'engine', q, function (e) { return Eng.build(e, q, engineOpts()); });
        items.forEach(function (e, i) {
          var url = Eng.build(e, q, engineOpts()), r = el('button', 'row');
          r.appendChild(txt('div', 'row-t', e.name)); var sub = txt('div', 'row-s', url.replace(/^https?:\/\//, '')); r.appendChild(sub);
          if (ST.get('engineConv') !== false && /^(?:google|yahoo)-(?:hk|tw)$/.test(e.id || '') && !Cv.isReady()) {
            (function waitConv(n) { if (Cv.isReady()) { sub.textContent = Eng.build(e, q, engineOpts()).replace(/^https?:\/\//, ''); } else if (n > 0) setTimeout(function () { waitConv(n - 1); }, 300); })(20);
          }
          r.onclick = async function () {
            var liveQ = $('q').value.trim();
            if (ST.get('engineConv') !== false && /^(?:google|yahoo)-(?:hk|tw)$/.test(e.id || '') && !Cv.isReady()) {
              UI.toast('正在准备繁体转换…', 1500);
              var t0 = Date.now();
              while (!Cv.isReady() && Date.now() - t0 < 4000) { await new Promise(function (r2) { setTimeout(r2, 150); }); }
              if (!Cv.isReady()) { UI.toast('繁体转换尚未就绪，已暂时取消港台搜索，避免直接发送简体关键词。', 4000); return; }
            }
            items = ST.get('engines');
            seeds = browserSeeds(items, 'engine', liveQ, function (item) { return Eng.build(item, liveQ, engineOpts()); });
            var at = items.indexOf(e), seed = seeds[at] || seeds[i];
            var targetUrl = Eng.build(e, liveQ, engineOpts());
            N.openBrowser(targetUrl, e.name, Cv.getMode(), Cv.getVariant(), liveQ, 'engine', seeds, seed && seed.id);
          };
          body.appendChild(r);
        });
        var add = addAction('＋', '添加搜索引擎', function () { if (root.PSApp.openEngineEditor) root.PSApp.openEngineEditor(function () { draw(); }); else root.PSApp.openSettings(); });
        add.className = tile ? 'tile-add' : 'list-add'; body.appendChild(add);
        if (root.PSApp.refreshBrowserCounts) root.PSApp.refreshBrowserCounts();
      }
      body._drawTiles = function () { tile = !tile; saveBrowserView('engine', tile); draw(); };
      draw();
    }, { actions: [{ label: function () { return String(browserCount('engine', ST.get('engines').length)); }, className: 'count-square', ariaLabel: '网页数量；点击切换列表和方块', dataGroup: 'engine', fn: function (api) { if (api.body._drawTiles) api.body._drawTiles(); } }] });
  }
  function refreshBrowserCounts() {
    Array.prototype.forEach.call(document.querySelectorAll('.count-square[data-group]'), function (b) {
      var group = b.getAttribute('data-group'), base = group === 'poetry' ? ST.get('sites').length : (group === 'lookup' ? (ST.get('lookupSites') || []).length : ST.get('engines').length);
      b.textContent = String(browserCount(group, base));
    });
  }
  // 收藏：两个文件夹"整首""部分"；进去是连续列表（照搜索结果的方式）；点一条进诗页
  function openFavs() {
    UI.openPage('收藏', function (body) { home(body); });
    function home(body) {
      body.innerHTML = '';
      ['整首', '部分'].forEach(function (name, idx) {
        var r = el('button', 'row'); r.appendChild(txt('div', 'row-t', name));
        r.onclick = function () { list(body, idx === 0 ? 'whole' : 'part', name); };
        body.appendChild(r);
      });
      if (Cv.isReady()) Cv.apply(body);
    }
    async function list(body, kind, name) {
      UI.openPage(name, function (b2) {
        b2.innerHTML = '';
        St.listFavs().then(function (all) {
          var items = all.filter(function (f) { return (f.kind || 'whole') === kind; });
          if (!items.length) { b2.appendChild(txt('p', 'tip', kind === 'whole' ? '还没有收藏整首诗。打开一首诗，连续点两下，再点"整首"。' : '还没有收藏句子。在诗里选中文字，再点"部分"。')); return; }
          var poems = items.map(function (f) { return f.poem; });
          items.forEach(function (f, i) {
            var p = f.poem, r = el('button', 'row');
            if (kind === 'part') r.appendChild(txt('div', 'row-t', f.text || ''));
            else r.appendChild(txt('div', 'row-t', p.title || '（无题）'));
            r.appendChild(txt('div', 'row-s', [p.author, p.dynasty, p.srcLabel].filter(Boolean).join(' · ') + '  ' + (Poem.lines(p.content)[0] || '')));
            r.onclick = function () { Poem.open(poems, i, { onClose: function () { } }); };
            b2.appendChild(r);
          });
          if (Cv.isReady()) Cv.apply(b2);
        });
      });
    }
  }

  root.PSApp = { boot: boot, startSearch: startSearch, mb: mb, openTree: openTree, refreshBrowserCounts: refreshBrowserCounts, _R: R };
})(window);
