package com.example.poetry;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;

/** 在 App 内打开网站：上面一条工具栏（返回、标题、简／繁、关闭），下面是网页。简／繁按钮把整个网页的文字一键转换。 */
public class WebActivity extends Activity {
    private static WebActivity active;
    private static final ArrayList<TabState> tabs = new ArrayList<>();
    private static boolean tabsLoaded = false;
    private static final String TAB_PREFS = "web_tabs_state", TAB_PREF_KEY = "tabs_v1";
    private static class TabState {
        String id, group, url, startUrl, searchUrl, title, mode, variant, query, parentId;
        int scrollY; boolean primary, visited;
        TabState(String i, String g, String u, String t, String m, String v, String q, boolean p, String parent) {
            id = i; group = g; url = u; startUrl = u; searchUrl = u; title = t; mode = m; variant = v; query = q; primary = p; parentId = parent;
        }
    }
    private WebView w;
    private TextView titleV, convBtn, tabsBtn;
    private ScrollView tabOverview;
    private LinearLayout tabGrid;
    private String tabKey = "", currentGroup = "external";
    private String mode = "s", variant = "std", title = "";
    private String searchQuery = "", searchUrl = "";
    private boolean haveT2 = false, haveC2 = false, haveInject = false;
    private boolean skipConv = false;

    public static void open(Activity from, String url, String title, String mode, String variant, String query) {
        open(from, url, title, mode, variant, query, "", "[]", "");
    }

    public static void open(Activity from, String url, String title, String mode, String variant, String query, String group, String seeds, String tabId) {
        if (active != null && !active.isFinishing()) { active.openRequest(url, title, mode, variant, query, group, seeds, tabId); return; }
        Intent i = new Intent(from, WebActivity.class);
        i.putExtra("url", url); i.putExtra("title", title == null ? "" : title);
        i.putExtra("mode", mode == null ? "s" : mode); i.putExtra("variant", variant == null ? "std" : variant);
        i.putExtra("query", query == null ? "" : query); i.putExtra("group", group == null ? "" : group);
        i.putExtra("seeds", seeds == null ? "[]" : seeds); i.putExtra("tabId", tabId == null ? "" : tabId);
        from.startActivity(i);
    }

    private int dp(int v) {
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics()));
    }

    private boolean isZdicHost(String host) {
        return host != null && ("zdic.net".equalsIgnoreCase(host) || host.toLowerCase().endsWith(".zdic.net"));
    }

    private TextView button(String text, int sizeSp) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sizeSp);
        t.setTextColor(0xFF1D1A16);
        t.setGravity(Gravity.CENTER);
        t.setMinWidth(dp(48));
        t.setPadding(dp(8), 0, dp(8), 0);
        return t;
    }

    @Override
    @SuppressWarnings("deprecation")
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        active = this;
        Intent in = getIntent();
        String url = in.getStringExtra("url");
        String requestTitle = in.getStringExtra("title");
        if (requestTitle == null) requestTitle = "";
        title = requestTitle;
        currentGroup = in.getStringExtra("group");
        if (currentGroup == null || currentGroup.length() == 0) currentGroup = "external";
        mode = "t".equals(in.getStringExtra("mode")) ? "t" : "s";
        String v = in.getStringExtra("variant");
        variant = (v == null || v.length() == 0) ? "std" : v;
        String requestQuery = in.getStringExtra("query");
        if (requestQuery == null) requestQuery = "";
        String seedJson = in.getStringExtra("seeds");
        if (seedJson == null) seedJson = "[]";
        String requestedTabId = in.getStringExtra("tabId");
        if (requestedTabId == null) requestedTabId = "";

        Window win = getWindow();
        if (Build.VERSION.SDK_INT >= 28) {
            WindowManager.LayoutParams lp = win.getAttributes();
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            win.setAttributes(lp);
        }
        win.setStatusBarColor(Color.TRANSPARENT);
        win.setNavigationBarColor(Color.TRANSPARENT);
        if (Build.VERSION.SDK_INT >= 30) win.setDecorFitsSystemWindows(false);
        int flags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION;
        if (Build.VERSION.SDK_INT >= 23) flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
        win.getDecorView().setSystemUiVisibility(flags);

        final LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFFF3ECDC);

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackgroundColor(0xFFFAF6EE);

        TextView back = button("‹", 28);
        back.setOnClickListener(new View.OnClickListener() { public void onClick(View x) { onBackPressed(); } });
        titleV = new TextView(this);
        titleV.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        titleV.setTextColor(0xFF1D1A16);
        titleV.setSingleLine(true);
        titleV.setEllipsize(TextUtils.TruncateAt.END);
        titleV.setText(title);
        convBtn = button("t".equals(mode) ? "繁" : "简", 20);
        convBtn.setTypeface(Typeface.DEFAULT_BOLD);
        convBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View x) {
                mode = "t".equals(mode) ? "s" : "t";
                convBtn.setText("t".equals(mode) ? "繁" : "简");
                TabState state = findTab(tabKey); if (state != null) { state.mode = mode; state.variant = variant; saveTabs(WebActivity.this); }
                applyConv();
                syncSearchQuery();
            }
        });
        tabsBtn = button("0", 16);
        GradientDrawable countBg = new GradientDrawable(); countBg.setColor(0xFFFAF6EE); countBg.setCornerRadius(dp(8)); countBg.setStroke(dp(1), 0xFF5B5143);
        tabsBtn.setBackground(countBg); tabsBtn.setContentDescription("网页标签数量；点击查看方块总览");
        tabsBtn.setOnClickListener(new View.OnClickListener() { public void onClick(View x) { toggleTabs(); } });
        TextView close = button("✕", 18);
        close.setOnClickListener(new View.OnClickListener() { public void onClick(View x) { saveCurrentPage(); saveTabs(WebActivity.this); finish(); } });

        bar.addView(back, new LinearLayout.LayoutParams(dp(52), dp(48)));
        bar.addView(titleV, new LinearLayout.LayoutParams(0, dp(48), 1f));
        bar.addView(tabsBtn, new LinearLayout.LayoutParams(dp(48), dp(48)));
        bar.addView(convBtn, new LinearLayout.LayoutParams(dp(56), dp(48)));
        bar.addView(close, new LinearLayout.LayoutParams(dp(52), dp(48)));

        w = new WebView(this);
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);   // 视频和声音不用先点一下，能自动播（开屏要用）
        s.setDomStorageEnabled(true);
        String ua0 = s.getUserAgentString();                // 去掉 WebView 标记，让网站按普通浏览器打开
        if (ua0 != null) s.setUserAgentString(ua0.replace("; wv", "").replace("Version/4.0 ", ""));
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        w.addJavascriptInterface(new BrowserBridge(), "PSBrowser");
        w.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                String sc = r.getUrl().getScheme();
                return !("http".equals(sc) || "https".equals(sc));      // 网页里的普通链接都留在这里打开
            }

            @Override
            public void onPageStarted(WebView v, String u, android.graphics.Bitmap f) {
                haveT2 = false; haveC2 = false; haveInject = false;     // 每个新页面都要重新装转换程序
                TabState state = findTab(tabKey);
                if (state != null) {
                    if (!TextUtils.equals(state.url, u)) state.scrollY = 0;
                    state.url = u; state.visited = true; saveTabs(WebActivity.this); updateTabsButton();
                }
            }

            @Override
            public void onPageFinished(WebView v, String u) {
                String t = v.getTitle();
                if (t != null && t.length() > 0) { titleV.setText(t); TabState state = findTab(tabKey); if (state != null) state.title = t; }
                try { skipConv = isZdicHost(android.net.Uri.parse(u).getHost()); } catch (Exception ignored) { }
                if (!skipConv) applyConv();
                TabState saved = findTab(tabKey);
                if (saved != null && saved.scrollY > 0) v.postDelayed(() -> v.scrollTo(0, saved.scrollY), 120);
                installNewTabHook(); saveTabs(WebActivity.this); updateTabsButton();
            }
        });

        root.addView(bar, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        root.addView(w, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        tabOverview = new ScrollView(this); tabOverview.setFillViewport(true); tabOverview.setVisibility(View.GONE);
        tabGrid = new LinearLayout(this); tabGrid.setOrientation(LinearLayout.VERTICAL); tabGrid.setPadding(dp(10), dp(10), dp(10), dp(18));
        tabOverview.addView(tabGrid, new ScrollView.LayoutParams(ScrollView.LayoutParams.MATCH_PARENT, ScrollView.LayoutParams.WRAP_CONTENT));
        root.addView(tabOverview, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);
        root.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override
            public WindowInsets onApplyWindowInsets(View v, WindowInsets in) {
                int top = in.getSystemWindowInsetTop();
                if (Build.VERSION.SDK_INT >= 28 && in.getDisplayCutout() != null) top = Math.max(top, in.getDisplayCutout().getSafeInsetTop());
                root.setPadding(0, top, 0, in.getSystemWindowInsetBottom());
                return in;
            }
        });
        loadTabs(this);
        ensureGroupSeeds(currentGroup, seedJson);
        openRequested(url, requestTitle, mode, variant, requestQuery, currentGroup, requestedTabId);
        updateTabsButton();
    }

    private static synchronized void loadTabs(Context context) {
        if (tabsLoaded) return;
        tabsLoaded = true;
        tabs.clear();
        try {
            String saved = context.getSharedPreferences(TAB_PREFS, MODE_PRIVATE).getString(TAB_PREF_KEY, "[]");
            JSONArray a = new JSONArray(saved);
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.optJSONObject(i); if (o == null) continue;
                String id = o.optString("id", ""), group = o.optString("group", "external"), url = o.optString("url", "");
                if (id.length() == 0 || url.length() == 0) continue;
                TabState t = new TabState(id, group, url, o.optString("title", "网页"), o.optString("mode", "s"), o.optString("variant", "std"), o.optString("query", ""), o.optBoolean("primary", false), o.optString("parentId", ""));
                t.startUrl = o.optString("startUrl", url); t.searchUrl = o.optString("searchUrl", t.startUrl);
                t.scrollY = Math.max(0, o.optInt("scrollY", 0)); t.visited = o.optBoolean("visited", false);
                tabs.add(t);
            }
        } catch (Exception ignored) { tabs.clear(); }
    }

    private static synchronized void saveTabs(Context context) {
        try {
            JSONArray a = new JSONArray();
            for (TabState t : tabs) {
                JSONObject o = new JSONObject();
                o.put("id", t.id); o.put("group", t.group); o.put("url", t.url); o.put("startUrl", t.startUrl); o.put("searchUrl", t.searchUrl);
                o.put("title", t.title); o.put("mode", t.mode); o.put("variant", t.variant); o.put("query", t.query);
                o.put("parentId", t.parentId); o.put("scrollY", t.scrollY); o.put("primary", t.primary); o.put("visited", t.visited); a.put(o);
            }
            context.getSharedPreferences(TAB_PREFS, MODE_PRIVATE).edit().putString(TAB_PREF_KEY, a.toString()).apply();
        } catch (Exception ignored) { }
    }

    public static int extraTabCount(Context context, String group) {
        int n = 0;
        try {
            JSONArray a = new JSONArray(context.getSharedPreferences(TAB_PREFS, MODE_PRIVATE).getString(TAB_PREF_KEY, "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.optJSONObject(i);
                if (o != null && group.equals(o.optString("group", "")) && !o.optBoolean("primary", false)) n++;
            }
        } catch (Exception ignored) { }
        return n;
    }

    private boolean sameEndpoint(String a, String b) {
        try {
            android.net.Uri x = android.net.Uri.parse(a), y = android.net.Uri.parse(b);
            return TextUtils.equals(x.getScheme(), y.getScheme()) && TextUtils.equals(x.getHost(), y.getHost()) && TextUtils.equals(x.getPath(), y.getPath());
        } catch (Exception e) { return TextUtils.equals(a, b); }
    }

    private void ensureGroupSeeds(String group, String json) {
        JSONArray a;
        try { a = new JSONArray(json == null ? "[]" : json); } catch (Exception e) { a = new JSONArray(); }
        HashSet<String> keep = new HashSet<>();
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i); if (o == null) continue;
            String seedId = o.optString("id", ""), url = o.optString("url", ""), name = o.optString("title", "网页");
            if (seedId.length() == 0 || !(url.startsWith("http://") || url.startsWith("https://"))) continue;
            String id = group + ":" + seedId; keep.add(id);
            TabState t = findTab(id);
            String seedMode = "t".equals(o.optString("mode", "s")) ? "t" : "s", seedVariant = o.optString("variant", "std"), seedQuery = o.optString("query", "");
            if (t == null) {
                t = new TabState(id, group, url, name, seedMode, seedVariant, seedQuery, true, ""); tabs.add(t);
            } else {
                t.title = name;
                if (!sameEndpoint(t.startUrl, url) || !t.visited) {
                    t.url = url; t.startUrl = url; t.searchUrl = url; t.query = seedQuery; t.scrollY = 0;
                    if (!t.visited) { t.mode = seedMode; t.variant = seedVariant; }
                    t.visited = false;
                }
            }
        }
        HashSet<String> removed = new HashSet<>();
        Iterator<TabState> it = tabs.iterator();
        while (it.hasNext()) {
            TabState t = it.next();
            if (t.group.equals(group) && t.primary && !keep.contains(t.id)) {
                removed.add(t.id); it.remove();
            }
        }
        Iterator<TabState> child = tabs.iterator(); while (child.hasNext()) if (removed.contains(child.next().parentId)) child.remove();
        saveTabs(this);
    }

    private String newTabId(String group) { return group + ":extra:" + System.nanoTime() + ":" + tabs.size(); }

    private TabState makeExtra(String group, String url, String name, String m, String v, String q, String parentId) {
        TabState t = new TabState(newTabId(group), group, url, name == null || name.length() == 0 ? "网页" : name, "t".equals(m) ? "t" : "s", v == null ? "std" : v, q == null ? "" : q, false, parentId == null ? "" : parentId);
        tabs.add(t); saveTabs(this); return t;
    }

    private void openRequest(String url, String name, String newMode, String newVariant, String query, String group, String seeds, String seedId) {
        if (url == null || !(url.startsWith("http://") || url.startsWith("https://")) || w == null) return;
        saveCurrentPage();
        String g = group == null || group.length() == 0 ? currentGroup : group;
        if (g == null || g.length() == 0) g = "external";
        if (seeds != null && seeds.trim().length() > 2) ensureGroupSeeds(g, seeds);
        openRequested(url, name, newMode, newVariant, query, g, seedId);
    }

    private void openRequested(String url, String name, String newMode, String newVariant, String query, String group, String seedId) {
        if (url == null || !(url.startsWith("http://") || url.startsWith("https://"))) return;
        TabState target = null;
        if (seedId != null && seedId.length() > 0) {
            TabState base = findTab(group + ":" + seedId);
            if (base != null) {
                if (base.visited && !url.equals(base.startUrl)) {
                    for (TabState t : tabs) if (!t.primary && group.equals(t.group) && base.id.equals(t.parentId) && url.equals(t.startUrl)) { target = t; break; }
                    if (target == null) target = makeExtra(group, url, name, newMode, newVariant, query, base.id);
                } else {
                    target = base;
                    if (!base.visited) { base.url = url; base.startUrl = url; base.searchUrl = url; base.query = query == null ? "" : query; base.mode = "t".equals(newMode) ? "t" : "s"; base.variant = newVariant == null ? "std" : newVariant; }
                }
            }
        }
        if (target == null) target = makeExtra(group, url, name, newMode, newVariant, query, "");
        switchTo(target);
    }

    private void saveCurrentPage() {
        if (w == null || tabKey.length() == 0) return;
        TabState t = findTab(tabKey); if (t == null) return;
        String u = w.getUrl(); if (u != null && (u.startsWith("http://") || u.startsWith("https://"))) t.url = u;
        String pageTitle = w.getTitle(); if (pageTitle != null && pageTitle.length() > 0) t.title = pageTitle;
        t.scrollY = Math.max(0, w.getScrollY()); t.mode = mode; t.variant = variant; t.query = searchQuery; t.searchUrl = searchUrl;
        saveTabs(this);
    }

    private void switchTo(TabState t) {
        if (t == null) return;
        boolean same = t.id.equals(tabKey);
        saveCurrentPage();
        currentGroup = t.group; tabKey = t.id; mode = "t".equals(t.mode) ? "t" : "s"; variant = t.variant == null ? "std" : t.variant;
        searchQuery = t.query == null ? "" : t.query; searchUrl = t.searchUrl == null ? t.startUrl : t.searchUrl; title = t.title == null ? "网页" : t.title;
        titleV.setText(title); convBtn.setText("t".equals(mode) ? "繁" : "简");
        if (tabOverview != null) { tabOverview.setVisibility(View.GONE); w.setVisibility(View.VISIBLE); }
        if (!same || !TextUtils.equals(w.getUrl(), t.url)) {
            haveT2 = false; haveC2 = false; haveInject = false;
            try { skipConv = isZdicHost(android.net.Uri.parse(t.url).getHost()); } catch (Exception ignored) { skipConv = false; }
            w.loadUrl(t.url);
        } else if (!skipConv) applyConv();
        updateTabsButton(); saveTabs(this);
    }

    private void toggleTabs() {
        if (tabOverview == null) return;
        if (tabOverview.getVisibility() == View.VISIBLE) { tabOverview.setVisibility(View.GONE); w.setVisibility(View.VISIBLE); return; }
        renderTabGrid(); saveCurrentPage(); w.setVisibility(View.GONE); tabOverview.setVisibility(View.VISIBLE);
    }

    private void renderTabGrid() {
        tabGrid.removeAllViews();
        ArrayList<TabState> visible = new ArrayList<>();
        for (TabState t : tabs) if (currentGroup.equals(t.group)) visible.add(t);
        for (int i = 0; i < visible.size(); i += 2) {
            LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL);
            for (int col = 0; col < 2; col++) {
                if (i + col >= visible.size()) { row.addView(new View(this), new LinearLayout.LayoutParams(0, dp(108), 1f)); continue; }
                final TabState t = visible.get(i + col);
                String shownUrl = t.url.length() > 76 ? t.url.substring(0, 73) + "…" : t.url;
                TextView card = button((t.id.equals(tabKey) ? "● " : "") + t.title + "\n" + shownUrl, 13);
                card.setGravity(Gravity.CENTER); card.setMaxLines(4); card.setEllipsize(TextUtils.TruncateAt.END); card.setMinHeight(dp(108));
                card.setPadding(dp(8), dp(6), dp(8), dp(6));
                GradientDrawable bg = new GradientDrawable(); bg.setColor(0xFFFAF6EE); bg.setCornerRadius(dp(10)); bg.setStroke(dp(1), 0xFFCEC3B2); card.setBackground(bg);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(108), 1f); lp.setMargins(dp(4), dp(4), dp(4), dp(4)); row.addView(card, lp);
                card.setOnClickListener(v -> switchTo(t));
            }
            tabGrid.addView(row, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        }
    }

    private void updateTabsButton() {
        if (tabsBtn == null) return;
        int n = 0; for (TabState t : tabs) if (currentGroup.equals(t.group)) n++;
        tabsBtn.setText(String.valueOf(n));
    }

    private void installNewTabHook() {
        if (w == null) return;
        String js = "(function(){try{if(window.__psTabHook)return;window.__psTabHook=true;var send=function(u){try{var x=new URL(u,location.href).href;if(/^https?:\\/\\//i.test(x)&&window.PSBrowser)PSBrowser.openTab(x)}catch(e){}};window.open=function(u){send(u);return null};document.addEventListener('click',function(e){var a=e.target;while(a&&a.tagName!=='A')a=a.parentElement;if(a&&a.target&&a.target.toLowerCase()==='_blank'){e.preventDefault();send(a.href)}},true)}catch(e){}})();";
        w.evaluateJavascript(js, null);
    }

    private class BrowserBridge {
        @android.webkit.JavascriptInterface public void openTab(final String url) {
            runOnUiThread(() -> {
                if (url == null || !(url.startsWith("http://") || url.startsWith("https://"))) return;
                saveCurrentPage(); TabState t = makeExtra(currentGroup, url, "网页", mode, variant, "", ""); switchTo(t);
            });
        }
    }

    private TabState findTab(String id) { for (TabState t : tabs) if (t.id.equals(id)) return t; return null; }

    private String asset(String name) {
        try {
            InputStream in = getAssets().open(name);
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[65536];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            in.close();
            return out.toString("UTF-8");
        } catch (Exception e) {
            return "";
        }
    }

    // OpenCC 的脚本带"模块定义"，有些网站自己也有 define，会抢走它；所以包一层，把 define / module / exports 屏蔽掉
    private String wrapLib(String text, String globalName) {
        return "(function(define,module,exports){" + text + "\n})(undefined,undefined,undefined);window." + globalName + "=window.OpenCC;";
    }

    private void applyConv() {
        if (w == null || skipConv) return;
        if ("t".equals(mode)) {
            if (!haveC2) { w.evaluateJavascript(wrapLib(asset("vendor/opencc/cn2t.js"), "__cn2t"), null); haveC2 = true; }
        } else {
            if (!haveT2) { w.evaluateJavascript(wrapLib(asset("vendor/opencc/t2cn.js"), "__t2cn"), null); haveT2 = true; }
        }
        if (!haveInject) { w.evaluateJavascript(asset("js/convert-inject.js"), null); haveInject = true; }
        w.evaluateJavascript("window.__psConv&&window.__psConv('" + mode + "','" + variant + "')", null);
    }

    private void syncSearchQuery() {
        if (w == null || searchUrl.length() == 0) return;
        String current = searchQuery;
        try {
            android.net.Uri u = android.net.Uri.parse(searchUrl);
            String[] keys = new String[]{"q", "p", "wd", "query"};
            for (String k : keys) { String v = u.getQueryParameter(k); if (v != null && v.length() > 0) { current = v; break; } }
        } catch (Exception ignored) { }
        if (current.length() == 0) return;
        final String oldQuery = current;
        String js = "window.__psConvertText&&window.__psConvertText(" + org.json.JSONObject.quote(oldQuery) + ")";
        w.evaluateJavascript(js, value -> {
            try {
                Object out = new JSONTokener(value == null ? "null" : value).nextValue();
                if (!(out instanceof String)) return;
                String converted = (String) out;
                if (converted.length() == 0 || converted.equals(oldQuery)) return;
                String oldEsc = android.net.Uri.encode(oldQuery);
                String newEsc = android.net.Uri.encode(converted);
                String next = searchUrl.replace(oldEsc, newEsc);
                if (!next.equals(searchUrl)) {
                    searchQuery = converted; searchUrl = next; w.loadUrl(next);
                    TabState state = findTab(tabKey); if (state != null) { state.query = converted; state.searchUrl = next; saveTabs(WebActivity.this); }
                }
            } catch (Exception ignored) { }
        });
    }

    @Override
    public void onBackPressed() {
        if (tabOverview != null && tabOverview.getVisibility() == View.VISIBLE) { toggleTabs(); return; }
        if (w != null && w.canGoBack()) w.goBack(); else { saveCurrentPage(); saveTabs(this); finish(); }
    }

    @Override
    protected void onPause() {
        saveCurrentPage(); saveTabs(this);
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        saveCurrentPage(); saveTabs(this);
        if (active == this) active = null;
        if (w != null) { w.stopLoading(); w.destroy(); w = null; }
        super.onDestroy();
    }
}
