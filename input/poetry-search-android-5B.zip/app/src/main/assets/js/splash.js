/* splash.js — 开屏：每次打开 App 先播"当前开屏"，播完或超过 30 秒就进首页。
 * GIF 直接显示；MP4、MKV 用视频标签播。播不了就提示换成 MP4，并直接进首页，不卡住。
 * 没有开屏文件，就直接进首页。浏览器里挂在 window.PSSplash。 */
(function (root) {
  'use strict';
  var MAX_MS = 30000;
  var layer = null, timer = null, done = false, onFinish = null;

  function kindOf(name) {
    var m = String(name || '').toLowerCase().match(/\.([a-z0-9]+)$/);
    var ext = m ? m[1] : '';
    if (ext === 'gif') return 'gif';
    if (ext === 'mp4' || ext === 'mkv') return 'video';
    return null;
  }

  function finish(reason) {
    if (done) return;
    done = true;
    if (timer) { clearTimeout(timer); timer = null; }
    if (layer) { layer.remove(); layer = null; }
    if (onFinish) { var f = onFinish; onFinish = null; f(reason); }
  }

  function fail(msg) {
    var m = document.getElementById('splashMsg');
    if (m) m.textContent = msg;
    setTimeout(function () { finish('fail'); }, 1800);
  }

  // play(force)：force = true 时是设置里"播放看看"，播完只关闭播放层，不跳进首页
  function play(force) {
    var sp = root.PSSettings.get('splash') || {};
    sp = { url: root.PSNative ? root.PSNative.toPageUrl(sp.url) : sp.url, name: sp.name };
    if (!sp.url) { if (!force) finish('none'); return; }
    var k = kindOf(sp.name);
    if (!k) { if (!force) finish('none'); return; }
    done = false;
    // 整层先建好，但不挂到页面上；视频就绪后才挂，避免黑屏一闪就没
    layer = document.createElement('div');
    layer.id = 'splashLayer';
    layer.style.cssText = 'position:fixed;top:0;left:0;right:0;bottom:0;width:100vw;height:100vh;z-index:5000;overflow:hidden;background:#000;';
    var msg = document.createElement('div');
    msg.id = 'splashMsg';
    msg.style.cssText = 'position:absolute;bottom:40px;left:0;right:0;text-align:center;color:#5b5143;font-size:14px;';
    var media = null;
    if (k === 'gif') {
      media = new Image();
      media.src = sp.url;
      media.style.cssText = 'position:absolute;top:0;left:0;width:100%;height:100%;object-fit:cover;';
      media.onerror = function () { fail('开屏图片打不开，已跳过。'); };
    } else {
      media = document.createElement('video');
      media.src = sp.url;
      media.playsInline = true;
      media.muted = true;
      media.preload = 'auto';
      media.style.cssText = 'position:absolute;top:0;left:0;width:100%;height:100%;object-fit:cover;background:#000;';
      media.onended = function () { finish('ended'); };
      media.onerror = function () { fail('这个视频播不了（可能是 MKV 格式）。请换成 MP4 再试。'); };
    }
    layer.appendChild(media);
    // 跳过按钮放在最后加进去，保证在视频之上
    var skip = document.createElement('button');
    skip.textContent = '跳过';
    skip.style.cssText = 'position:absolute;z-index:10;top:calc(env(safe-area-inset-top,0px) + 12px);right:12px;border:none;background:rgba(20,17,12,.5);color:#fff;border-radius:16px;padding:6px 14px;';
    skip.onclick = function (e) { if (e) e.stopPropagation(); finish('skip'); };
    layer.appendChild(skip);
    layer.appendChild(msg);
    // 整层点击也能跳过（按钮被原生层盖住时的兜底）
    layer.addEventListener('click', function () { finish('skip'); });

    var mounted = false;
    function mount() {
      if (mounted || done || !layer) return;
      mounted = true;
      document.body.appendChild(layer);
      if (k !== 'gif') { try { media.play(); } catch (e) { /* 忽略 */ } }
    }
    if (k === 'gif') {
      media.onload = mount;
      setTimeout(function () { if (!done) finish('gif-end'); }, Math.min(MAX_MS, 6000));
    } else {
      media.oncanplay = mount;
    }
    // 兜底：视频迟迟不 canplay，超时也挂上，避免永远黑着
    setTimeout(mount, 4000);
    timer = setTimeout(function () { finish('timeout'); }, MAX_MS);
  }

  // 启动时调用：有开屏就先播，播完再执行 next（进首页）
  function run(next) {
    onFinish = next;
    play(false);
    if (!layer) { done = true; if (next) next('none'); }
  }

  root.PSSplash = { run: run, play: play };
})(window);
