# 6A版图库集成核查记录

核查时间：2026-11-18。此记录只涉及 Pexels 与集古作，不代表对其他图库接口的变更建议。

## Pexels

- 官方 API 使用 API Key，并在照片对象中提供可用于显示的 `src` 图片地址。应用中已有 `pexelsKey` 设置项和官方 API 请求分支；配置有效 Key 后，图片候选可在应用里直接预览。
- 本轮检查公开搜索页 `https://www.pexels.com/search/nature/` 时遇到 CAPTCHA，无法稳定读取图片结果 DOM。页面结构、懒加载与反自动化页面不是可靠 API，故不应把 HTML 抓取或 WebView 点击拦截当作无 Key 的产品路径。
- 无 Key 时，应用继续打开 Pexels 搜索网页，并改用站点实际的路径型地址 `https://www.pexels.com/search/{query}/`。当前公开网页路径不能保证应用内直接选图；可靠的内嵌候选和预览依赖 Pexels API Key。
- 应用原生跨域代理白名单已包含 `images.pexels.com`，用于 Key 已配置时读取 CDN 图片。

来源：
- API 文档（认证、Photo `src`、归属）：https://www.pexels.com/api/documentation/
- API 产品页与资格说明：https://www.pexels.com/api/
- 许可：https://www.pexels.com/license/
- 服务条款：https://www.pexels.com/terms-of-service/
- 公开搜索页实测入口：https://www.pexels.com/search/nature/

## 集古作

- 搜索不是普通 GET；搜索表单提交到 `https://www.jiguzuo.com/sou/`。本轮按表单提交 `tempid=1`、`show=title,smalltext,ftitle,laiyuan,keyboard`、`tbname=xiazai` 与 `keyboard=山水`，不预先 GET 首页也返回 HTTP 200 的搜索结果 HTML，标题为“搜索‘山水’”，正文包含 `data-original` 图片字段。因此，应用内的原生 POST 可以单次完成搜索，不需要用户先访问搜索页再重复提交。
- 实测结果中的图片地址带 `!w100` 尺寸后缀。该地址适合作为列表缩略图；去掉末尾 `!w100` 后的图片 URL可直接响应 HTTP 200，适合作为预览和实际使用图。当前解析保留缩略图地址，同时将去后缀的地址设为候选原图。
- 搜索结果里的图片域名为 `img.jiguzuo.com`。应用原生 GET 代理白名单已补入该 CDN 域名，以便 WebView 的跨域图像请求和本机保存流程可以读取图片。

来源：
- 集古作首页：https://www.jiguzuo.com/
- 搜索 POST 端点：https://www.jiguzuo.com/sou/
- 集古作国画列表：https://www.jiguzuo.com/guohua/list/
- 调研查看的详情页：https://www.jiguzuo.com/guohua/he-ting-na-shuang-tu-7387.html
- 调研 HEAD 验证的原图示例：https://img.jiguzuo.com/guohua/tupian/202611/e588abae056c741b3c8a09aca1cee353.jpg
