package com.example.poetry;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.TextView;
import org.json.JSONTokener;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;

/** 在 App 内打开网站：上面一条工具栏（返回、标题、简／繁、关闭），下面是网页。简／繁按钮把整个网页的文字一键转换。 */
public class WebActivity extends Activity {
    private static WebActivity active;
    private static final ArrayList<TabState> tabs = new ArrayList<>();
    private static class TabState { String key, url, title; int scrollY; TabState(String k, String u, String t) { key = k; url = u; title = t; } }
    private WebView w;
    private TextView titleV, convBtn, tabsBtn;
    private String tabKey = "";
    private String mode = "s", variant = "std", title = "";
    private String searchQuery = "", searchUrl = "";
    private boolean haveT2 = false, haveC2 = false, haveInject = false;
    private boolean skipConv = false;

    public static void open(Activity from, String url, String title, String mode, String variant, String query) {
        if (active != null && !active.isFinishing()) { active.openTab(url, title, mode, variant, query); return; }
        Intent i = new Intent(from, WebActivity.class);
        i.putExtra("url", url); i.putExtra("title", title == null ? "" : title);
        i.putExtra("mode", mode == null ? "s" : mode); i.putExtra("variant", variant == null ? "std" : variant);
        i.putExtra("query", query == null ? "" : query); from.startActivity(i);
    }

    private int dp(int v) {
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics()));
    }

    private boolean isZdicHost(String host) {
        return host != null && ("zdic.net".equalsIgnoreCase(host) || host.toLowerCase().endsWith(".zdic.net"));
    }

    private TextView button(String text, int sizeSp) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sizeSp);
        t.setTextColor(0xFF1D1A16);
        t.setGravity(Gravity.CENTER);
        t.setMinWidth(dp(48));
        t.setPadding(dp(8), 0, dp(8), 0);
        return t;
    }

    @Override
    @SuppressWarnings("deprecation")
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        active = this;
        Intent in = getIntent();
        String url = in.getStringExtra("url");
        searchUrl = url == null ? "" : url;
        searchQuery = in.getStringExtra("query");
        if (searchQuery == null) searchQuery = "";
        tabKey = searchUrl;
        if (url != null) {
            try { String host = android.net.Uri.parse(url).getHost(); skipConv = isZdicHost(host); }
            catch (Exception e) { skipConv = false; }
        }
        title = in.getStringExtra("title");
        if (title == null) title = "";
        rememberTab(tabKey, searchUrl, title);
        mode = "t".equals(in.getStringExtra("mode")) ? "t" : "s";
        String v = in.getStringExtra("variant");
        variant = (v == null || v.length() == 0) ? "std" : v;

        Window win = getWindow();
        if (Build.VERSION.SDK_INT >= 28) {
            WindowManager.LayoutParams lp = win.getAttributes();
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            win.setAttributes(lp);
        }
        win.setStatusBarColor(Color.TRANSPARENT);
        win.setNavigationBarColor(Color.TRANSPARENT);
        if (Build.VERSION.SDK_INT >= 30) win.setDecorFitsSystemWindows(false);
        int flags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION;
        if (Build.VERSION.SDK_INT >= 23) flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
        win.getDecorView().setSystemUiVisibility(flags);

        final LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFFF3ECDC);

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackgroundColor(0xFFFAF6EE);

        TextView back = button("‹", 28);
        back.setOnClickListener(new View.OnClickListener() { public void onClick(View x) { onBackPressed(); } });
        titleV = new TextView(this);
        titleV.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        titleV.setTextColor(0xFF1D1A16);
        titleV.setSingleLine(true);
        titleV.setEllipsize(TextUtils.TruncateAt.END);
        titleV.setText(title);
        convBtn = button("t".equals(mode) ? "繁" : "简", 20);
        convBtn.setTypeface(Typeface.DEFAULT_BOLD);
        convBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View x) {
                mode = "t".equals(mode) ? "s" : "t";
                convBtn.setText("t".equals(mode) ? "繁" : "简");
                applyConv();
                syncSearchQuery();
            }
        });
        tabsBtn = button("▦", 20);
        tabsBtn.setContentDescription("网页方块总览");
        tabsBtn.setOnClickListener(new View.OnClickListener() { public void onClick(View x) { showTabs(); } });
        TextView close = button("✕", 18);
        close.setOnClickListener(new View.OnClickListener() { public void onClick(View x) { finish(); } });

        bar.addView(back, new LinearLayout.LayoutParams(dp(52), dp(48)));
        bar.addView(titleV, new LinearLayout.LayoutParams(0, dp(48), 1f));
        bar.addView(tabsBtn, new LinearLayout.LayoutParams(dp(48), dp(48)));
        bar.addView(convBtn, new LinearLayout.LayoutParams(dp(56), dp(48)));
        bar.addView(close, new LinearLayout.LayoutParams(dp(52), dp(48)));

        w = new WebView(this);
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);   // 视频和声音不用先点一下，能自动播（开屏要用）
        s.setDomStorageEnabled(true);
        String ua0 = s.getUserAgentString();                // 去掉 WebView 标记，让网站按普通浏览器打开
        if (ua0 != null) s.setUserAgentString(ua0.replace("; wv", "").replace("Version/4.0 ", ""));
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        w.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                String sc = r.getUrl().getScheme();
                return !("http".equals(sc) || "https".equals(sc));      // 网页里的普通链接都留在这里打开
            }

            @Override
            public void onPageStarted(WebView v, String u, android.graphics.Bitmap f) {
                haveT2 = false; haveC2 = false; haveInject = false;     // 每个新页面都要重新装转换程序
            }

            @Override
            public void onPageFinished(WebView v, String u) {
                String t = v.getTitle();
                if (t != null && t.length() > 0) titleV.setText(t);
                try { skipConv = isZdicHost(android.net.Uri.parse(u).getHost()); } catch (Exception ignored) { }
                if (!skipConv) applyConv();
                TabState saved = findTab(tabKey);
                if (saved != null && saved.scrollY > 0) v.postDelayed(() -> v.scrollTo(0, saved.scrollY), 120);
            }
        });

        root.addView(bar, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        root.addView(w, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);
        root.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override
            public WindowInsets onApplyWindowInsets(View v, WindowInsets in) {
                int top = in.getSystemWindowInsetTop();
                if (Build.VERSION.SDK_INT >= 28 && in.getDisplayCutout() != null) top = Math.max(top, in.getDisplayCutout().getSafeInsetTop());
                root.setPadding(0, top, 0, in.getSystemWindowInsetBottom());
                return in;
            }
        });
        if (url != null) w.loadUrl(url);
    }

    private void rememberTab(String key, String url, String name) {
        if (key == null || key.length() == 0) return;
        for (TabState t : tabs) if (t.key.equals(key)) { t.url = url; if (name != null && name.length() > 0) t.title = name; return; }
        tabs.add(new TabState(key, url, name == null || name.length() == 0 ? "网页" : name));
    }

    private void openTab(String url, String name, String newMode, String newVariant, String query) {
        if (url == null || url.length() == 0) return;
        TabState old = findTab(tabKey); if (old != null && w != null) old.scrollY = w.getScrollY();
        mode = "t".equals(newMode) ? "t" : "s"; variant = newVariant == null ? "std" : newVariant;
        searchQuery = query == null ? "" : query; searchUrl = url; tabKey = url;
        title = name == null ? "网页" : name; titleV.setText(title); convBtn.setText("t".equals(mode) ? "繁" : "简");
        rememberTab(tabKey, searchUrl, title);
        haveT2 = false; haveC2 = false; haveInject = false;
        try { skipConv = isZdicHost(android.net.Uri.parse(url).getHost()); } catch (Exception ignored) { skipConv = false; }
        w.loadUrl(url);
    }

    private void showTabs() {
        String[] names = new String[tabs.size()];
        for (int i = 0; i < tabs.size(); i++) names[i] = (tabs.get(i).key.equals(tabKey) ? "● " : "○ ") + tabs.get(i).title;
        new AlertDialog.Builder(this).setTitle("已打开网页（点击切换）").setItems(names, (d, which) -> {
            TabState t = tabs.get(which); if (!t.key.equals(tabKey)) openTab(t.url, t.title, mode, variant, "");
        }).setNeutralButton("关闭当前", (d, which) -> closeCurrentTab()).setNegativeButton("取消", null).show();
    }

    private void closeCurrentTab() {
        int ix = -1; for (int i = 0; i < tabs.size(); i++) if (tabs.get(i).key.equals(tabKey)) { ix = i; break; }
        if (ix >= 0) tabs.remove(ix);
        if (tabs.isEmpty()) { finish(); return; }
        TabState t = tabs.get(Math.max(0, ix - 1)); openTab(t.url, t.title, mode, variant, "");
    }

    private TabState findTab(String key) { for (TabState t : tabs) if (t.key.equals(key)) return t; return null; }

    private String asset(String name) {
        try {
            InputStream in = getAssets().open(name);
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[65536];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            in.close();
            return out.toString("UTF-8");
        } catch (Exception e) {
            return "";
        }
    }

    // OpenCC 的脚本带"模块定义"，有些网站自己也有 define，会抢走它；所以包一层，把 define / module / exports 屏蔽掉
    private String wrapLib(String text, String globalName) {
        return "(function(define,module,exports){" + text + "\n})(undefined,undefined,undefined);window." + globalName + "=window.OpenCC;";
    }

    private void applyConv() {
        if (w == null || skipConv) return;
        if ("t".equals(mode)) {
            if (!haveC2) { w.evaluateJavascript(wrapLib(asset("vendor/opencc/cn2t.js"), "__cn2t"), null); haveC2 = true; }
        } else {
            if (!haveT2) { w.evaluateJavascript(wrapLib(asset("vendor/opencc/t2cn.js"), "__t2cn"), null); haveT2 = true; }
        }
        if (!haveInject) { w.evaluateJavascript(asset("js/convert-inject.js"), null); haveInject = true; }
        w.evaluateJavascript("window.__psConv&&window.__psConv('" + mode + "','" + variant + "')", null);
    }

    private void syncSearchQuery() {
        if (w == null || searchUrl.length() == 0) return;
        String current = searchQuery;
        try {
            android.net.Uri u = android.net.Uri.parse(searchUrl);
            String[] keys = new String[]{"q", "p", "wd", "query"};
            for (String k : keys) { String v = u.getQueryParameter(k); if (v != null && v.length() > 0) { current = v; break; } }
        } catch (Exception ignored) { }
        if (current.length() == 0) return;
        final String oldQuery = current;
        String js = "window.__psConvertText&&window.__psConvertText(" + org.json.JSONObject.quote(oldQuery) + ")";
        w.evaluateJavascript(js, value -> {
            try {
                Object out = new JSONTokener(value == null ? "null" : value).nextValue();
                if (!(out instanceof String)) return;
                String converted = (String) out;
                if (converted.length() == 0 || converted.equals(oldQuery)) return;
                String oldEsc = android.net.Uri.encode(oldQuery);
                String newEsc = android.net.Uri.encode(converted);
                String next = searchUrl.replace(oldEsc, newEsc);
                if (!next.equals(searchUrl)) {
                    searchQuery = converted; searchUrl = next; w.loadUrl(next);
                }
            } catch (Exception ignored) { }
        });
    }

    @Override
    public void onBackPressed() {
        if (w != null && w.canGoBack()) w.goBack(); else finish();
    }

    @Override
    protected void onDestroy() {
        if (active == this) { active = null; tabs.clear(); }
        if (w != null) { w.stopLoading(); w.destroy(); w = null; }
        super.onDestroy();
    }
}
