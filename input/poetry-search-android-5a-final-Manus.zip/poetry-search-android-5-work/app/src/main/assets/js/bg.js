  /* bg.js — 背景图：自动配图（网络图库 → AI；失败后停止）、换图的各个选项、首页背景 */
(function (root) {
  'use strict';
  var UI = root.PSUI, I = root.PSImages, St = root.PSStore, ST = root.PSSettings, N = root.PSNative;
  var el = UI.el, tempRefs = {};

  function enabledMap() { var m = {}; ST.get('galleries').forEach(function (g) { m[g.id] = !!g.enabled; }); return m; }
  function ink(n) { return I.localUrl(n); }
  function dayInk() { return ((new Date().getDate() + new Date().getMonth() * 3) % I.LOCAL_COUNT) + 1; }

  // 首页背景
  function homeUrl() {
    var h = ST.get('homeBg') || {};
    if (h.type === 'local' && h.url) return N.toPageUrl(h.url);
    if (h.type === 'url' && h.url) return N.toPageUrl(h.url);
    if (h.type === 'auto' && h.url) return h.url;
    return ink(h.n || dayInk());
  }
  // 首页背景"自动更换"：与诗页同一顺序；每次打开 App 前进一站
  async function homeAutoAdvance() {
    var h = ST.get('homeBg') || {};
    var n = sources().length;
    var start = n ? ((typeof h.src === 'number' ? h.src : -1) + 1) % n : 0;
    var r = await pickFromSources({ title: '', content: '' }, start, '', null, { force: true, ai: ST.get('autoAI') !== false });
    if (!r) return null;
    ST.set('homeBg', { type: 'auto', url: r.url, src: r.src, credit: r.credit || '' });
    return r.url;
  }
  function applyHome() {
    var e = UI.$('homeBg'); if (!e) return;
    var h = ST.get('homeBg') || {};
    if (h.type === 'auto') {
      // 先显示上次的图（或占位），再后台前进一站换上新图
      e.style.backgroundImage = 'url("' + (h.url || ink(dayInk())) + '")';
      if (navigator.onLine !== false) homeAutoAdvance().then(function (u) { if (u) e.style.backgroundImage = 'url("' + u + '")'; }).catch(function () { /* 保持原图 */ });
      return;
    }
    e.style.backgroundImage = 'url("' + homeUrl() + '")';
  }

  // 这首诗用哪张图
  async function refToBg(ref, key) {
    if (!ref) return null;
    if (ref.kind === 'local') return { kind: 'ink', url: ink(ref.n), credit: '' };
    if (ref.kind === 'phone' && ref.url) return { kind: 'phone', url: N.toPageUrl(ref.url), credit: '' };
    if (ref.kind === 'blob') {
      try { var rec = await St.getImage(ref.id); if (rec && rec.blob) return { kind: 'blob', url: URL.createObjectURL(rec.blob), credit: rec.credit || '', link: rec.link || '' }; } catch (e) { /* 往下走 */ }
    }
    if (ref.kind === 'url' && ref.url) return { kind: 'url', url: ref.url, credit: ref.credit || '', link: ref.link || '', fallback: ink(I.localIndexFor(key)) };
    return null;
  }
  function aiSite() { return (ST.get('aiSites') || []).filter(function (s) { return s.mode === 'api'; })[0] || null; }
  function aiUrl(site, poem, seedAdd) {
    var p = I.aiPrompt(poem).en, seed = (I.hash(I.poemKey(poem)) + (seedAdd || 0)) % 1000000;
    var u = site.url.replace('{prompt}', encodeURIComponent(p));
    return u + (u.indexOf('?') >= 0 ? '&' : '?') + 'seed=' + seed;
  }
  function timeout(ms) { return new Promise(function (res) { setTimeout(function () { res('timeout'); }, ms); }); }

  // ---------------------------------------------------------------
  // 自动选图的统一顺序（诗页换图、首页换背景共用）：
  // 网络图库各站依次试 → 全部不通再依次试 AI 生成各站 → 循环。
  // 某一站不通就自动往后试下一站；成功即停。记录成功的是第几站（ref.src），手动"下一张"从下一站开始。
  function sources(opts) {
    var m = enabledMap(), out = [];
    if (!opts || opts.gallery !== false) ST.get('galleries').forEach(function (g) {
      var impl = I.galleryById ? I.galleryById(g.id) : I.GALLERIES.filter(function (x) { return x.id === g.id; })[0];
      if (impl && m[g.id]) out.push({ kind: 'gallery', impl: impl, name: g.name });
    });
    if (!opts || opts.ai !== false) (ST.get('aiSites') || []).forEach(function (s) {
      if (s.mode === 'api') out.push({ kind: 'ai', site: s, name: s.name });
    });
    return out;
  }
  // 试一个站：图库站取候选、挑一张能打开的；AI 站按链接生成一张，能打开即成功
  async function trySource(src, poem, idx, exclude, signal) {
    if (src.kind === 'ai') {
      var u = aiUrl(src.site, poem, idx * 7);
      if (await I.loadImage(u, 25000)) return { url: u, credit: 'AI 生成' };
      return null;
    }
    // 网页搜索页不是图片，不能直接作为背景；没有 direct 结果时必须继续下一站。
    if (src.impl && src.impl.page && !src.impl.direct) return null;
    var terms = I.imageryTerms((poem.title || '') + (poem.content || ''), 3).concat(['mountain landscape']);
    for (var t = 0; t < terms.length; t++) {
      if (signal && signal.aborted) return null;
      var list = [];
      try { list = (await I.searchGallery(src.impl, terms[t], 12, signal)).filter(function (x) { return x.url && !x.page && x.url !== exclude; }); } catch (e) { list = []; }
      if (!list.length) continue;
      var base = I.hash(I.poemKey(poem)) + idx;
      for (var k = 0; k < Math.min(3, list.length); k++) {
        var c = list[(base + k) % list.length];
        if (await I.loadImage(c.url, 5000)) return { url: c.url, credit: c.credit || src.name, link: c.link || '' };
      }
    }
    return null;
  }
  // 从第 start 站开始，按顺序试，直到成功；全部不通返回 null
  async function pickFromSources(poem, start, exclude, signal, opts) {
    var list = sources(opts); if (!list.length) return null;
    for (var step = 0; step < list.length; step++) {
      if (signal && signal.aborted) return null;
      var idx = (start + step) % list.length;
      var r = await trySource(list[idx], poem, idx, exclude, signal);
      if (r) return { url: r.url, credit: r.credit || '', link: r.link || '', src: idx };
    }
    return null;
  }
  // 诗页"自动更换"（也是手动"下一张"）：从上一次成功的站的下一站开始
  async function nextForPoem(poem, cur) {
    var key = I.poemKey(poem), ref = tempRefs[key] || null;
    if (!ref) { try { ref = await St.getMap(key); } catch (e) { ref = null; } }
    var n = sources({ ai: ST.get('autoAI') !== false }).length; if (!n) return null;
    var start = ((ref && typeof ref.src === 'number' ? ref.src : -1) + 1) % n;
    return pickFromSources(poem, start, cur || '', null, { force: true, ai: ST.get('autoAI') !== false });
  }

  // 先给出能立刻显示的背景（已保存的 / 自带水墨），再在后台按统一顺序临时找一张；未点击保存就不建立永久映射
  async function forPoem(poem, onUpdate) {
    var key = I.poemKey(poem), ref = tempRefs[key] || null, cancelled = false, ctl = new AbortController();
    if (!ref) { try { ref = await St.getMap(key); } catch (e) { ref = null; } }
    var saved = await refToBg(ref, key);
    var handle = { cancel: function () { cancelled = true; try { ctl.abort(); } catch (e) { /* ignore */ } } };
    if (saved) { handle.bg = saved; return handle; }
    handle.bg = { kind: 'ink', url: ink(I.localIndexFor(key)), credit: '' };
    if (navigator.onLine === false || ST.get('autoGallery') === false) return handle;
    (async function () {
      try {
        var r = await pickFromSources(poem, 0, '', ctl.signal, { force: false, ai: ST.get('autoAI') !== false });
        if (!r || cancelled) return;
        tempRefs[key] = { kind: 'url', url: r.url, credit: r.credit || '', link: r.link || '', src: r.src };
        onUpdate({ kind: 'url', url: r.url, credit: r.credit, link: r.link || '' });
      } catch (e) { /* 失败就保持自带水墨 */ }
    })();
    return handle;
  }
  async function setPoemRef(poem, ref) { await St.setMap(I.poemKey(poem), ref); delete tempRefs[I.poemKey(poem)]; }
  function setTempPoemRef(poem, ref) { tempRefs[I.poemKey(poem)] = ref; }

  function btn(label, cls, fn) { var b = el('button', cls || 'btn'); b.textContent = label; b.onclick = fn; return b; }
  function listRow(title, sub, fn) {
    var r = el('button', 'row'); var t = el('div', 'row-t'); t.textContent = title; r.appendChild(t);
    if (sub) { var s = el('div', 'row-s'); s.textContent = sub; r.appendChild(s); }
    r.onclick = fn; return r;
  }

  // 自带水墨：缩略图列表，点一张预览，再设为首页背景或这首诗的背景
  function openInkGrid(opts) {
    UI.openPage('自带水墨图片', function (body) {
      var g = el('div', 'grid');
      for (var n = 1; n <= I.LOCAL_COUNT; n++) (function (n) {
        var c = el('button', 'thumb'); var im = new Image(); im.loading = 'lazy'; im.src = ink(n); im.alt = '水墨 ' + n; c.appendChild(im);
        c.onclick = function () {
          UI.openSheet('预览 · 第 ' + n + ' 张', function (b) {
            var big = new Image(); big.src = ink(n); big.className = 'preview'; b.appendChild(big);
            b.appendChild(btn(opts.label, 'btn primary wide', function () { UI.closeSheet(); setTimeout(function () { opts.onPick(n); }, 60); }));
          }, { hideOk: true });
        };
        g.appendChild(c);
      })(n);
      body.appendChild(g);
    });
  }

  // 手机本地：先问"相册"还是"文件"
  function openPhoneDialog(onPicked) {
    UI.openSheet('手机本地图片', function (b) {
      b.appendChild(listRow('相册', '缩略图预览，最新保存的在前面', function () { UI.closeSheet(); setTimeout(function () { pick('gallery'); }, 60); }));
      b.appendChild(listRow('文件', '从手机存储的根目录开始，一层层翻文件夹', function () { UI.closeSheet(); setTimeout(function () { pick('files'); }, 60); }));
    }, { hideOk: true });
    async function pick(mode) { var r = await N.pickImage(mode); if (r && r.url) onPicked(r); }
  }

  // 网络图库：先列出预设的图库链接，选一个，再看这个图库里和这首诗意象相合的图
  function openGalleryList(poem, applied) {
    UI.openPage('网络图库', function (body) {
      ST.get('galleries').forEach(function (g) {
        body.appendChild(listRow(g.name, g.enabled ? '' : '（已在设置里关闭）', function () { openCandidates(poem, g, applied); }));
      });
      var tip = el('p', 'tip'); tip.textContent = '图库列表可在 设置 → 网络图库 里添加、删除、修改。'; body.appendChild(tip);
    });
  }
  function openCandidates(poem, g, applied) {
    var ctl = new AbortController();
    UI.openPage(g.name, function (body) {
      var st = el('p', 'tip'); st.textContent = '正在查找与这首诗意象相合的图片……'; body.appendChild(st);
      var m = {}; m[g.id] = true;
      var impl = I.galleryById ? I.galleryById(g.id) : g;
      // 没有真实图片接口的页面型站：给一个“打开搜索结果”按钮，在 App 里打开搜索页自己选
      if (impl && impl.page && (!impl.direct || (impl.custom && !impl.imageUrl) || (impl.id === 'pexels' && !(ST.get('pexelsKey') || '').trim()))) {
        var pageTerms = I.imageryTerms((poem.title || '') + (poem.content || ''), 1);
        st.textContent = '这个站是网页搜索，已自动选择一个主关键词；点下面的词打开搜索页，自己选图。';
        pageTerms.forEach(function (t) {
          body.appendChild(listRow('搜索：' + t, '在这个站里打开搜索结果', function () { N.openBrowser(I.pageUrlFor(impl, t) || t, g.name, 's', 'std'); }));
        });
        return;
      }
      I.candidates(poem, m, ctl.signal).then(function (r) {
        st.textContent = r.list.length ? ('找到 ' + r.list.length + ' 张（意象：' + r.terms.join('、') + '），点一张预览') : '这个图库这次没有找到，可能打不开或没有合适的图。';
        var gr = el('div', 'grid');
        r.list.forEach(function (c) {
          var t = el('button', 'thumb'), im = new Image(); im.loading = 'lazy'; im.src = c.thumb || c.url; t.appendChild(im);
          t.onclick = function () {
            UI.openSheet('预览', function (b) {
              var big = new Image(); big.src = c.url; big.className = 'preview'; b.appendChild(big);
              var cr = el('p', 'tip'); cr.textContent = '来源：' + (c.credit || g.name); b.appendChild(cr);
              if (c.link) b.appendChild(btn('打开详情页', 'btn wide', function () { N.openBrowser(c.link, c.credit || g.name, root.PSConvert.getMode(), root.PSConvert.getVariant()); }));
              b.appendChild(btn('保存并使用这张', 'btn primary wide', async function () {
                try { await I.saveCandidate(St, poem, c); UI.closeSheet(); applied(); UI.toast('已保存并换成这张'); }
                catch (e) { UI.toast('保存失败，未建立永久图片记录：' + (e.message || e), 4500); }
              }));
              b.appendChild(btn('仅本次显示（不保存）', 'btn wide', function () {
                setTempPoemRef(poem, { kind: 'url', url: c.url, credit: c.credit, link: c.link || '' });
                UI.closeSheet(); applied(); UI.toast('已临时换图，未保存');
              }));
            }, { hideOk: true });
          };
          gr.appendChild(t);
        });
        body.appendChild(gr);
        if (root.PSConvert) root.PSConvert.apply(body);
      }).catch(function () { st.textContent = '这个图库打不开。'; });
    }, { onClose: function () { try { ctl.abort(); } catch (e) { /* ignore */ } } });
  }

  // AI 生成：已配置好的 AI 链接。能一键出图的（链接里有 {prompt}）直接生成并和当前背景对比；其余的复制提示词后打开网站
  function openAiList(poem, getCurrentUrl, applied) {
    UI.openPage('AI 生成', function (body) {
      (ST.get('aiSites') || []).forEach(function (s) {
        body.appendChild(listRow(s.name, s.mode === 'api' ? '一键生成，可与当前背景对比' : '打开网站，提示词已复制', function () {
          if (s.mode === 'api') openAiCompare(poem, s, getCurrentUrl, applied);
          else {
            var p = I.aiPrompt(poem).zh;
            try { navigator.clipboard.writeText(p); } catch (e) { /* ignore */ }
            UI.toast('提示词已复制，到网站粘贴；生成后保存图片，再回来选"手机本地"', 5000);
            N.openBrowser(s.url, s.name, root.PSConvert.getMode(), root.PSConvert.getVariant());
          }
        }));
      });
      var tip = el('p', 'tip'); tip.textContent = 'AI 网站列表可在 设置 → AI生图网站 里添加、删除、修改。免费的一键出图每 15 秒只能一次，图上可能有水印。'; body.appendChild(tip);
    });
  }
  function openAiCompare(poem, site, getCurrentUrl, applied) {
    var seedAdd = 0;
    UI.openPage('AI 出图对比', function (body) {
      var row = el('div', 'compare'), a = el('div', 'cmp'), b = el('div', 'cmp');
      var ia = new Image(), ib = new Image();
      ia.src = getCurrentUrl(); ia.className = 'preview'; ib.className = 'preview';
      a.appendChild(ia); var la = el('div', 'tip'); la.textContent = '当前背景'; a.appendChild(la);
      var lb = el('div', 'tip'); lb.textContent = '正在生成……（可能要十几秒）'; b.appendChild(ib); b.appendChild(lb);
      row.appendChild(a); row.appendChild(b); body.appendChild(row);
      var use = btn('保存并使用这张', 'btn primary wide', async function () {
        var u = ib.dataset.url; if (!u) return;
        try {
          var blob = await I.downloadBlob(u), id = 'ai-' + I.hash(u);
          await St.putImage({ id: id, blob: blob, credit: 'AI 生成', link: '', source: 'ai', added: Date.now() });
          await setPoemRef(poem, { kind: 'blob', id: id });
        } catch (e) { UI.toast('保存失败，未建立永久图片记录：' + (e.message || e), 4500); return; }
        applied(); UI.toast('已保存并换成 AI 生成的图'); UI.closeTop();
      });
      var temp = btn('仅本次使用（不保存）', 'btn wide', function () {
        var u = ib.dataset.url; if (!u) return;
        setTempPoemRef(poem, { kind: 'url', url: u, credit: 'AI 生成', link: '' });
        applied(); UI.toast('已临时使用 AI 图片，未保存'); UI.closeTop();
      });
      use.disabled = true;
      temp.disabled = true;
      var again = btn('再来一张', 'btn wide', function () { gen(); });
      body.appendChild(use); body.appendChild(temp); body.appendChild(again);
      function gen() {
        seedAdd += 1; var u = aiUrl(site, poem, seedAdd); use.disabled = true; temp.disabled = true; lb.textContent = '正在生成……（可能要十几秒）'; ib.removeAttribute('src');
        I.loadImage(u, 90000).then(function (ok) {
          if (ok) { ib.src = u; ib.dataset.url = u; lb.textContent = 'AI 生成'; use.disabled = false; temp.disabled = false; }
          else lb.textContent = '没有生成出来（可能太频繁或网站忙），稍等 15 秒再点"再来一张"。';
        });
      }
      gen();
    });
  }

  // 诗页"换图"：四个选项
  // 诗页换图五项：网络图库、AI 生成、手机本地、自带水墨、自动更换（放最后）
  function openSourceDialog(poem, getCurrentUrl, applied) {
    UI.openSheet('换图', function (b) {
      b.appendChild(listRow('网络图库', '预设的图库链接，任选一个', function () { UI.closeSheet(); setTimeout(function () { openGalleryList(poem, applied); }, 60); }));
      b.appendChild(listRow('AI 生成', '已配置好的 AI 生成链接', function () { UI.closeSheet(); setTimeout(function () { openAiList(poem, getCurrentUrl, applied); }, 60); }));
      b.appendChild(listRow('手机本地', '相册或文件', function () {
        UI.closeSheet(); setTimeout(function () {
          openPhoneDialog(async function (r) { await setPoemRef(poem, { kind: 'phone', url: r.url }); applied(); UI.toast('已换成你选的图'); });
        }, 60);
      }));
      b.appendChild(listRow('自带水墨图片', '缩略图列表，任选一张', function () {
        UI.closeSheet(); setTimeout(function () {
          openInkGrid({ label: '设为这首诗的背景', onPick: async function (n) { await setPoemRef(poem, { kind: 'local', n: n }); applied(); UI.closeTop(); UI.toast('已换成这张'); } });
        }, 60);
      }));
      b.appendChild(listRow('自动更换', '每点一次按顺序换下一站：网络图库各站，再 AI 生成各站，循环', async function () {
        UI.closeSheet();
        var cur = (getCurrentUrl && getCurrentUrl()) || '';
        UI.toast('正在换图…');
        var r = await nextForPoem(poem, cur);
        if (!r) { UI.toast('所有图库和 AI 站这次都没有取到图，请稍后再试'); return; }
        setTempPoemRef(poem, { kind: 'url', url: r.url, credit: r.credit || '', link: r.link || '', src: r.src });
        applied(); UI.toast('已临时换一张，未保存');
      }));
    }, { hideOk: true });
  }

  // 首页"换背景"：自带水墨、手机本地
  // 首页换背景五项：自动更换、手机本地、网络图库、AI 生成、自带水墨（水墨排最后）
  function openHomeDialog() {
    UI.openSheet('换背景', function (b) {
      b.appendChild(listRow('自动更换', '按顺序：网络图库各站，再 AI 生成各站，循环；每次打开 App 换下一站', function () {
        UI.closeSheet();
        ST.set('homeBg', { type: 'auto', url: '', src: -1, credit: '' });
        applyHome(); UI.toast('已设为自动更换');
      }));
      b.appendChild(listRow('手机本地', '相册或文件', function () {
        UI.closeSheet(); setTimeout(function () {
          openPhoneDialog(function (r) { ST.set('homeBg', { type: 'local', n: 0, url: r.url }); applyHome(); UI.toast('首页背景已换'); });
        }, 60);
      }));
      b.appendChild(listRow('网络图库', '找一张和首页意象相合的图', function () {
        UI.closeSheet(); setTimeout(async function () {
          UI.toast('正在网络图库找图……');
          try {
            var r = await I.autoMatch({ title: '', author: '', dynasty: '', content: '' }, enabledMap(), new AbortController().signal);
            if (r && r.url) { ST.set('homeBg', { type: 'url', n: 0, url: r.url, credit: r.credit || '' }); applyHome(); UI.toast('首页背景已换（网络图库）'); }
            else UI.toast('网络图库这次没有找到，可以试试别的');
          } catch (e) { UI.toast('网络图库打不开'); }
        }, 60);
      }));
      b.appendChild(listRow('AI 生成', '用已配置的 AI 生图网站生成', function () {
        UI.closeSheet(); setTimeout(function () {
          var site = aiSite();
          if (!site) { UI.toast('还没有可一键生图的 AI 网站，请到 设置 → AI生图网站 添加'); return; }
          var u = aiUrl(site, { title: '首页', content: '' }, 0);
          ST.set('homeBg', { type: 'url', n: 0, url: u, credit: 'AI 生成' }); applyHome(); UI.toast('首页背景已换（AI 生成）');
        }, 60);
      }));
      b.appendChild(listRow('自带水墨图片', '缩略图列表，任选一张', function () {
        UI.closeSheet(); setTimeout(function () {
          openInkGrid({ label: '设为首页背景', onPick: function (n) { ST.set('homeBg', { type: 'ink', n: n, url: '' }); applyHome(); UI.closeTop(); UI.toast('首页背景已换'); } });
        }, 60);
      }));
    }, { hideOk: true });
  }

  // 自动更换：每次打开 App 从列表里换一张（mode=own 用专属文件夹；mode=phone 用手机文件夹）
  function autoPick() {
    var a = ST.get('autoChange') || {};
    if (a.mode === 'phone' && a.folderUri) {
      // 直接引用的手机文件夹：每次取图片列表，随机一张
      return { folder: true, uri: a.folderUri };
    }
    if (!a.list || !a.list.length) return null;
    var i = Math.floor(Math.random() * a.list.length);
    return a.list[i];
  }
  // 把 autoPick 的结果变成可显示的图片地址（文件夹模式要先向手机要图片列表）
  async function autoUrl() {
    var p = autoPick();
    if (!p) return null;
    if (typeof p === 'string') return p;
    var list = await N.listFolderImages(p.uri);
    if (!list.length) return null;
    return list[Math.floor(Math.random() * list.length)];
  }
  root.PSBg = { nextForPoem: nextForPoem, homeAutoAdvance: homeAutoAdvance, autoPick: autoPick, autoUrl: autoUrl, applyHome: applyHome, homeUrl: homeUrl, forPoem: forPoem, ink: ink, openSourceDialog: openSourceDialog, openHomeDialog: openHomeDialog, openInkGrid: openInkGrid, openPhoneDialog: openPhoneDialog };
})(window);
