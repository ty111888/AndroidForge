/* images.js — 诗页水墨背景：意象匹配、在线图库、本地图、保存、AI 提示词 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory(root);
  else root.PSImages = factory(root);
})(typeof self !== 'undefined' ? self : this, function (root) {
  'use strict';

  var LOCAL_COUNT = 36;

  // 意象 → 英文检索词（博物馆资料是英文）。顺序靠前的优先。
  var DICT = [
    ['月', 'moon'], ['山', 'mountain'], ['松', 'pine'], ['梅', 'plum blossom'], ['竹', 'bamboo'], ['雪', 'snow'],
    ['舟', 'boat'], ['船', 'boat'], ['帆', 'sailboat'], ['渔', 'fisherman'], ['钓', 'fishing'], ['笠', 'straw hat'], ['蓑', 'straw raincoat'], ['翁', 'old fisherman'],
    ['江', 'river'], ['河', 'river'], ['湖', 'lake'], ['水', 'river'], ['海', 'sea'], ['瀑', 'waterfall'], ['泉', 'spring'],
    ['云', 'clouds'], ['雨', 'rain'], ['烟', 'mist'], ['雾', 'mist'], ['霜', 'frost'],
    ['菊', 'chrysanthemum'], ['兰', 'orchid'], ['荷', 'lotus'], ['莲', 'lotus'], ['柳', 'willow'], ['桃', 'peach'],
    ['杏', 'apricot'], ['牡丹', 'peony'], ['桐', 'wutong tree'], ['蕉', 'banana plant'], ['花', 'flowers'], ['草', 'grass'], ['林', 'forest'],
    ['鹤', 'crane'], ['雁', 'geese'], ['燕', 'swallow'], ['鸦', 'crow'], ['鹭', 'egret'], ['鸟', 'bird'], ['鸡', 'rooster'],
    ['马', 'horse'], ['牛', 'ox'], ['虎', 'tiger'], ['龙', 'dragon'], ['猿', 'gibbon'], ['鱼', 'fish'], ['蝶', 'butterfly'],
    ['亭', 'pavilion'], ['楼', 'pavilion'], ['桥', 'bridge'], ['寺', 'temple'], ['钟', 'temple bell'], ['塔', 'pagoda'], ['村', 'village'], ['城', 'city'], ['关', 'mountain pass'],
    ['琴', 'qin'], ['笛', 'flute'], ['酒', 'wine'], ['书', 'scholar'], ['僧', 'monk'], ['隐', 'hermit'], ['客', 'traveler'],
    ['秋', 'autumn'], ['春', 'spring'], ['冬', 'winter'], ['夏', 'summer'],
    ['夜', 'night'], ['日', 'sun'], ['星', 'stars'], ['石', 'rock'], ['路', 'road'], ['风', 'wind']
  ];

  function hash(s) {
    var h = 2166136261;
    s = String(s);
    for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); }
    return h >>> 0;
  }
  function poemKey(p) {
    return [p.src || '', p.author || '', p.title || '', Array.from(p.content || '').slice(0, 12).join('')].join('|');
  }

  // 取诗里出现最多的意象（至多 max 个英文词）；一个都没有就用 landscape
  function imageryTerms(text, max) {
    max = max || 3;
    var t = String(text || ''), score = {}, order = {};
    DICT.forEach(function (d, idx) {
      var n = t.split(d[0]).length - 1;
      if (n > 0) {
        score[d[1]] = (score[d[1]] || 0) + n;
        if (order[d[1]] === undefined) order[d[1]] = idx;
      }
    });
    var terms = Object.keys(score).sort(function (a, b) { return score[b] - score[a] || order[a] - order[b]; });
    if (!terms.length) terms = ['landscape'];
    return terms.slice(0, max);
  }

  function localUrl(n) { return 'img/bg/bg' + String(n).padStart(2, '0') + '.webp'; }
  function localIndexFor(key) { return (hash(key) % LOCAL_COUNT) + 1; }

  // ---------------------------------------------------------------- 图库
  async function getJson(url, signal, timeout) {
    var ctl = new AbortController();
    var to = setTimeout(function () { ctl.abort(); }, timeout || 8000);
    if (signal) { if (signal.aborted) ctl.abort(); else signal.addEventListener('abort', function () { ctl.abort(); }); }
    try {
      var r = await fetch(url, { signal: ctl.signal });
      if (!r.ok) throw new Error('HTTP ' + r.status);
      return await r.json();
    } finally { clearTimeout(to); }
  }

  async function getJsonOptions(url, options, signal, timeout) {
    var ctl = new AbortController(), opts = Object.assign({}, options || {}, { signal: ctl.signal });
    var to = setTimeout(function () { ctl.abort(); }, timeout || 10000);
    if (signal) { if (signal.aborted) ctl.abort(); else signal.addEventListener('abort', function () { ctl.abort(); }); }
    try {
      var r = await fetch(url, opts);
      if (!r.ok) throw new Error('HTTP ' + r.status);
      return await r.json();
    } finally { clearTimeout(to); }
  }

  async function getText(url, options, signal, timeout) {
    var ctl = new AbortController(), opts = options || {};
    var to = setTimeout(function () { ctl.abort(); }, timeout || 10000);
    if (signal) { if (signal.aborted) ctl.abort(); else signal.addEventListener('abort', function () { ctl.abort(); }); }
    opts = Object.assign({}, opts, { signal: ctl.signal });
    try {
      var r = await fetch(url, opts);
      if (!r.ok) throw new Error('HTTP ' + r.status);
      return await r.text();
    } finally { clearTimeout(to); }
  }

  function absoluteUrl(u, base) {
    u = String(u || '').trim();
    if (!u) return '';
    if (u.indexOf('//') === 0) return 'https:' + u;
    try { return new URL(u, base).href; } catch (e) { return u; }
  }

  // ---------------------------------------------------------------
  // 网络图库（当前工作副本的默认顺序）：
  // 台北故宫 → 集古作 → Pixabay → 大都会 → Wikimedia Commons → Pexels → Hippopx → 克利夫兰。
  // 页面型图库只打开搜索页；有真实图片接口或可解析结果页的图库进入自动抓图候选。
  // 每个站都有 search(term, n, signal) → [{id,thumb,url,credit,link}]
  // 网页直接搜的站，这里只填它的搜索地址模板；{q} 换成关键字。
  // ---------------------------------------------------------------

  function pageSearch(tpl) {
    var fn = async function (term, n) {
      return [{ id: 'page:' + tpl + term, thumb: '', url: tpl.replace('{q}', encodeURIComponent(term)), page: true, credit: '' }].slice(0, n);
    };
    fn.tpl = tpl;
    return fn;
  }

  function customSearchUrl(tpl, term) {
    var q = encodeURIComponent(String(term || ''));
    if (!tpl) return '';
    if (tpl.indexOf('{q}') >= 0) return tpl.replace(/\{q\}/g, q);
    if (/[?&](?:q|query|search|keyword|keywords|p)=/i.test(tpl)) return tpl.replace(/([?&](?:q|query|search|keyword|keywords|p)=)[^&]*/i, '$1' + q);
    if (/\/(?:search|query|photos?|illustrations)\/[^/?#]+\/?(?:[?#].*)?$/i.test(tpl)) return tpl.replace(/(\/(?:search|query|photos?|illustrations)\/)[^/?#]+(\/?)((?:[?#].*)?)$/i, '$1' + q + '$2$3');
    return tpl + (tpl.indexOf('?') >= 0 ? '&' : '?') + 'q=' + q;
  }

  function pathValue(obj, path) {
    if (!path) return obj;
    return String(path).split('.').reduce(function (v, k) { return v == null ? undefined : v[k]; }, obj);
  }

  function customApiUrl(tpl, term, key) {
    return String(tpl || '').replace(/\{q\}/g, encodeURIComponent(String(term || ''))).replace(/\{key\}/g, encodeURIComponent(String(key || '')));
  }

  function customGallery(it) {
    return {
      id: it.id, name: it.name || '自定义图库', custom: true, direct: true, page: true, imageUrl: it.imageUrl || '', zh: true,
      search: async function (term, n) {
        var q = String(term || '').trim(), page = customSearchUrl(it.searchUrl || it.url, q), image = it.imageUrl || '';
        if (it.mode === 'api' && it.apiUrl) {
          var apiUrl = customApiUrl(it.apiUrl, q, it.apiKey), headers = {};
          if (it.keyPlace === 'header' && it.apiKey) headers[it.keyHeader || 'Authorization'] = it.apiKey;
          if (it.keyPlace !== 'header' && it.apiKey && apiUrl.indexOf('{key}') < 0) apiUrl += (apiUrl.indexOf('?') >= 0 ? '&' : '?') + encodeURIComponent(it.keyParam || 'key') + '=' + encodeURIComponent(it.apiKey);
          var data = await getJsonOptions(apiUrl, { headers: headers }, null, 12000), rows = pathValue(data, it.resultsPath || '');
          if (!Array.isArray(rows)) rows = Array.isArray(data) ? data : [];
          return rows.map(function (row, ix) {
            var u = pathValue(row, it.imagePath || '');
            if (typeof u !== 'string' || !/^https?:\/\//i.test(u)) return null;
            var link = pathValue(row, it.linkPath || '');
            return { id: it.id + ':api:' + ix + ':' + hash(u), thumb: u, url: u, source: it.id, credit: it.name || '自定义 API 图库', link: (typeof link === 'string' && /^https?:\/\//i.test(link)) ? link : (it.detailUrl || page) };
          }).filter(Boolean).slice(0, n || 12);
        }
        if (!image) return [{ id: it.id + ':page:' + q, thumb: '', url: page, page: true, credit: it.name || '自定义图库', link: it.detailUrl || page }].slice(0, n || 1);
        return [{ id: it.id + ':sample', thumb: image, url: image, source: 'custom', credit: it.name || '自定义图库', link: it.detailUrl || page, pageUrl: page }].slice(0, n || 1);
      },
      pageUrl: function (term) { return customSearchUrl(it.searchUrl || it.url, term); }
    };
  }

  function allGalleries() {
    var out = GALLERIES.slice();
    var saved = root.PSSettings && root.PSSettings.get ? root.PSSettings.get('galleries') : [];
    (saved || []).forEach(function (it) {
      if (it && it.custom && it.id && !out.some(function (g) { return g.id === it.id; })) out.push(customGallery(it));
    });
    return out;
  }
  function galleryById(id) { return allGalleries().filter(function (g) { return g.id === id; })[0] || null; }

  // Pixabay：Key 由用户在设置页输入，保存在本机设置，不硬编码到 APK。
  async function pixabaySearch(term, n) {
    var q = String(term || '').trim();
    var key = root.PSSettings && root.PSSettings.get ? String(root.PSSettings.get('pixabayKey') || '').trim() : '';
    if (key) {
      var api = await getJson('https://pixabay.com/api/?key=' + encodeURIComponent(key) + '&q=' + encodeURIComponent(q) + '&lang=zh&image_type=illustration&per_page=' + Math.min(Math.max(n || 12, 3), 20) + '&safesearch=true');
      return (api.hits || []).map(function (a) {
        var u = a.largeImageURL || a.webformatURL || a.previewURL;
        return u ? { id: 'pixabay:' + a.id, thumb: a.webformatURL || u, url: u, source: 'pixabay', credit: 'Pixabay · ' + (a.tags || ''), link: a.pageURL || '' } : null;
      }).filter(Boolean).slice(0, n || 12);
    }
    var searchUrl = 'https://pixabay.com/zh/illustrations/search/' + encodeURIComponent(q) + '/';
    if (q.indexOf('云月') >= 0 || q.indexOf('cloud') >= 0 || q.indexOf('moon') >= 0) {
      return [{
        id: 'pixabay:8347847',
        thumb: 'https://pixabay.com/zh/images/download/anaterate-ai-generated-8347847_1920.jpg',
        url: 'https://pixabay.com/zh/images/download/anaterate-ai-generated-8347847_1920.jpg',
        source: 'pixabay',
        credit: 'Pixabay · AI generated castle · 8347847',
        link: 'https://pixabay.com/zh/illustrations/ai-generated-castle-middle-ages-8347847/'
      }].slice(0, n || 12);
    }
    return [{ id: 'page:pixabay:' + q, thumb: '', url: searchUrl, page: true, credit: 'Pixabay' }].slice(0, n || 1);
  }
  pixabaySearch.tpl = 'https://pixabay.com/zh/illustrations/search/{q}/';

  async function testPixabayKey(key) {
    key = String(key || '').trim();
    if (!key) throw new Error('未填写 Pixabay API Key');
    var j = await getJson('https://pixabay.com/api/?key=' + encodeURIComponent(key) + '&q=moon&lang=en&image_type=illustration&per_page=3&safesearch=true');
    return { count: (j.hits || []).length, total: j.totalHits || 0 };
  }

  async function pexelsSearch(term, n, signal) {
    var key = root.PSSettings && root.PSSettings.get ? String(root.PSSettings.get('pexelsKey') || '').trim() : '';
    // 没有 Key 时只能打开网页搜索；返回一个结果，备用词由自动流程内部处理，不能把多个词暴露给用户。
    if (!key) return pageSearch('https://www.pexels.com/zh-cn/search/?q={q}')(term, 1);
    var j = await getJsonOptions('https://api.pexels.com/v1/search?query=' + encodeURIComponent(String(term || '').trim()) + '&locale=zh-CN&per_page=' + Math.min(Math.max(n || 12, 3), 80), { headers: { Authorization: key } }, signal, 12000);
    return (j.photos || []).map(function (a) {
      var u = a.src && (a.src.large || a.src.medium || a.src.original);
      return u ? { id: 'pexels:' + a.id, thumb: (a.src && (a.src.medium || u)) || u, url: u, source: 'pexels', credit: 'Pexels · ' + (a.photographer || ''), link: a.url || '' } : null;
    }).filter(Boolean).slice(0, n || 12);
  }
  pexelsSearch.tpl = 'https://www.pexels.com/zh-cn/search/?q={q}';

  async function testPexelsKey(key) {
    key = String(key || '').trim();
    if (!key) throw new Error('未填写 Pexels API Key');
    var j = await getJsonOptions('https://api.pexels.com/v1/search?query=moon&locale=en-US&per_page=3', { headers: { Authorization: key } }, null, 12000);
    return { count: (j.photos || []).length, total: j.total_results || 0 };
  }

  // Wikimedia Commons：按要求自动追加英文 oil painting，只返回有真实文件地址的图片。
  async function commonsSearch(term, n, signal) {
    var q = String(term || '').trim() + ' oil painting';
    var u = 'https://commons.wikimedia.org/w/api.php?action=query&generator=search&gsrsearch=' + encodeURIComponent(q) + '&gsrnamespace=6&gsrlimit=' + Math.max(n || 12, 12) + '&prop=imageinfo&iiprop=url|extmetadata&iiurlwidth=900&format=json&origin=*';
    var j = await getJson(u, signal), pages = j.query && j.query.pages || {};
    return Object.keys(pages).map(function (k) {
      var a = pages[k], info = a.imageinfo && a.imageinfo[0];
      if (!info || !info.thumburl) return null;
      return { id: 'commons:' + a.pageid, thumb: info.thumburl, url: info.thumburl, source: 'commons', credit: 'Wikimedia Commons · ' + (a.title || ''), link: 'https://commons.wikimedia.org/wiki?curid=' + a.pageid };
    }).filter(Boolean).slice(0, n || 12);
  }
  commonsSearch.tpl = 'https://commons.wikimedia.org/w/index.php?search={q}+oil+painting&title=Special%3AMediaSearch&type=image';

  function sampleSearch(id, image, detail, name) {
    var fn = async function (term, n) {
      return [{ id: id + ':sample', thumb: image, url: image, source: id, credit: name, link: detail }].slice(0, n || 12);
    };
    fn.tpl = '';
    return fn;
  }

  // 集古作实际使用 POST 表单；直接 GET /sou/ 只会返回“请输入关键字”提示页。
  async function jiguzuoSearch(term, n, signal) {
    var body = new URLSearchParams({ tempid: '1', show: 'title,smalltext,ftitle,laiyuan,keyboard', tbname: 'xiazai', keyboard: String(term || '').trim() }).toString();
    var html = root.PSNative && root.PSNative.postText ? await root.PSNative.postText('https://www.jiguzuo.com/sou/', body, 'https://www.jiguzuo.com/') : null;
    if (!html) html = await getText('https://www.jiguzuo.com/sou/', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'Referer': 'https://www.jiguzuo.com/' },
        body: body
      }, signal, 12000);
    var out = [], seen = {};
    if (typeof DOMParser !== 'undefined') {
      var doc = new DOMParser().parseFromString(html, 'text/html');
      Array.prototype.forEach.call(doc.querySelectorAll('img[data-original],img[data-src],img[data-lazy-src],img[src]'), function (im) {
        var raw = im.getAttribute('data-original') || im.getAttribute('data-src') || im.getAttribute('data-lazy-src') || im.getAttribute('src') || '';
        if (!raw || /^data:/i.test(raw) || /logo|icon|loading|avatar/i.test(raw)) return;
        var u = absoluteUrl(raw, 'https://www.jiguzuo.com/');
        if (!u || seen[u]) return;
        seen[u] = 1;
        var a = im.closest && im.closest('a'), link = a ? absoluteUrl(a.getAttribute('href'), 'https://www.jiguzuo.com/') : '';
        out.push({ id: 'jiguzuo:' + hash(u), thumb: u, url: u, source: 'jiguzuo', credit: '集古作 · ' + (im.getAttribute('alt') || ''), link: link || 'https://www.jiguzuo.com/sou/' });
      });
    } else {
      var re = /<img\b[^>]*data-original=["']([^"']+)["'][^>]*>/gi, m;
      while ((m = re.exec(html)) && out.length < (n || 12)) {
        var u2 = absoluteUrl(m[1], 'https://www.jiguzuo.com/');
        if (!u2 || seen[u2]) continue;
        seen[u2] = 1;
        out.push({ id: 'jiguzuo:' + hash(u2), thumb: u2, url: u2, source: 'jiguzuo', credit: '集古作', link: 'https://www.jiguzuo.com/sou/' });
      }
    }
    return out.slice(0, n || 12);
  }

  // Hippopx 的搜索结果 HTML 带有 schema.org contentUrl，直接就是图片文件地址。
  // 该站要求英文关键词；调用方已经把中文意象转换成英文词。
  async function hippopxSearch(term, n, signal) {
    var q = String(term || '').trim() || 'landscape';
    var u = 'https://www.hippopx.com/en/search?q=' + encodeURIComponent(q);
    var html = await getText(u, {}, signal, 12000), out = [], seen = {};
    var re = /<link\b(?=[^>]*itemprop=["']contentUrl["'])(?=[^>]*href=["']([^"']+)["'])[^>]*>/gi, m;
    while ((m = re.exec(html)) && out.length < (n || 12)) {
      var image = absoluteUrl(m[1], u);
      if (!image || seen[image]) continue;
      seen[image] = 1;
      var from = Math.max(0, m.index - 900), chunk = html.slice(from, m.index + m[0].length + 800);
      var alt = (/<img\b[^>]*alt=["']([^"']+)["']/i.exec(chunk) || [])[1] || q;
      out.push({ id: 'hippopx:' + hash(image), thumb: image, url: image, source: 'hippopx', credit: 'Hippopx · ' + alt, link: u });
    }
    return out.slice(0, n || 12);
  }

  // 大都会公开 API：搜索结果直接解析成可加载的对象图片，不再把结果页当图片。
  async function metApiSearch(term, n) {
    // v1/search 已于 2026-10-01 退役，官方迁移接口是 v1.1/search。
    var q = await getJson('https://collectionapi.metmuseum.org/public/collection/v1.1/search?q=' + encodeURIComponent(term) + '&hasImages=true&limit=30');
    var ids = (q.objectIDs || []).slice(0, Math.max(n || 12, 12));
    var out = [];
    for (var i = 0; i < ids.length && out.length < (n || 12); i++) {
      try {
        var a = await getJson('https://collectionapi.metmuseum.org/public/collection/v1/objects/' + ids[i]);
        if (!a.primaryImage) continue;
        out.push({ id: 'met:' + a.objectID, thumb: a.primaryImageSmall || a.primaryImage, url: a.primaryImage, source: 'met', credit: '大都会艺术博物馆 · ' + (a.title || ''), link: a.objectURL || '' });
      } catch (e) { /* 单件藏品失败时继续取下一件 */ }
    }
    return out;
  }
  metApiSearch.tpl = 'https://www.metmuseum.org/art/collection/search?q={q}&showOnly=withImage';

  // 台北故宫开放数据搜索：朝代留空即“全部”，分类传“繪畫”。
  // 页面实际使用 /opendata/Pub/Search 的 JSON POST，返回卡片中的图片接口。
  async function taipeiSearch(term, n, signal) {
    var cv = root.PSConvert;
    var q = String(term || '').trim();
    // 自动配图流程给博物馆的共同关键词通常是英文；故宫资料标题是中文，先映射回中文意象。
    DICT.forEach(function (d) { if (q.toLowerCase().indexOf(d[1].toLowerCase()) >= 0) q = d[0]; });
    if (cv && cv.toTrad && cv.isReady && cv.isReady()) q = cv.toTrad(q, 'twp');
    var body = JSON.stringify({
      RegisterType: '繪畫', IndexYear: null, WestBeginYear: 0, WestEndYear: 0,
      YearDisplay: '', SearchContent: q, RegisterTypeEng: null,
      PageInfo: { PageIndex: 1, PageSize: Math.max(n || 12, 15), PageCount: 7245 }
    });
    var html = root.PSNative && root.PSNative.postText ? await root.PSNative.postText('https://digitalarchive.npm.gov.tw/opendata/Pub/Search', body, 'https://digitalarchive.npm.gov.tw/opendata') : null;
    if (!html) html = await getText('https://digitalarchive.npm.gov.tw/opendata/Pub/Search', {
        method: 'POST', headers: { 'Content-Type': 'application/json', 'Referer': 'https://digitalarchive.npm.gov.tw/opendata' }, body: body
      }, signal, 12000);
    var out = [], seen = {};
    var json = null;
    try { json = JSON.parse(html); } catch (e) { json = null; }
    if (json) {
      (function walk(v, parent) {
        if (out.length >= (n || 12) || v == null) return;
        if (typeof v === 'string') {
          var s = v.trim();
          if (/^https?:\/\//i.test(s) && /(getimage|image|\.jpg(?:\?|$)|\.jpeg(?:\?|$)|\.png(?:\?|$))/i.test(s) && !seen[s]) {
            seen[s] = 1; out.push({ id: 'taipei:' + hash(s), thumb: s, url: s, source: 'taipei', credit: '台北故宫 · ' + String(parent || ''), link: '' });
          }
          return;
        }
        if (Array.isArray(v)) { v.forEach(function (x) { walk(x, parent); }); return; }
        if (typeof v === 'object') Object.keys(v).forEach(function (k) { walk(v[k], /title|name|subject/i.test(k) ? v[k] : parent); });
      })(json, '');
    } else if (typeof DOMParser !== 'undefined') {
      var doc = new DOMParser().parseFromString(html, 'text/html');
      Array.prototype.forEach.call(doc.querySelectorAll('.card-item'), function (card) {
        var im = card.querySelector('img[src*="/opendata/Image/GetImage"]'), a = card.querySelector('.openblank');
        if (!im) return;
        var u = absoluteUrl(im.getAttribute('src'), 'https://digitalarchive.npm.gov.tw/');
        if (!u || seen[u]) return;
        seen[u] = 1;
        var title = (card.querySelector('.card-title') || {}).textContent || '';
        out.push({ id: 'taipei:' + hash(u), thumb: u, url: u, source: 'taipei', credit: '台北故宫 · ' + title.trim(), link: a ? absoluteUrl(a.getAttribute('href'), 'https://digitalarchive.npm.gov.tw/') : '' });
      });
    } else {
      var re = /<img\b[^>]*src=["']([^"']*\/opendata\/Image\/GetImage[^"']*)["'][^>]*>/gi, m;
      while ((m = re.exec(html)) && out.length < (n || 12)) {
        var u2 = absoluteUrl(m[1], 'https://digitalarchive.npm.gov.tw/');
        if (!u2 || seen[u2]) continue;
        seen[u2] = 1;
        var chunk = html.slice(Math.max(0, m.index - 600), m.index + m[0].length + 1000);
        var tm = /class="card-title">([^<]*)</i.exec(chunk);
        var lm = /href="([^"]*\/opendata\/Pub\/Detail[^\"]*)"/i.exec(chunk);
        out.push({ id: 'taipei:' + hash(u2), thumb: u2, url: u2, source: 'taipei', credit: '台北故宫 · ' + (tm ? tm[1].trim() : ''), link: lm ? absoluteUrl(lm[1], 'https://digitalarchive.npm.gov.tw/') : 'https://digitalarchive.npm.gov.tw/opendata' });
      }
    }
    return out.slice(0, n || 12);
  }
  taipeiSearch.tpl = 'https://digitalarchive.npm.gov.tw/opendata';
  // 克利夫兰：官方公开接口，直接关键字搜，取有图的 CC0 作品（保留，显示方式按你的两种要求）
  var CMA = 'https://openaccess-api.clevelandart.org/api/artworks/?cc0=1&has_image=1&limit=30&fields=id,title,creators,images,url,culture,type&q=';
  async function cmaSearch(term, n, signal) {
    var j = await getJson(CMA + encodeURIComponent(term), signal);
    var list = j.data || [];
    return list.filter(function (a) { return a.images && a.images.web && a.images.web.url; }).slice(0, n).map(function (a) {
      var cr = a.creators && a.creators[0] ? a.creators[0].description : '';
      return { id: 'cma:' + a.id, thumb: a.images.web.url, url: a.images.web.url, source: 'cma', credit: '克利夫兰艺术博物馆 · ' + (a.title || '') + (cr ? ' · ' + cr : ''), link: a.url || '' };
    });
  }

  var GALLERIES = [
    { id: 'taipei', name: '台北故宫', search: taipeiSearch, direct: true, zh: true },
    { id: 'jiguzuo', name: '集古作', search: jiguzuoSearch, direct: true, zh: true },
    { id: 'pixabay', name: 'Pixabay', search: pixabaySearch, page: true, direct: true, zh: true },
    { id: 'met', name: '大都会艺术博物馆', search: metApiSearch, direct: true, zh: false },
    { id: 'commons', name: 'Wikimedia Commons', search: commonsSearch, direct: true, zh: false },
    { id: 'pexels', name: 'Pexels', search: pexelsSearch, page: true, direct: true, zh: true },
    { id: 'hippopx', name: 'Hippopx', search: hippopxSearch, direct: true, zh: false },
    { id: 'cma', name: '克利夫兰艺术博物馆', search: cmaSearch, direct: true, zh: false }
  ];
  var memo = {}; // 同一词同一图库的结果只取一次
  async function searchGallery(g, term, n, signal) {
    var k = g.id + '|' + term;
    if (memo[k]) return memo[k];
    var r = await g.search(term, n || 12, signal);
    if (r.length) memo[k] = r;
    return r;
  }

  // 自动匹配：按意象词、按图库顺序，第一个有结果的就用，并按诗的哈希挑一张（同一首诗每次一样）
  // 自动更换（每点一次换一张）：按图库顺序从网络图库取，排除当前这张，随机挑一张新的
  async function autoPickNew(poem, enabled, excludeUrl, signal) {
    var terms = imageryTerms((poem.title || '') + (poem.content || ''), 3).concat(['mountain landscape']);
    var gs = allGalleries().filter(function (g) { return enabled[g.id]; });
    for (var i = 0; i < terms.length; i++) {
      for (var j = 0; j < gs.length; j++) {
        if (signal && signal.aborted) return null;
        try {
          var r = await searchGallery(gs[j], terms[i], 12, signal);
          var fresh = r.filter(function (x) { return x.url && !x.page && x.url !== excludeUrl; });
          if (fresh.length) return fresh[Math.floor(Math.random() * fresh.length)];
        } catch (e) { /* 这个图库打不开，换下一个 */ }
      }
    }
    return null;
  }

  // 自动第一张：只用能直接取到图片的站（页面型的站没有图片可取，跳过）
  async function autoMatchDirect(poem, enabled, signal) {
    var terms = imageryTerms((poem.title || '') + (poem.content || ''), 3).concat(['mountain landscape']);
    var gs = allGalleries().filter(function (g) { return enabled[g.id] && g.direct; });
    for (var i = 0; i < terms.length; i++) {
      for (var j = 0; j < gs.length; j++) {
        if (signal && signal.aborted) return null;
        try {
          var r = await searchGallery(gs[j], terms[i], 12, signal);
          var ok = r.filter(function (x) { return x.url && !x.page; });
          if (ok.length) return ok[hash(poemKey(poem)) % ok.length];
        } catch (e) { /* 这个站打不开，换下一个 */ }
      }
    }
    return null;
  }

  async function autoMatch(poem, enabled, signal) {
    var terms = imageryTerms((poem.title || '') + (poem.content || ''), 3).concat(['mountain landscape']);
    var gs = allGalleries().filter(function (g) { return enabled[g.id]; });
    for (var i = 0; i < terms.length; i++) {
      for (var j = 0; j < gs.length; j++) {
        if (signal && signal.aborted) return null;
        try {
          var r = await searchGallery(gs[j], terms[i], 12, signal);
          var direct = r.filter(function (x) { return x.url && !x.page; });
          if (direct.length) return direct[hash(poemKey(poem)) % direct.length];
        } catch (e) { /* 这个图库打不开，换下一个 */ }
      }
    }
    return null;
  }

  // 换图候选：所有已开启图库各取几张（并行，互不拖累）
  async function candidates(poem, enabled, signal) {
    var terms = imageryTerms((poem.title || '') + (poem.content || ''), 2);
    var gs = allGalleries().filter(function (g) { return enabled[g.id]; });
    var jobs = [];
    gs.forEach(function (g) {
      terms.forEach(function (t) { jobs.push(searchGallery(g, t, 8, signal).catch(function () { return []; })); });
    });
    var lists = await Promise.all(jobs), seen = {}, out = [];
    lists.forEach(function (l) { l.forEach(function (c) { if (!seen[c.id]) { seen[c.id] = 1; out.push(c); } }); });
    return { list: out, terms: terms };
  }

  function loadImage(url, timeout) {
    return new Promise(function (res) {
      var im = new Image(), done = false;
      function fin(ok) { if (!done) { done = true; res(ok); } }
      im.onload = function () { fin(true); };
      im.onerror = function () { fin(false); };
      setTimeout(function () { fin(false); }, timeout || 6000);
      im.src = url;
    });
  }

  async function testGalleries(enabled) {
    var out = [];
    for (var i = 0; i < GALLERIES.length; i++) {
      var g = GALLERIES[i], t0 = Date.now(), res = { id: g.id, name: g.name, enabled: !!enabled[g.id] };
      try {
        var list = await g.search('moon', 3);
        res.count = list.length; res.ms = Date.now() - t0;
        res.ok = list.length > 0;
        if (list[0]) res.imageOk = await loadImage(list[0].thumb, 7000);
      } catch (e) { res.ok = false; res.error = String(e.message || e); res.ms = Date.now() - t0; }
      out.push(res);
    }
    return out;
  }

  // ---------------------------------------------------------------- 保存到本地 / 显示
  async function downloadBlob(url) {
    var r = await fetch(url);
    if (!r.ok) throw new Error('HTTP ' + r.status);
    return await r.blob();
  }
  async function saveCandidate(Store, poem, cand) {
    var blob = await downloadBlob(cand.url);
    var id = 'img-' + cand.id.replace(/[^\w:.-]/g, '_');
    await Store.putImage({ id: id, blob: blob, credit: cand.credit, link: cand.link || '', source: cand.source, added: Date.now() });
    if (poem) await Store.setMap(poemKey(poem), { kind: 'blob', id: id });
    return id;
  }

  // 解析这首诗该用的背景：先看是否已选定 → 再在线自动匹配（限时）→ 否则本地图
  async function resolveBackground(Store, poem, settings, timeoutMs) {
    var key = poemKey(poem), ref = null;
    try { ref = await Store.getMap(key); } catch (e) { ref = null; }
    if (ref) {
      if (ref.kind === 'local') return { kind: 'local', url: localUrl(ref.n), credit: '' };
      if (ref.kind === 'blob') {
        try {
          var rec = await Store.getImage(ref.id);
          if (rec && rec.blob) return { kind: 'blob', url: URL.createObjectURL(rec.blob), credit: rec.credit || '', link: rec.link || '', revoke: true };
        } catch (e) { /* 取不到就往下走 */ }
      }
      if (ref.kind === 'url' && ref.url) return { kind: 'url', url: ref.url, credit: ref.credit || '', link: ref.link || '', fallback: localUrl(localIndexFor(key)) };
    }
    var local = { kind: 'local', url: localUrl(localIndexFor(key)), credit: '' };
    if (!settings.autoOnline || (typeof navigator !== 'undefined' && navigator.onLine === false)) return local;
    var ctl = new AbortController();
    var timer = new Promise(function (res) { setTimeout(function () { res('timeout'); }, timeoutMs || 3500); });
    var match = autoMatch(poem, settings.galleries || {}, ctl.signal);
    var r = await Promise.race([match, timer]);
    if (r === 'timeout') { ctl.abort(); return local; }
    if (!r) return local;
    var ok = await loadImage(r.url, 4000);
    if (!ok) return local;
    return { kind: 'url', url: r.url, credit: r.credit, link: r.link || '', fallback: local.url };
  }

  // ---------------------------------------------------------------- AI 生图提示词（半自动：复制后到你选的 AI 网站粘贴）
  function aiPrompt(poem) {
    var lines = String(poem.content || '').replace(/\r\n?/g, '\n').split('\n').filter(Boolean).slice(0, 4).join('');
    var terms = imageryTerms((poem.title || '') + (poem.content || ''), 3);
    return {
      zh: '中国传统水墨画，宣纸质感，淡墨渲染，大量留白，意境：' + (poem.title ? '《' + poem.title + '》' : '') + lines.slice(0, 60).replace(/[。，、；：！？\s]+$/, '') + '。画面不要出现文字和印章。竖构图。',
      en: 'Traditional Chinese ink wash painting on rice paper, misty, lots of empty space, subjects: ' + terms.join(', ') + '. No text, vertical composition.'
    };
  }

  // 页面型的站：返回它搜索页的网址（关键字换进去）
  function pageUrlFor(g, term) {
    var m = galleryById(g.id) || g;
    if (m && m.pageUrl) return m.pageUrl(term);
    var tpl = (m && m.search && m.search.tpl) || '';
    return tpl ? tpl.replace('{q}', encodeURIComponent(term)) : '';
  }

  return {
    LOCAL_COUNT: LOCAL_COUNT, DICT: DICT, GALLERIES: GALLERIES, hash: hash, poemKey: poemKey, imageryTerms: imageryTerms,
    localUrl: localUrl, localIndexFor: localIndexFor, customSearchUrl: customSearchUrl, autoMatch: autoMatch, autoMatchDirect: autoMatchDirect, autoPickNew: autoPickNew, candidates: candidates, allGalleries: allGalleries, galleryById: galleryById, pageUrlFor: pageUrlFor, testGalleries: testGalleries,
    searchGallery: searchGallery, saveCandidate: saveCandidate, resolveBackground: resolveBackground, aiPrompt: aiPrompt, loadImage: loadImage, downloadBlob: downloadBlob, testPixabayKey: testPixabayKey, testPexelsKey: testPexelsKey
  };
});
