package com.chatgpt.docviewlauncher;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final String TARGET_PACKAGE = "files.fileexplorer.filemanager";
    private static final String TARGET_ACTIVITY =
            "filemanager.manager.IOstudio.FUNC.DOC.DOCviewActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setComponent(new ComponentName(TARGET_PACKAGE, TARGET_ACTIVITY));

        try {
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(
                    this,
                    "无法打开 DOC View Activity。请确认原 File Manager 已安装，且该 Activity 允许外部启动。",
                    Toast.LENGTH_LONG
            ).show();
        } finally {
            finish();
        }
    }
}
