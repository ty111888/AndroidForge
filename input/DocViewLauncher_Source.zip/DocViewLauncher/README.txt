项目：文本编辑器（DOC View Activity 启动入口）

桌面图标名称：文本编辑器

目标应用包名：
files.fileexplorer.filemanager

目标 Activity：
filemanager.manager.IOstudio.FUNC.DOC.DOCviewActivity

启动方式：
点击本 APK 桌面图标后，通过显式 ACTION_VIEW Intent 调用目标应用的 DOCviewActivity。
不重新开发编辑功能。

重要限制：
1. 本项目是启动入口 APK，不包含原 File Manager 的编辑器代码。
2. 原 File Manager 必须安装在手机上。
3. 目标 Activity 必须允许外部应用启动；若其未导出或要求额外 Intent 数据/参数，单凭目前记录无法保证直接启动成功。
4. 本项目不会修改、卸载或更改原 File Manager 的数据与设置。

构建：
使用 Android Gradle Plugin 8.6.1，compileSdk 35，minSdk 23。
