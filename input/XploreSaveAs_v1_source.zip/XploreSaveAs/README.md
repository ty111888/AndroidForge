# X-plore 另存为助手（第一版）

## 功能
1. 从 Android 文件选择器选择一个 `text/plain` 文件。
2. 通过 `ACTION_EDIT` 调用已安装的 X-plore TextEditor：
   `com.lonelycatgames.Xplore/.ui.TextEditor`
3. 用户在 X-plore 中编辑并使用原有保存功能。
4. 返回本助手，点击“另存为…”，选择新文件名和位置；助手将当前原文件 URI 的内容复制到新文件。

## 重要边界
- 本项目不修改 X-plore APK，也不能把按钮直接插入 X-plore 自己的三点菜单。
- 第一版把“另存为”放在独立助手界面中。
- 另存时复制的是 X-plore 已保存回源 URI 的文件内容。因此请先在 X-plore 中点击它自己的保存图标，再返回助手执行另存为。
- Android 文件提供程序、X-plore 版本及 URI 授权方式可能影响写回；如果实际安装后无法保存或复制，需根据手机上的具体表现调整。

## 构建
使用 AndroidForge 上传本 ZIP。项目使用 Android Gradle Plugin 8.6.1、compileSdk 34、Java 17。
