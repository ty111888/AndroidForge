package com.example.xploresaveas;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.InputStream;
import java.io.OutputStream;

public class MainActivity extends Activity {
    private static final int REQUEST_OPEN_TEXT = 1001;
    private static final int REQUEST_SAVE_AS = 1002;

    private Uri currentUri;
    private String currentName = "document.txt";
    private TextView status;
    private Button saveAsButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildScreen();
    }

    private void buildScreen() {
        int pad = (int) (22 * getResources().getDisplayMetrics().density);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(pad, pad * 2, pad, pad);
        layout.setGravity(Gravity.CENTER_HORIZONTAL);

        TextView title = new TextView(this);
        title.setText("X-plore 文本另存为助手");
        title.setTextSize(22);
        title.setGravity(Gravity.CENTER);
        layout.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView intro = new TextView(this);
        intro.setText("选择一个 TXT 文件，交给 X-plore TextEditor 编辑并使用它原有的保存功能。返回这里后，可以把保存后的文件另存为一个新文件。");
        intro.setTextSize(16);
        intro.setPadding(0, pad, 0, pad);
        layout.addView(intro);

        Button openButton = new Button(this);
        openButton.setText("选择 TXT 并用 X-plore 编辑");
        openButton.setOnClickListener(v -> chooseTextFile());
        layout.addView(openButton, fullWidth());

        saveAsButton = new Button(this);
        saveAsButton.setText("另存为…");
        saveAsButton.setEnabled(false);
        saveAsButton.setOnClickListener(v -> chooseSaveDestination());
        LinearLayout.LayoutParams saveParams = fullWidth();
        saveParams.topMargin = pad / 2;
        layout.addView(saveAsButton, saveParams);

        status = new TextView(this);
        status.setText("尚未选择文件");
        status.setTextSize(14);
        status.setPadding(0, pad, 0, 0);
        layout.addView(status);

        setContentView(layout);
    }

    private LinearLayout.LayoutParams fullWidth() {
        return new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
    }

    private void chooseTextFile() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("text/plain");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try {
            startActivityForResult(intent, REQUEST_OPEN_TEXT);
        } catch (Exception e) {
            toast("无法打开文件选择器：" + e.getMessage());
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) {
            if (requestCode == REQUEST_SAVE_AS) {
                status.setText("另存为已取消；原文件未更改。");
            }
            return;
        }

        Uri uri = data.getData();

        if (requestCode == REQUEST_OPEN_TEXT) {
            currentUri = uri;
            int takeFlags = data.getFlags() &
                    (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            try {
                getContentResolver().takePersistableUriPermission(uri, takeFlags);
            } catch (Exception ignored) {
                // Some document providers grant only temporary access; keep the returned URI.
            }
            currentName = queryDisplayName(uri);
            launchXploreEditor(uri);
        } else if (requestCode == REQUEST_SAVE_AS) {
            copyToDestination(uri);
        }
    }

    private void launchXploreEditor(Uri uri) {
        Intent edit = new Intent(Intent.ACTION_EDIT);
        edit.setClassName(
                "com.lonelycatgames.Xplore",
                "com.lonelycatgames.Xplore.ui.TextEditor");
        edit.setDataAndType(uri, "text/plain");
        edit.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        try {
            status.setText("正在交给 X-plore TextEditor。编辑并使用原来的保存图标保存后，返回本助手即可另存为。");
            startActivityForResult(edit, 2001);
            saveAsButton.setEnabled(true);
        } catch (Exception e) {
            // Some versions may not accept an explicit component; try the EDIT intent resolver.
            try {
                Intent fallback = new Intent(Intent.ACTION_EDIT);
                fallback.setDataAndType(uri, "text/plain");
                fallback.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                        | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                startActivityForResult(fallback, 2001);
                saveAsButton.setEnabled(true);
            } catch (Exception second) {
                status.setText("无法启动 X-plore TextEditor。请确认已安装 X-plore。");
                toast("启动 TextEditor 失败");
            }
        }
    }

    private void chooseSaveDestination() {
        if (currentUri == null) {
            toast("请先选择并编辑一个 TXT 文件");
            return;
        }
        String suggested = currentName;
        if (!suggested.toLowerCase().endsWith(".txt")) {
            suggested += ".txt";
        }
        Intent create = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        create.addCategory(Intent.CATEGORY_OPENABLE);
        create.setType("text/plain");
        create.putExtra(Intent.EXTRA_TITLE, suggested);
        create.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        startActivityForResult(create, REQUEST_SAVE_AS);
    }

    private void copyToDestination(Uri destination) {
        try (InputStream in = getContentResolver().openInputStream(currentUri);
             OutputStream out = getContentResolver().openOutputStream(destination, "w")) {
            if (in == null || out == null) {
                throw new IllegalStateException("文件无法读取或写入");
            }
            byte[] buffer = new byte[8192];
            int count;
            while ((count = in.read(buffer)) != -1) {
                out.write(buffer, 0, count);
            }
            out.flush();
            status.setText("另存成功：" + queryDisplayName(destination));
            toast("另存成功");
        } catch (Exception e) {
            status.setText("另存失败：" + e.getMessage());
            toast("另存失败，请检查文件访问权限和存储位置");
        }
    }

    private String queryDisplayName(Uri uri) {
        android.database.Cursor cursor = null;
        try {
            cursor = getContentResolver().query(uri,
                    new String[]{android.provider.OpenableColumns.DISPLAY_NAME},
                    null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);
                if (index >= 0) return cursor.getString(index);
            }
        } catch (Exception ignored) {
        } finally {
            if (cursor != null) cursor.close();
        }
        return "document.txt";
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }
}
