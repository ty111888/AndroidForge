package com.example.texteditorlauncher;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Intent intent = new Intent();
        intent.setComponent(new ComponentName(
                "com.lonelycatgames.Xplore",
                "com.lonelycatgames.Xplore.ui.TextEditor"
        ));

        try {
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(
                    this,
                    "无法启动 X-plore Text Editor。请确认 X-plore 已安装。",
                    Toast.LENGTH_LONG
            ).show();
        }
        finish();
    }
}
