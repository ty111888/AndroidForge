Text Editor launcher source project

App label: Text Editor
Launcher activity: com.example.texteditorlauncher.MainActivity
Target component:
  package: com.lonelycatgames.Xplore
  activity: com.lonelycatgames.Xplore.ui.TextEditor

Behavior:
- Adds a normal launcher icon named "Text Editor".
- Tapping it explicitly starts the existing X-plore TextEditor activity.
- Does not contain or replace the editor implementation.
- Does not modify X-plore.

Important:
This source project has not yet been compiled or tested on the user's phone.
The direct Activity launch was previously confirmed by the user through the APK/Activity list.
If X-plore's activity requires a file URI or a particular intent action on this device,
the launcher may need that exact intent configuration.
