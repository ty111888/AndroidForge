# 诗境 · 古诗词搜索：Android APK 构建说明

## 这是什么

这个压缩包包含完整 Expo/React Native/TypeScript 源码，但当前会话不能直接产出 APK 二进制。使用 Manus Dashboard 的 Android Build 或 Expo/EAS 构建即可生成 APK。

## 已集成功能

- GitHub `chinese-poetry` 的全唐诗、全宋诗、全宋词全部 JSON 分片搜索；首次读取后建立全量缓存。
- 搜索字段：全部、诗题、作者、正文、朝代。
- 独立朝代范围：全部朝代、先秦、秦、汉、魏晋、南北朝、隋、唐、五代、宋、辽、金、元、明、清、近现代。当前核心库实际有数据的唐、宋可选；其他朝代明确显示“暂无”。
- 正文同一句多关键词：用空格分隔关键词，关键词必须出现在同一标点分隔句内，不跨逗号、句号、问号、叹号、分号、冒号、顿号或换行。
- 简体输入匹配部分繁体原文，例如“朝辞  彩云间”可找到“朝辭白帝彩雲間”。
- App 内麦克风按钮：使用 `expo-speech-recognition` 调用 Android SpeechRecognizer / iOS SFSpeechRecognizer，识别结果先填入搜索框，用户编辑后再点击搜索。
- 详情页按需生成水墨配图：点击“生成诗意水墨图”后调用平台图片服务，生成结果保存到对象存储并在服务进程内按诗词 ID 缓存；失败显示重试提示。
- 五个外部入口：搜韵、每日诗词、中华诗库、古文岛、识典古籍。它们是第三方网页入口，不冒充本地数据库，也不改变本地同句搜索逻辑。

## 用 Expo EAS 构建 APK

```bash
unzip shijing-source-final.zip
cd shijing
pnpm install
npx expo login
npx eas login
npx eas build:configure
npx eas build --platform android --profile preview
```

`preview` 通常会生成可直接安装的 APK；生产发布一般生成 AAB。语音识别依赖原生 config plugin，因此必须使用 Expo Development Build/EAS APK，不能只依赖普通 Expo Go。

## 运行前端和 API

```bash
pnpm install
pnpm dev
```

安装后的 APK 需要一个长期可访问的 API 地址，并通过 `EXPO_PUBLIC_API_BASE_URL` 配置。当前会话开发地址是临时预览地址，不保证长期有效。图片生成功能需要部署环境提供内置图片服务和对象存储配置。

## 项目入口

- `app/(tabs)/index.tsx`：本地全量搜索、字段/朝代筛选、同句匹配、语音按钮、五个外部入口。
- `app/poem/[id].tsx`：诗词详情、按需水墨图生成、失败重试状态。
- `server/routers.ts`：GitHub 全量数据接入、搜索过滤和图片生成接口。
- `server/_core/imageGeneration.ts`：平台图片生成与对象存储转存。
- `app.config.ts`：Expo/Android 配置、麦克风和语音识别权限插件。
