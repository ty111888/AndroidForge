import { Stack, useLocalSearchParams, useRouter } from "expo-router";
import { Image } from "expo-image";
import { useState } from "react";
import { Pressable, ScrollView, StyleSheet, Text, View } from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { trpc } from "@/lib/trpc";

export default function PoemDetailScreen() {
  const router = useRouter();
  const params = useLocalSearchParams<{
    id?: string;
    title?: string;
    author?: string;
    dynasty?: string;
    content?: string;
    source?: string;
  }>();
  const title = params.title ?? "无题";
  const author = params.author ?? "佚名";
  const dynasty = params.dynasty ?? "古代";
  const content = params.content ?? "暂无正文";
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const imageMutation = trpc.poetry.generateImage.useMutation({
    onSuccess: (result) => setImageUrl(result.url),
  });

  const createImage = () => {
    imageMutation.mutate({
      id: params.id ?? `${dynasty}-${author}-${title}`,
      title,
      author,
      dynasty,
      content,
    });
  };

  return (
    <ScreenContainer containerClassName="bg-[#F7F4EE]" safeAreaClassName="bg-[#F7F4EE]" className="px-5">
      <Stack.Screen options={{ headerShown: false }} />
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.content}>
        <Pressable onPress={() => router.back()} style={styles.backButton} accessibilityRole="button">
          <Text style={styles.backArrow}>‹</Text>
          <Text style={styles.backText}>返回诗页</Text>
        </Pressable>
        <View style={styles.rule} />
        <Text style={styles.kicker}>{dynasty} · {author}</Text>
        <Text style={styles.title}>{title}</Text>
        <View style={styles.authorLine}>
          <View style={styles.dot} />
          <Text style={styles.authorText}>{author} · {dynasty}</Text>
          <View style={styles.dot} />
        </View>
        <View style={styles.poemPaper}>
          <View style={styles.redLine} />
          <Text style={styles.body}>{content}</Text>
          <Text style={styles.source}>数据来源 · {params.source === "chinese-poetry" ? "chinese-poetry" : "离线示例"}</Text>
        </View>
        <View style={styles.imageSection}>
          <View style={styles.imageHeading}>
            <Text style={styles.imageKicker}>意境配图</Text>
            <Text style={styles.imageNote}>按需生成 · 生成后缓存</Text>
          </View>
          {imageUrl ? (
            <Image source={{ uri: imageUrl }} contentFit="cover" style={styles.poemImage} />
          ) : (
            <View style={styles.imagePlaceholder}>
              <Text style={styles.imagePlaceholderText}>一卷诗页，留一方水墨</Text>
            </View>
          )}
          <Pressable
            onPress={createImage}
            disabled={imageMutation.isPending}
            style={({ pressed }) => [styles.imageButton, pressed && styles.pressed, imageMutation.isPending && styles.buttonDisabled]}
          >
            <Text style={styles.imageButtonText}>{imageMutation.isPending ? "正在生成水墨图…" : imageUrl ? "重新生成水墨图" : "生成诗意水墨图"}</Text>
          </Pressable>
          {imageMutation.isError ? <Text style={styles.imageError}>生成失败，请检查网络后重试。</Text> : null}
        </View>
        <Text style={styles.footerNote}>愿每一次翻阅，都有一句话与你相逢。</Text>
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  content: { paddingTop: 18, paddingBottom: 52 },
  backButton: { flexDirection: "row", alignItems: "center", minHeight: 42, alignSelf: "flex-start" },
  backArrow: { color: "#B84A3A", fontSize: 34, lineHeight: 30, marginRight: 5, fontFamily: "serif" },
  backText: { color: "#6F6A61", fontSize: 13, fontWeight: "700" },
  rule: { height: 1, backgroundColor: "#DDD8CD", marginTop: 10, marginBottom: 38 },
  kicker: { color: "#B84A3A", fontSize: 12, letterSpacing: 2, fontWeight: "800", textAlign: "center" },
  title: { color: "#24231F", fontSize: 31, lineHeight: 42, fontWeight: "800", fontFamily: "serif", textAlign: "center", marginTop: 13 },
  authorLine: { flexDirection: "row", justifyContent: "center", alignItems: "center", marginTop: 14, gap: 10 },
  dot: { width: 4, height: 4, borderRadius: 2, backgroundColor: "#B84A3A" },
  authorText: { color: "#8B877D", fontSize: 13 },
  poemPaper: { backgroundColor: "#FFFDF9", borderWidth: 1, borderColor: "#E7E0D4", borderRadius: 17, marginTop: 36, paddingVertical: 32, paddingHorizontal: 26, shadowColor: "#6E543E", shadowOpacity: 0.06, shadowRadius: 14, shadowOffset: { width: 0, height: 6 }, elevation: 2 },
  redLine: { width: 28, height: 3, borderRadius: 2, backgroundColor: "#B84A3A", marginBottom: 23 },
  body: { color: "#34322D", fontSize: 19, lineHeight: 38, fontFamily: "serif", letterSpacing: 1.1 },
  source: { color: "#AAA399", fontSize: 10, marginTop: 28, paddingTop: 14, borderTopWidth: 1, borderTopColor: "#EFE9DE" },
  footerNote: { color: "#A09A90", fontSize: 12, textAlign: "center", marginTop: 24, fontFamily: "serif" },
  imageSection: { marginTop: 28 },
  imageHeading: { flexDirection: "row", alignItems: "baseline", justifyContent: "space-between", marginBottom: 10 },
  imageKicker: { color: "#B84A3A", fontSize: 11, letterSpacing: 1.6, fontWeight: "800" },
  imageNote: { color: "#AAA399", fontSize: 10 },
  imagePlaceholder: { height: 190, borderRadius: 16, backgroundColor: "#E8E0D2", alignItems: "center", justifyContent: "center", borderWidth: 1, borderColor: "#D8CDBD" },
  imagePlaceholderText: { color: "#8B7A68", fontSize: 15, fontFamily: "serif" },
  poemImage: { width: "100%", height: 230, borderRadius: 16, backgroundColor: "#E8E0D2" },
  imageButton: { marginTop: 12, borderRadius: 12, backgroundColor: "#7C6653", minHeight: 44, alignItems: "center", justifyContent: "center" },
  imageButtonText: { color: "#FFF9F0", fontSize: 13, fontWeight: "700" },
  buttonDisabled: { opacity: 0.65 },
  imageError: { color: "#B84A3A", fontSize: 11, textAlign: "center", marginTop: 8 },
  pressed: { opacity: 0.8 },
});
