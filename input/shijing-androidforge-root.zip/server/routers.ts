import { z } from "zod";

import { getSessionCookieName, getSessionCookieOptions } from "./_core/cookies";
import { generateImage } from "./_core/imageGeneration";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";

type RemotePoem = {
  title?: string;
  author?: string;
  paragraphs?: string[];
  content?: string[];
  rhythmic?: string;
};

type PoetryResult = {
  id: string;
  title: string;
  author: string;
  dynasty: string;
  content: string;
  source: "chinese-poetry" | "fallback";
};

const SEARCH_FIELDS = ["all", "title", "author", "content", "dynasty"] as const;
type SearchField = (typeof SEARCH_FIELDS)[number];
const DYNASTIES = ["all", "先秦", "秦", "汉", "魏晋", "南北朝", "隋", "唐", "五代", "宋", "辽", "金", "元", "明", "清", "近现代"] as const;
type DynastyFilter = (typeof DYNASTIES)[number];

type RepositoryTreeEntry = {
  path: string;
  type: string;
};

type DatasetGroup = {
  key: "tang" | "song-poem" | "song-ci";
  dynasty: "唐" | "宋";
  prefix: string;
};

const REPOSITORY_TREE_URL =
  "https://api.github.com/repos/chinese-poetry/chinese-poetry/git/trees/master?recursive=1";

// The upstream repository stores the complete collections as numbered JSON shards.
// Do not replace these with a single sample shard: every matching .json file is loaded.
const DATASET_GROUPS: DatasetGroup[] = [
  { key: "tang", dynasty: "唐", prefix: "全唐诗/poet.tang." },
  { key: "song-poem", dynasty: "宋", prefix: "全唐诗/poet.song." },
  { key: "song-ci", dynasty: "宋", prefix: "宋词/ci.song." },
];

// The upstream collections mix simplified and traditional Chinese. Keep the
// search experience friendly for simplified input, including the user's
// example “朝辞  彩云间” against “朝辭白帝彩雲間”.
const TRADITIONAL_TO_SIMPLIFIED: Record<string, string> = {
  辭: "辞",
  雲: "云",
  間: "间",
  發: "发",
  還: "还",
  詩: "诗",
  詞: "词",
  國: "国",
  風: "风",
  長: "长",
  萬: "万",
  與: "与",
  無: "无",
  為: "为",
  來: "来",
  見: "见",
  時: "时",
  處: "处",
  聞: "闻",
  鳥: "鸟",
};

const FALLBACK_POEMS: PoetryResult[] = [
  {
    id: "fallback-1",
    title: "静夜思",
    author: "李白",
    dynasty: "唐",
    content: "床前明月光，疑是地上霜。\n举头望明月，低头思故乡。",
    source: "fallback",
  },
  {
    id: "fallback-2",
    title: "春晓",
    author: "孟浩然",
    dynasty: "唐",
    content: "春眠不觉晓，处处闻啼鸟。\n夜来风雨声，花落知多少。",
    source: "fallback",
  },
  {
    id: "fallback-3",
    title: "水调歌头·明月几时有",
    author: "苏轼",
    dynasty: "宋",
    content: "明月几时有？把酒问青天。\n不知天上宫阙，今夕是何年。",
    source: "fallback",
  },
];

let cachedRemote: PoetryResult[] | null = null;
let cachePromise: Promise<PoetryResult[]> | null = null;
let manifestPromise: Promise<Array<{ group: DatasetGroup; path: string }>> | null = null;
const generatedImageCache = new Map<string, string>();

async function fetchJson<T>(url: string, attempts = 3): Promise<T> {
  let lastError: unknown;
  for (let attempt = 1; attempt <= attempts; attempt += 1) {
    try {
      const response = await fetch(url, {
        headers: {
          Accept: "application/json",
          "User-Agent": "shijing-poetry-search/1.0",
        },
      });
      if (!response.ok) throw new Error(`${response.status} ${response.statusText}`);
      return (await response.json()) as T;
    } catch (error) {
      lastError = error;
      if (attempt < attempts) await new Promise((resolve) => setTimeout(resolve, 400 * attempt));
    }
  }
  throw lastError instanceof Error ? lastError : new Error("Remote dataset request failed");
}

async function getDatasetManifest() {
  if (!manifestPromise) {
    manifestPromise = fetchJson<{ tree?: RepositoryTreeEntry[] }>(REPOSITORY_TREE_URL).then((tree) => {
      const entries = (tree.tree ?? [])
        .filter((entry) => entry.type === "blob" && entry.path.endsWith(".json"))
        .flatMap((entry) => {
          const group = DATASET_GROUPS.find((candidate) => entry.path.startsWith(candidate.prefix));
          return group ? [{ group, path: entry.path }] : [];
        })
        .sort((a, b) => a.path.localeCompare(b.path, "en"));

      for (const group of DATASET_GROUPS) {
        if (!entries.some((entry) => entry.group.key === group.key)) {
          throw new Error(`No complete dataset shards found for ${group.key}`);
        }
      }
      return entries;
    });
  }
  return manifestPromise;
}

async function mapWithConcurrency<T, R>(items: T[], limit: number, worker: (item: T) => Promise<R>) {
  const results = new Array<R>(items.length);
  let nextIndex = 0;
  async function runWorker() {
    while (nextIndex < items.length) {
      const index = nextIndex;
      nextIndex += 1;
      results[index] = await worker(items[index]);
    }
  }
  await Promise.all(Array.from({ length: Math.min(limit, items.length) }, () => runWorker()));
  return results;
}

function normalizePoem(poem: RemotePoem, group: DatasetGroup, shardPath: string, index: number): PoetryResult {
  return {
    id: `${group.key}-${shardPath.replace(/[^a-zA-Z0-9]+/g, "-")}-${index}`,
    title: poem.title?.trim() || poem.rhythmic?.trim() || "无题",
    author: poem.author?.trim() || "佚名",
    dynasty: group.dynasty,
    content: (poem.paragraphs ?? poem.content ?? []).join("\n").trim() || "暂无正文",
    source: "chinese-poetry",
  };
}

async function fetchDatasetShard(group: DatasetGroup, path: string) {
  const encodedPath = path.split("/").map(encodeURIComponent).join("/");
  const url = `https://raw.githubusercontent.com/chinese-poetry/chinese-poetry/master/${encodedPath}`;
  const payload = await fetchJson<RemotePoem[]>(url);
  return payload.map((poem, index) => normalizePoem(poem, group, path, index));
}

async function getPoems(): Promise<PoetryResult[]> {
  if (cachedRemote) return cachedRemote;
  if (!cachePromise) {
    cachePromise = getDatasetManifest()
      .then((manifest) => mapWithConcurrency(manifest, 8, (entry) => fetchDatasetShard(entry.group, entry.path)))
      .then((groups) => groups.flat())
      .then((poems) => {
        cachedRemote = poems;
        return poems;
      })
      .catch(() => FALLBACK_POEMS)
      .finally(() => {
        cachePromise = null;
      });
  }
  return cachePromise;
}

function splitKeywords(query: string) {
  return query
    .trim()
    .toLocaleLowerCase()
    .replace(/[辭雲間發還詩詞國風長萬與無為來見時處聞鳥]/g, (character) => TRADITIONAL_TO_SIMPLIFIED[character] ?? character)
    .split(/\s+/)
    .filter(Boolean);
}

function normalizeSearchText(value: string) {
  return value
    .toLocaleLowerCase()
    .replace(/[辭雲間發還詩詞國風長萬與無為來見時處聞鳥]/g, (character) => TRADITIONAL_TO_SIMPLIFIED[character] ?? character);
}

function matchesSameSentence(content: string, keywords: string[]) {
  if (keywords.length === 0) return true;
  const sentences = normalizeSearchText(content).split(/[，。！？；：、,.!?;:\n]+/);
  return sentences.some((sentence) => keywords.every((keyword) => sentence.includes(keyword)));
}

function matchesField(poem: PoetryResult, keywords: string[], field: SearchField) {
  if (keywords.length === 0) return true;
  if (field === "content") return matchesSameSentence(poem.content, keywords);
  if (field === "all") {
    return (
      matchesSameSentence(poem.content, keywords) ||
      [poem.title, poem.author, poem.dynasty].some((value) => {
        const normalized = normalizeSearchText(value);
        return keywords.every((keyword) => normalized.includes(keyword));
      })
    );
  }
  const value = normalizeSearchText(poem[field]);
  return keywords.every((keyword) => value.includes(keyword));
}

function matchesDynasty(poem: PoetryResult, dynasty: DynastyFilter) {
  return dynasty === "all" || poem.dynasty === dynasty;
}

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(getSessionCookieName(ctx.req), {
        ...cookieOptions,
        maxAge: -1,
      });
      return { success: true } as const;
    }),
  }),
  poetry: router({
    search: publicProcedure
      .input(
        z.object({
          query: z.string().max(120).default(""),
          field: z.enum(SEARCH_FIELDS).default("all"),
          dynasty: z.enum(DYNASTIES).default("all"),
        }),
      )
      .query(async ({ input }) => {
        const allPoems = await getPoems();
        const keywords = splitKeywords(input.query);
        const results = allPoems.filter(
          (poem) => matchesDynasty(poem, input.dynasty) && matchesField(poem, keywords, input.field),
        );

        return {
          items: results.slice(0, 30),
          total: results.length,
          source: cachedRemote ? "chinese-poetry" : "fallback",
        };
      }),
    generateImage: publicProcedure
      .input(
        z.object({
          id: z.string().max(200),
          title: z.string().max(200),
          author: z.string().max(100),
          dynasty: z.string().max(30),
          content: z.string().max(5000),
        }),
      )
      .mutation(async ({ input }) => {
        const cached = generatedImageCache.get(input.id);
        if (cached) return { url: cached, cached: true };
        const { url } = await generateImage({
          quality: "medium",
          prompt: `中国古典诗词意境水墨画，宣纸肌理，宋代写意山水风格。诗题：${input.title}；作者：${input.author}；朝代：${input.dynasty}。画面意境参考诗文：${input.content.slice(0, 800)}。不要出现文字、印章、现代物件，构图留白雅致，适合手机详情页。`,
        });
        if (!url) throw new Error("图片生成服务未返回图片地址");
        generatedImageCache.set(input.id, url);
        return { url, cached: false };
      }),
  }),
});

export type AppRouter = typeof appRouter;
