# 诗境 AndroidForge 专用构建说明

这个包已经按 AndroidForge 的 **Gradle 项目输入格式**准备，不再只是纯 Expo 源码包。

## AndroidForge 识别入口

ZIP 根目录现在直接包含：

```text
settings.gradle
build.gradle
gradlew
gradle/wrapper/gradle-wrapper.properties
gradle/wrapper/gradle-wrapper.jar
```

真正的 Expo 生成 Android 工程保留在：

```text
android/
├── app/
├── settings.gradle
├── build.gradle
└── gradlew
```

根目录的 `gradlew` 是 AndroidForge 转发入口，会：

1. 在 AndroidForge 没有 Node.js 时下载 Node.js 22.13.0；
2. 在源码根目录执行 `npm install`；
3. 转发到 `android/gradlew`；
4. 使用 Gradle 8.14 构建 Android APK。

## Gradle 版本

根目录和 `android/` 目录的 wrapper 都固定为：

```text
gradle-8.14-bin.zip
```

## AndroidForge 操作

`input/` 中只保留一个 ZIP：

```text
shijing-androidforge-root.zip
```

手动运行 `Build Android APK` 时选择：

```text
zip_source = input-directory
zip_path = input/shijing-androidforge-root.zip
build_variant = debug
```

AndroidForge 应该识别为 Gradle 项目，并运行：

```text
./gradlew assembleDebug
```

项目已将 React Native 的 `debuggableVariants` 设为空，因此 `assembleDebug` 会把 JS bundle 和资源打进 APK；安装后不需要另外运行 Metro，不会停在启动画面。

注意：完整诗库搜索接口仍需要通过 `EXPO_PUBLIC_API_BASE_URL` 提供一个手机可访问的长期 HTTPS API 地址。没有 API 地址时，应用仍应打开首页，但搜索会提示网络/API 不可用。

根目录的 wrapper 会把命令转发到 `android/gradlew`。

## 不应再出现的内容

```text
flutter build apk
harmonyMusic-src
com/anandnet/harmonymusic
```

ZIP 不包含 `node_modules`、Gradle 缓存、SDK 路径、构建产物或日志目录。AndroidForge 会在临时 workspace 中安装依赖并写入 `local.properties`。
