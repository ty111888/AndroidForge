import { useMemo, useState } from "react";
import {
  ActivityIndicator,
  FlatList,
  Keyboard,
  Linking,
  Pressable,
  RefreshControl,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { useRouter } from "expo-router";
import { ExpoSpeechRecognitionModule, useSpeechRecognitionEvent } from "expo-speech-recognition";

import { ScreenContainer } from "@/components/screen-container";
import { trpc } from "@/lib/trpc";

type PoetryItem = {
  id: string;
  title: string;
  author: string;
  dynasty: string;
  content: string;
  source: "chinese-poetry" | "fallback";
};

const HOT_KEYWORDS = ["明月", "春风", "李白", "苏轼", "思乡"];
const EXTERNAL_SOURCES = [
  { name: "搜韵", url: "https://sou-yun.cn/QueryPoem.aspx" },
  { name: "每日诗词", url: "https://meirishici.com/poetries" },
  { name: "中华诗库", url: "https://www.shigeku.org/shiku/gs/index.htm" },
  { name: "古文岛", url: "https://www.gushiwen.cn/search.aspx?value=" },
  { name: "识典古籍", url: "https://www.shidianguji.com/zh/search" },
] as const;
const SEARCH_FIELDS = [
  { key: "all", label: "全部" },
  { key: "title", label: "诗题" },
  { key: "author", label: "作者" },
  { key: "content", label: "正文" },
  { key: "dynasty", label: "朝代" },
] as const;
type SearchField = (typeof SEARCH_FIELDS)[number]["key"];
const DYNASTIES = ["all", "先秦", "秦", "汉", "魏晋", "南北朝", "隋", "唐", "五代", "宋", "辽", "金", "元", "明", "清", "近现代"] as const;
type DynastyFilter = (typeof DYNASTIES)[number];
const AVAILABLE_DYNASTIES = new Set<DynastyFilter>(["all", "唐", "宋"]);

function excerpt(content: string) {
  const compact = content.replace(/\n/g, " · ");
  return compact.length > 58 ? `${compact.slice(0, 58)}…` : compact;
}

export default function HomeScreen() {
  const router = useRouter();
  const [query, setQuery] = useState("");
  const [submittedQuery, setSubmittedQuery] = useState("");
  const [searchField, setSearchField] = useState<SearchField>("all");
  const [dynastyFilter, setDynastyFilter] = useState<DynastyFilter>("all");
  const [recognizing, setRecognizing] = useState(false);
  const [speechError, setSpeechError] = useState("");
  const [refreshing, setRefreshing] = useState(false);
  const search = trpc.poetry.search.useQuery(
    { query: submittedQuery, field: searchField, dynasty: dynastyFilter },
    {
      staleTime: 1000 * 60 * 10,
      // Do not download every upstream JSON shard during the splash/first
      // render. The full library is loaded only after the user searches.
      enabled: submittedQuery.length > 0,
    },
  );

  const items = useMemo(() => (search.data?.items ?? []) as PoetryItem[], [search.data?.items]);

  const doSearch = (nextQuery = query) => {
    Keyboard.dismiss();
    setSubmittedQuery(nextQuery.trim());
  };

  useSpeechRecognitionEvent("start", () => {
    setRecognizing(true);
    setSpeechError("");
  });
  useSpeechRecognitionEvent("end", () => setRecognizing(false));
  useSpeechRecognitionEvent("result", (event) => {
    const transcript = event.results[0]?.transcript ?? "";
    if (transcript) setQuery(transcript);
  });
  useSpeechRecognitionEvent("error", (event) => {
    setRecognizing(false);
    setSpeechError(event.message || "语音识别没有完成，请重试");
  });

  const startVoiceSearch = async () => {
    setSpeechError("");
    const permission = await ExpoSpeechRecognitionModule.requestPermissionsAsync();
    if (!permission.granted) {
      setSpeechError("请允许麦克风和语音识别权限");
      return;
    }
    ExpoSpeechRecognitionModule.start({ lang: "zh-CN", interimResults: true, continuous: false });
  };

  const openPoem = (item: PoetryItem) => {
    router.push({
      pathname: "/poem/[id]",
      params: {
        id: item.id,
        title: item.title,
        author: item.author,
        dynasty: item.dynasty,
        content: item.content,
        source: item.source,
      },
    });
  };

  const header = (
    <View>
      <View style={styles.brandRow}>
        <View style={styles.seal}>
          <Text style={styles.sealText}>诗</Text>
        </View>
        <View style={styles.brandCopy}>
          <Text style={styles.brandName}>诗境</Text>
          <Text style={styles.brandSub}>古诗词搜索案头</Text>
        </View>
        <Text style={styles.counter}>{search.data?.total ? `${search.data.total} 首` : ""}</Text>
      </View>
      <View style={styles.rule} />

      <View style={styles.hero}>
        <Text style={styles.eyebrow}>CHINESE POETRY · SEARCH</Text>
        <Text style={styles.heroTitle}>让一句诗，{"\n"}重新被看见</Text>
        <Text style={styles.heroBody}>从题名、作者或正文开始寻找，{ "\n" }在古典文字里遇见当时的心情。</Text>
      </View>

      <View style={styles.searchShell}>
        <TextInput
          value={query}
          onChangeText={setQuery}
          onSubmitEditing={() => doSearch()}
          returnKeyType="search"
          placeholder="搜诗题、作者、正文或朝代"
          placeholderTextColor="#9B9A93"
          style={styles.input}
          accessibilityLabel="搜索古诗词"
        />
        <Pressable
          onPress={() => (recognizing ? ExpoSpeechRecognitionModule.stop() : void startVoiceSearch())}
          style={({ pressed }) => [styles.micButton, recognizing && styles.micButtonActive, pressed && styles.pressed]}
          accessibilityRole="button"
          accessibilityLabel={recognizing ? "停止语音识别" : "开始语音识别"}
        >
          <Text style={styles.micText}>{recognizing ? "■" : "麦"}</Text>
        </Pressable>
        <Pressable
          onPress={() => doSearch()}
          style={({ pressed }) => [styles.searchButton, pressed && styles.pressed]}
          accessibilityRole="button"
          accessibilityLabel="开始搜索"
        >
          <Text style={styles.searchIcon}>⌕</Text>
        </Pressable>
      </View>

      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.fieldList}>
        {SEARCH_FIELDS.map((field) => (
          <Pressable
            key={field.key}
            onPress={() => setSearchField(field.key)}
            style={[styles.fieldPill, searchField === field.key && styles.fieldPillActive]}
          >
            <Text style={[styles.fieldText, searchField === field.key && styles.fieldTextActive]}>{field.label}</Text>
          </Pressable>
        ))}
      </ScrollView>
      <Text style={styles.searchHint}>
        正文模式支持空格分隔多个词：例如「朝辞  彩云间」，只匹配同一句诗。
      </Text>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.dynastyList}>
        {DYNASTIES.map((dynasty) => {
          const available = AVAILABLE_DYNASTIES.has(dynasty);
          return (
            <Pressable
              key={dynasty}
              disabled={!available}
              onPress={() => setDynastyFilter(dynasty)}
              style={[styles.dynastyPill, dynastyFilter === dynasty && styles.dynastyPillActive, !available && styles.dynastyPillDisabled]}
            >
              <Text style={[styles.dynastyFilterText, dynastyFilter === dynasty && styles.dynastyFilterTextActive]}>
                {dynasty === "all" ? "全部朝代" : dynasty}{!available && dynasty !== "all" ? " · 暂无" : ""}
              </Text>
            </Pressable>
          );
        })}
      </ScrollView>
      {speechError ? <Text style={styles.speechError}>{speechError}</Text> : null}

      <View style={styles.hotRow}>
        <Text style={styles.hotLabel}>热门</Text>
        <FlatList
          data={HOT_KEYWORDS}
          horizontal
          showsHorizontalScrollIndicator={false}
          keyExtractor={(item) => item}
          contentContainerStyle={styles.hotList}
          renderItem={({ item }) => (
            <Pressable
              onPress={() => {
                setQuery(item);
                doSearch(item);
              }}
              style={({ pressed }) => [styles.hotPill, pressed && styles.pressed]}
            >
              <Text style={styles.hotText}>{item}</Text>
            </Pressable>
          )}
        />
      </View>

      <View style={styles.externalHeader}>
        <Text style={styles.sectionKicker}>外部诗词库</Text>
        <Text style={styles.externalNote}>点击后打开对应网站搜索页</Text>
      </View>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.externalList}>
        {EXTERNAL_SOURCES.map((source) => (
          <Pressable
            key={source.name}
            onPress={() => void Linking.openURL(source.url)}
            style={({ pressed }) => [styles.externalPill, pressed && styles.pressed]}
            accessibilityRole="link"
            accessibilityLabel={`打开${source.name}搜索`}
          >
            <Text style={styles.externalText}>{source.name}</Text>
            <Text style={styles.externalArrow}>↗</Text>
          </Pressable>
        ))}
      </ScrollView>

      <View style={styles.sectionHeading}>
        <View>
          <Text style={styles.sectionKicker}>{submittedQuery ? "SEARCH RESULT" : "RECOMMENDED READS"}</Text>
          <Text style={styles.sectionTitle}>{submittedQuery ? `关于「${submittedQuery}」` : "今日诗页"}</Text>
        </View>
        {search.isFetching ? <ActivityIndicator color="#B84A3A" /> : null}
      </View>
    </View>
  );

  return (
    <ScreenContainer containerClassName="bg-[#F7F4EE]" safeAreaClassName="bg-[#F7F4EE]" className="px-5">
      <FlatList
        data={items}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <Pressable
            onPress={() => openPoem(item)}
            style={({ pressed }) => [styles.poemCard, pressed && styles.cardPressed]}
          >
            <View style={styles.cardTopLine}>
              <Text style={styles.dynasty}>{item.dynasty} · {item.author}</Text>
              <Text style={styles.chevron}>›</Text>
            </View>
            <Text style={styles.poemTitle}>{item.title}</Text>
            <Text style={styles.excerpt} numberOfLines={2}>{excerpt(item.content)}</Text>
            <View style={styles.cardFooter}>
              <Text style={styles.readLabel}>阅 读 全 文</Text>
              <View style={styles.sourceDot} />
              <Text style={styles.sourceLabel}>{item.source === "chinese-poetry" ? "chinese-poetry" : "离线示例"}</Text>
            </View>
          </Pressable>
        )}
        ListHeaderComponent={header}
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl
            refreshing={refreshing && search.isFetching}
            onRefresh={() => {
              setRefreshing(true);
              search.refetch().finally(() => setRefreshing(false));
            }}
            tintColor="#B84A3A"
          />
        }
        ListEmptyComponent={
          !submittedQuery ? (
            <View style={styles.stateBox}>
              <Text style={styles.stateMark}>⌕</Text>
              <Text style={styles.stateTitle}>从一句关键词开始</Text>
              <Text style={styles.stateBody}>输入诗题、作者或正文，诗境会在完整诗库中检索。</Text>
            </View>
          ) : search.isLoading ? (
            <View style={styles.stateBox}>
              <ActivityIndicator color="#B84A3A" size="large" />
              <Text style={styles.stateTitle}>正在翻阅诗页</Text>
              <Text style={styles.stateBody}>首次读取全量诗库，可能需要稍等片刻。</Text>
            </View>
          ) : search.isError ? (
            <View style={styles.stateBox}>
              <Text style={styles.stateMark}>!</Text>
              <Text style={styles.stateTitle}>诗页暂时无法打开</Text>
              <Text style={styles.stateBody}>请检查网络后下拉刷新。</Text>
              <Pressable onPress={() => search.refetch()} style={styles.retryButton}>
                <Text style={styles.retryText}>重新读取</Text>
              </Pressable>
            </View>
          ) : (
            <View style={styles.stateBox}>
              <Text style={styles.stateMark}>⌁</Text>
              <Text style={styles.stateTitle}>没有找到这句诗</Text>
              <Text style={styles.stateBody}>换个关键词，也许会遇见新的答案。</Text>
            </View>
          )
        }
      />
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  content: { paddingTop: 18, paddingBottom: 42 },
  brandRow: { flexDirection: "row", alignItems: "center", minHeight: 48 },
  seal: { width: 42, height: 42, borderRadius: 12, backgroundColor: "#B84A3A", alignItems: "center", justifyContent: "center", transform: [{ rotate: "-4deg" }] },
  sealText: { color: "#FFF9F0", fontSize: 23, fontWeight: "700", fontFamily: "serif" },
  brandCopy: { marginLeft: 10 },
  brandName: { color: "#24231F", fontSize: 18, fontWeight: "800", letterSpacing: 2 },
  brandSub: { color: "#8B877D", fontSize: 11, marginTop: 2, letterSpacing: 1 },
  counter: { marginLeft: "auto", color: "#B84A3A", fontSize: 12, fontWeight: "700" },
  rule: { height: 1, backgroundColor: "#DDD8CD", marginTop: 16 },
  hero: { paddingTop: 28, paddingBottom: 22 },
  eyebrow: { color: "#B84A3A", fontSize: 10, letterSpacing: 2.2, fontWeight: "800", marginBottom: 12 },
  heroTitle: { color: "#24231F", fontSize: 30, lineHeight: 38, fontWeight: "800", fontFamily: "serif", letterSpacing: 1 },
  heroBody: { color: "#77736B", fontSize: 13, lineHeight: 22, marginTop: 14 },
  searchShell: { height: 54, borderRadius: 15, borderWidth: 1, borderColor: "#DED8CC", backgroundColor: "#FFFCF7", flexDirection: "row", alignItems: "center", paddingLeft: 16, paddingRight: 6, shadowColor: "#8B5E3C", shadowOpacity: 0.06, shadowRadius: 10, shadowOffset: { width: 0, height: 4 }, elevation: 2 },
  input: { flex: 1, height: "100%", color: "#24231F", fontSize: 15 },
  searchButton: { width: 42, height: 42, borderRadius: 12, backgroundColor: "#B84A3A", alignItems: "center", justifyContent: "center" },
  searchIcon: { color: "#FFF9F0", fontSize: 30, lineHeight: 30, fontWeight: "300", transform: [{ rotate: "-20deg" }] },
  micButton: { width: 42, height: 42, borderRadius: 12, backgroundColor: "#EFE6DC", alignItems: "center", justifyContent: "center", marginRight: 6 },
  micButtonActive: { backgroundColor: "#D7B6A9" },
  micText: { color: "#8D4C3E", fontSize: 12, fontWeight: "800" },
  pressed: { opacity: 0.78 },
  fieldList: { gap: 8, paddingTop: 12, paddingBottom: 4 },
  fieldPill: { borderWidth: 1, borderColor: "#DED8CC", borderRadius: 18, paddingHorizontal: 14, paddingVertical: 7, backgroundColor: "#FBF8F2" },
  fieldPillActive: { backgroundColor: "#B84A3A", borderColor: "#B84A3A" },
  fieldText: { color: "#6F6A61", fontSize: 12, fontWeight: "700" },
  fieldTextActive: { color: "#FFF9F0" },
  searchHint: { color: "#A09A90", fontSize: 11, lineHeight: 18, marginTop: 5 },
  dynastyList: { gap: 7, paddingTop: 10, paddingBottom: 2 },
  dynastyPill: { borderWidth: 1, borderColor: "#DED8CC", borderRadius: 16, paddingHorizontal: 11, paddingVertical: 6, backgroundColor: "#FBF8F2" },
  dynastyPillActive: { backgroundColor: "#7C6653", borderColor: "#7C6653" },
  dynastyPillDisabled: { opacity: 0.45 },
  dynastyFilterText: { color: "#6F6A61", fontSize: 11 },
  dynastyFilterTextActive: { color: "#FFF9F0", fontWeight: "700" },
  speechError: { color: "#B84A3A", fontSize: 11, marginTop: 6 },
  hotRow: { flexDirection: "row", alignItems: "center", marginTop: 16, marginBottom: 28 },
  hotLabel: { color: "#8B877D", fontSize: 12, marginRight: 8 },
  hotList: { gap: 8 },
  hotPill: { borderWidth: 1, borderColor: "#DED8CC", borderRadius: 20, paddingHorizontal: 13, paddingVertical: 7, backgroundColor: "#FBF8F2" },
  hotText: { color: "#5E5B54", fontSize: 12 },
  externalHeader: { flexDirection: "row", alignItems: "baseline", justifyContent: "space-between", marginBottom: 9 },
  externalNote: { color: "#AAA399", fontSize: 10 },
  externalList: { gap: 8, paddingBottom: 25 },
  externalPill: { flexDirection: "row", alignItems: "center", borderWidth: 1, borderColor: "#DCCBBF", borderRadius: 12, paddingHorizontal: 12, paddingVertical: 9, backgroundColor: "#FFF8F1" },
  externalText: { color: "#6D4B3F", fontSize: 12, fontWeight: "700" },
  externalArrow: { color: "#B84A3A", fontSize: 14, marginLeft: 6 },
  sectionHeading: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 12 },
  sectionKicker: { color: "#B84A3A", fontSize: 10, letterSpacing: 1.6, fontWeight: "800" },
  sectionTitle: { color: "#24231F", fontSize: 20, fontWeight: "800", marginTop: 4, fontFamily: "serif" },
  poemCard: { backgroundColor: "#FFFDF9", borderRadius: 16, borderWidth: 1, borderColor: "#E7E0D4", padding: 17, marginBottom: 12, shadowColor: "#6E543E", shadowOpacity: 0.05, shadowRadius: 12, shadowOffset: { width: 0, height: 5 }, elevation: 1 },
  cardPressed: { transform: [{ scale: 0.985 }], opacity: 0.9 },
  cardTopLine: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  dynasty: { color: "#B84A3A", fontSize: 12, fontWeight: "700" },
  chevron: { color: "#B84A3A", fontSize: 24, lineHeight: 22 },
  poemTitle: { color: "#24231F", fontSize: 19, fontWeight: "800", marginTop: 10, fontFamily: "serif" },
  excerpt: { color: "#5C5A55", fontSize: 14, lineHeight: 24, marginTop: 9 },
  cardFooter: { flexDirection: "row", alignItems: "center", marginTop: 15, paddingTop: 11, borderTopWidth: 1, borderTopColor: "#EFE9DE" },
  readLabel: { color: "#B84A3A", fontSize: 10, fontWeight: "800", letterSpacing: 1.1 },
  sourceDot: { width: 3, height: 3, borderRadius: 2, backgroundColor: "#B8B1A4", marginHorizontal: 8 },
  sourceLabel: { color: "#AAA399", fontSize: 10 },
  stateBox: { alignItems: "center", paddingVertical: 54, paddingHorizontal: 18 },
  stateMark: { color: "#B84A3A", fontSize: 32, fontWeight: "300", marginBottom: 8 },
  stateTitle: { color: "#393731", fontSize: 16, fontWeight: "800", marginTop: 8 },
  stateBody: { color: "#929087", fontSize: 13, marginTop: 8, textAlign: "center" },
  retryButton: { marginTop: 18, borderRadius: 18, paddingHorizontal: 18, paddingVertical: 9, backgroundColor: "#B84A3A" },
  retryText: { color: "#FFF9F0", fontSize: 12, fontWeight: "700" },
});
