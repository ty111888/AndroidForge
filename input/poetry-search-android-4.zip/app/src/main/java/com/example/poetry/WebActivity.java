package com.example.poetry;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;

/** 在 App 内打开网站：上面一条工具栏（返回、标题、简／繁、关闭），下面是网页。简／繁按钮把整个网页的文字一键转换。 */
public class WebActivity extends Activity {
    private WebView w;
    private TextView titleV, convBtn;
    private String mode = "s", variant = "std", title = "";
    private boolean haveT2 = false, haveC2 = false, haveInject = false;

    private int dp(int v) {
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics()));
    }

    private TextView button(String text, int sizeSp) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sizeSp);
        t.setTextColor(0xFF1D1A16);
        t.setGravity(Gravity.CENTER);
        t.setMinWidth(dp(48));
        t.setPadding(dp(8), 0, dp(8), 0);
        return t;
    }

    @Override
    @SuppressWarnings("deprecation")
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Intent in = getIntent();
        String url = in.getStringExtra("url");
        title = in.getStringExtra("title");
        if (title == null) title = "";
        mode = "t".equals(in.getStringExtra("mode")) ? "t" : "s";
        String v = in.getStringExtra("variant");
        variant = (v == null || v.length() == 0) ? "std" : v;

        Window win = getWindow();
        if (Build.VERSION.SDK_INT >= 28) {
            WindowManager.LayoutParams lp = win.getAttributes();
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            win.setAttributes(lp);
        }
        win.setStatusBarColor(Color.TRANSPARENT);
        win.setNavigationBarColor(Color.TRANSPARENT);
        if (Build.VERSION.SDK_INT >= 30) win.setDecorFitsSystemWindows(false);
        int flags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION;
        if (Build.VERSION.SDK_INT >= 23) flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
        win.getDecorView().setSystemUiVisibility(flags);

        final LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFFF3ECDC);

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackgroundColor(0xFFFAF6EE);

        TextView back = button("‹", 28);
        back.setOnClickListener(new View.OnClickListener() { public void onClick(View x) { onBackPressed(); } });
        titleV = new TextView(this);
        titleV.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        titleV.setTextColor(0xFF1D1A16);
        titleV.setSingleLine(true);
        titleV.setEllipsize(TextUtils.TruncateAt.END);
        titleV.setText(title);
        convBtn = button("t".equals(mode) ? "繁" : "简", 20);
        convBtn.setTypeface(Typeface.DEFAULT_BOLD);
        convBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View x) {
                mode = "t".equals(mode) ? "s" : "t";
                convBtn.setText("t".equals(mode) ? "繁" : "简");
                applyConv();
            }
        });
        TextView close = button("✕", 18);
        close.setOnClickListener(new View.OnClickListener() { public void onClick(View x) { finish(); } });

        bar.addView(back, new LinearLayout.LayoutParams(dp(52), dp(48)));
        bar.addView(titleV, new LinearLayout.LayoutParams(0, dp(48), 1f));
        bar.addView(convBtn, new LinearLayout.LayoutParams(dp(56), dp(48)));
        bar.addView(close, new LinearLayout.LayoutParams(dp(52), dp(48)));

        w = new WebView(this);
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);   // 视频和声音不用先点一下，能自动播（开屏要用）
        s.setDomStorageEnabled(true);
        String ua0 = s.getUserAgentString();                // 去掉 WebView 标记，让网站按普通浏览器打开
        if (ua0 != null) s.setUserAgentString(ua0.replace("; wv", "").replace("Version/4.0 ", ""));
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        w.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                String sc = r.getUrl().getScheme();
                return !("http".equals(sc) || "https".equals(sc));      // 网页里的普通链接都留在这里打开
            }

            @Override
            public void onPageStarted(WebView v, String u, android.graphics.Bitmap f) {
                haveT2 = false; haveC2 = false; haveInject = false;     // 每个新页面都要重新装转换程序
            }

            @Override
            public void onPageFinished(WebView v, String u) {
                String t = v.getTitle();
                if (t != null && t.length() > 0) titleV.setText(t);
                applyConv();
            }
        });

        root.addView(bar, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        root.addView(w, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);
        root.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override
            public WindowInsets onApplyWindowInsets(View v, WindowInsets in) {
                int top = in.getSystemWindowInsetTop();
                if (Build.VERSION.SDK_INT >= 28 && in.getDisplayCutout() != null) top = Math.max(top, in.getDisplayCutout().getSafeInsetTop());
                root.setPadding(0, top, 0, in.getSystemWindowInsetBottom());
                return in;
            }
        });
        if (url != null) w.loadUrl(url);
    }

    private String asset(String name) {
        try {
            InputStream in = getAssets().open(name);
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[65536];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            in.close();
            return out.toString("UTF-8");
        } catch (Exception e) {
            return "";
        }
    }

    // OpenCC 的脚本带"模块定义"，有些网站自己也有 define，会抢走它；所以包一层，把 define / module / exports 屏蔽掉
    private String wrapLib(String text, String globalName) {
        return "(function(define,module,exports){" + text + "\n})(undefined,undefined,undefined);window." + globalName + "=window.OpenCC;";
    }

    private void applyConv() {
        if (w == null) return;
        if ("t".equals(mode)) {
            if (!haveC2) { w.evaluateJavascript(wrapLib(asset("vendor/opencc/cn2t.js"), "__cn2t"), null); haveC2 = true; }
        } else {
            if (!haveT2) { w.evaluateJavascript(wrapLib(asset("vendor/opencc/t2cn.js"), "__t2cn"), null); haveT2 = true; }
        }
        if (!haveInject) { w.evaluateJavascript(asset("js/convert-inject.js"), null); haveInject = true; }
        w.evaluateJavascript("window.__psConv&&window.__psConv('" + mode + "','" + variant + "')", null);
    }

    @Override
    public void onBackPressed() {
        if (w != null && w.canGoBack()) w.goBack(); else finish();
    }

    @Override
    protected void onDestroy() {
        if (w != null) { w.stopLoading(); w.destroy(); w = null; }
        super.onDestroy();
    }
}
