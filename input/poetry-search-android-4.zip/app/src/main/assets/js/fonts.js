/* fonts.js — 字体与字号：首页"搜诗"、首页其他文字、搜索记录文字、诗词全文文字，各自设置
 * 字体：默认（App 的水墨风）/ 系统字体（手机自带）/ 其他（你选的字体文件）；字号多档。 */
(function (root) {
  'use strict';
  var KEYS = ['title', 'home', 'results', 'poem'];
  var NAMES = { title: '首页搜诗文字', home: '首页其他文字', results: '搜索记录显示文字', poem: '诗词全文页面文字' };
  var SYS = 'system-ui, -apple-system, "Roboto", "Noto Sans CJK SC", "Droid Sans Fallback", sans-serif';
  var SIZE_NAMES = { min: '最小', s: '小', m: '正常', l: '大', xl: '偏大', xxl: '特大', xxxl: '最大' };
  var styleEl = null;

  function apply() {
    var F = root.PSSettings.get('fonts'), S = root.PSSettings.SIZES, css = ':root{', faces = '';
    KEYS.forEach(function (k) {
      var f = F[k] || { font: 'default', size: 'm' }, fam = 'var(--font)';
      if (f.font === 'system') fam = SYS;
      else if (f.font === 'file' && f.file) {
        var name = 'psfont-' + k;
        faces += '@font-face{font-family:"' + name + '";src:url("' + f.file + '");font-display:swap;}';
        fam = '"' + name + '", var(--font)';
      }
      var sz = f.size || 'm';
      css += '--f-' + k + ':' + fam + ';--s-' + k + ':' + (S[sz] || 1) + ';';
      if (k === 'title') {
        var titleSize = sz === 'xl' ? '25vw' : sz === 'xxl' ? '50vw' : sz === 'xxxl' ? '66.6667vw' : 'calc(' + (S[sz] || 1) + ' * 60px');
        css += '--title-size:' + titleSize + ';';
      }
    });
    css += '}';
    if (!styleEl) { styleEl = document.createElement('style'); styleEl.id = 'psFontStyle'; document.head.appendChild(styleEl); }
    styleEl.textContent = faces + css;
  }
  root.PSFonts = { KEYS: KEYS, NAMES: NAMES, SIZE_NAMES: SIZE_NAMES, apply: apply };
})(window);
