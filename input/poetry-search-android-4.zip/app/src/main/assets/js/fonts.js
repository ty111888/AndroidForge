/* fonts.js — 字体与字号：首页"搜诗"、首页其他文字、搜索记录文字、诗词全文文字，各自设置
 * 字体：默认（App 的水墨风）/ 系统字体（手机自带）/ 其他（你选的字体文件）；字号多档。 */
(function (root) {
  'use strict';
  var KEYS = ['title', 'home', 'results', 'poem'];
  var NAMES = { title: '首页搜诗文字', home: '首页其他文字', results: '搜索记录显示文字', poem: '诗词全文页面文字' };
  var SYS = 'system-ui, -apple-system, "Roboto", "Noto Sans CJK SC", "Droid Sans Fallback", sans-serif';
  var SIZE_NAMES = { min: '最小', s: '小', m: '正常', l: '大', pl: '偏大', xl: '特大', xxl: '最大' };
  // 偏大 / 特大 / 最大：按屏幕实际宽度的 1/4、1/2、2/3 定字号（不缩小）
  var BIG = { pl: '25vw', xl: '50vw', xxl: '66.67vw' };
  var styleEl = null;

  function apply() {
    var F = root.PSSettings.get('fonts'), S = root.PSSettings.SIZES, css = ':root{', faces = '';
    KEYS.forEach(function (k) {
      var f = F[k] || { font: 'default', size: 'm' }, fam = 'var(--font)';
      if (f.font === 'system') fam = SYS;
      else if (f.font === 'file' && f.file) {
        var name = 'psfont-' + k;
        faces += '@font-face{font-family:"' + name + '";src:url("' + f.file + '");font-display:swap;}';
        fam = '"' + name + '", var(--font)';
      }
      css += '--f-' + k + ':' + fam + ';--s-' + k + ':' + (S[f.size] || 1) + ';';
      css += '--fs-' + k + ':' + (BIG[f.size] ? BIG[f.size] : 'initial') + ';';   // initial = 没有大字号，用原来的倍数
    });
    css += '}';
    if (!styleEl) { styleEl = document.createElement('style'); styleEl.id = 'psFontStyle'; document.head.appendChild(styleEl); }
    styleEl.textContent = faces + css;
  }
  root.PSFonts = { BIG: BIG, KEYS: KEYS, NAMES: NAMES, SIZE_NAMES: SIZE_NAMES, apply: apply };
})(window);
