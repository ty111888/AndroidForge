/* splash.js — 开屏：每次打开 App 先播"当前开屏"，播完或超过 30 秒就进首页。
 * GIF 直接显示；MP4、MKV 用视频标签播。播不了就提示换成 MP4，并直接进首页，不卡住。
 * 没有开屏文件，就直接进首页。浏览器里挂在 window.PSSplash。 */
(function (root) {
  'use strict';
  var MAX_MS = 30000;
  var layer = null, timer = null, done = false, onFinish = null;

  function kindOf(name) {
    var m = String(name || '').toLowerCase().match(/\.([a-z0-9]+)$/);
    var ext = m ? m[1] : '';
    if (ext === 'gif') return 'gif';
    if (ext === 'mp4' || ext === 'mkv') return 'video';
    return null;
  }

  function finish(reason) {
    if (done) return;
    done = true;
    if (timer) { clearTimeout(timer); timer = null; }
    if (layer) { layer.remove(); layer = null; }
    if (onFinish) { var f = onFinish; onFinish = null; f(reason); }
  }

  function fail(msg) {
    var m = document.getElementById('splashMsg');
    if (m) m.textContent = msg;
    setTimeout(function () { finish('fail'); }, 1800);
  }

  // play(force)：force = true 时是设置里"播放看看"，播完只关闭播放层，不跳进首页
  function play(force) {
    var sp = root.PSSettings.get('splash') || {};
    sp = { url: root.PSNative ? root.PSNative.toPageUrl(sp.url) : sp.url, name: sp.name };
    if (!sp.url) { if (!force) finish('none'); return; }
    var k = kindOf(sp.name);
    if (!k) { if (!force) finish('none'); return; }
    done = false;
    layer = document.createElement('div');
    layer.id = 'splashLayer';
    layer.style.cssText = 'position:fixed;top:0;left:0;right:0;bottom:0;z-index:5000;background:#f3ecdc;display:flex;align-items:center;justify-content:center;';
    var msg = document.createElement('div');
    msg.id = 'splashMsg';
    msg.style.cssText = 'position:absolute;bottom:40px;left:0;right:0;text-align:center;color:#5b5143;font-size:14px;';
    var skip = document.createElement('button');
    skip.textContent = '跳过';
    skip.style.cssText = 'position:absolute;top:calc(env(safe-area-inset-top,0px) + 12px);right:12px;border:none;background:rgba(20,17,12,.5);color:#fff;border-radius:16px;padding:6px 14px;';
    skip.onclick = function () { finish('skip'); };
    layer.appendChild(skip);

    if (k === 'gif') {
      var im = new Image();
      im.src = sp.url;
      im.style.cssText = 'width:100%;height:100%;object-fit:contain;';
      im.onerror = function () { fail('开屏图片打不开，已跳过。'); };
      // GIF 没有结束事件：播一轮的时间由它自己的帧长决定，这里按一个保守的时长收起（最多 MAX_MS）
      // 解析 GIF 总时长较复杂，统一用 MAX_MS 兜底，并在图片完整加载后再给一个最短停留，避免一闪而过
      im.onload = function () { /* 已显示，等待下面的计时器收起 */ };
      setTimeout(function () { if (!done) finish('gif-end'); }, Math.min(MAX_MS, 6000));
      layer.appendChild(im);
    } else {
      var v = document.createElement('video');
      v.src = sp.url;
      v.playsInline = true;
      v.autoplay = true;
      v.style.cssText = 'width:100%;height:100%;object-fit:contain;background:#000;';
      v.onended = function () { finish('ended'); };
      v.onerror = function () { fail('这个视频播不了（可能是 MKV 格式）。请换成 MP4 再试。'); };
      layer.appendChild(v);
    }
    layer.appendChild(msg);
    document.body.appendChild(layer);
    timer = setTimeout(function () { finish('timeout'); }, MAX_MS);
  }

  // 启动时调用：有开屏就先播，播完再执行 next（进首页）
  function run(next) {
    onFinish = next;
    play(false);
    if (!layer) { done = true; if (next) next('none'); }
  }

  root.PSSplash = { run: run, play: play };
})(window);
