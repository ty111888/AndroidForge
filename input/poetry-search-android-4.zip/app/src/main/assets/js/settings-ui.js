/* settings-ui.js — 设置页：导入、数据库、字体与字号、诗词网站、搜索引擎、网络图库、AI生图网站、其他 */
(function (root) {
  'use strict';
  var UI = root.PSUI, ST = root.PSSettings, St = root.PSStore, Cv = root.PSConvert, N = root.PSNative, I = root.PSImages, F = root.PSFonts, Src = root.PSSources;
  var $ = UI.$, el = UI.el;
  function txt(tag, cls, t) { var e = el(tag, cls); e.textContent = t; return e; }
  function mb(n) { return root.PSApp.mb(n); }
  function next(fn) { UI.closeSheet(); setTimeout(fn, 60); }            // 先关掉当前抽屉，再开下一个（避免返回键错乱）
  function rowBtn(title, sub, fn) { var r = el('button', 'row'); r.appendChild(txt('div', 'row-t', title)); if (sub) r.appendChild(txt('div', 'row-s', sub)); r.onclick = fn; return r; }
  function optBtn(label, on, fn) { var b = el('button', 'opt' + (on ? ' on' : '')); b.textContent = label; b.onclick = fn; return b; }
  function field(label, input) { var l = el('label', 'field'); l.appendChild(txt('span', '', label)); l.appendChild(input); return l; }
  function input(type, value, ph) { var i = el('input'); i.type = type; i.value = value == null ? '' : value; if (ph) i.placeholder = ph; return i; }
  function switchRow(label, on, fn) {
    var r = el('div', 'switch'); r.appendChild(txt('span', '', label));
    var c = el('input'); c.type = 'checkbox'; c.checked = !!on; c.onchange = function () { fn(c.checked); }; r.appendChild(c); return r;
  }

  // ---------------------------------------------------------------- 设置首页
  function openSettings() {
    UI.openPage('设置', function (body) {
      var convRow = rowBtn('简繁', '点一下切换简体、繁体；当前：' + (Cv.getMode() === 's' ? '简体' : '繁体'), function () {
        Cv.toggle(); UI.toast(Cv.getMode() === 's' ? '已切换为简体' : '已切换为繁体'); convRow.querySelector('.row-s').textContent = '点一下切换简体、繁体；当前：' + (Cv.getMode() === 's' ? '简体' : '繁体');
      });
      body.appendChild(convRow);
      body.appendChild(rowBtn('导入', '本地导入文件；GitHub 在线导入', openImport));
      body.appendChild(rowBtn('数据库', '已下载到手机的文件、流量提醒', openDbSettings));
      body.appendChild(rowBtn('换背景', '自动更换的图片：往里加图、删图', openAutoChange));
      body.appendChild(rowBtn('开屏', '开屏动画：放一个 GIF / MP4 / MKV，每次打开先播', openSplash));
      body.appendChild(rowBtn('水晶球', '首页和诗页的水晶球图案，可以换', openCrystal));
      body.appendChild(rowBtn('字体与字号', '首页、搜索记录、诗词全文各自设置', openFonts));
      body.appendChild(rowBtn('诗词网站', '添加、删除、修改', function () { openListEditor(SITES); }));
      body.appendChild(rowBtn('搜索引擎', '添加、删除、修改；港台本地化', function () { openListEditor(ENGINES); }));
      body.appendChild(rowBtn('网络图库', '背景图来源', function () { openListEditor(GALLERIES); }));
      body.appendChild(rowBtn('AI生图网站', '一键出图或打开网站', function () { openListEditor(AISITES); }));
      body.appendChild(rowBtn('其他', '关于与诊断、繁体写法、搜索记录、备份与恢复', openOther));
    });
  }

  // ---------------------------------------------------------------- 开屏（每次打开先播一段，播完进首页）
  var SPLASH_EXT = ['gif', 'mp4', 'mkv'];
  function splashKind(name) {
    var m = String(name || '').toLowerCase().match(/\.([a-z0-9]+)$/);
    var ext = m ? m[1] : '';
    if (SPLASH_EXT.indexOf(ext) < 0) return null;
    return ext === 'gif' ? 'gif' : 'video';       // GIF 直接显示；MP4/MKV 走视频标签
  }
  function openSplash() {
    UI.openPage('开屏', function (body) {
      body.appendChild(txt('p', 'tip', '只显示"当前开屏"这一个。换一个，就替代掉旧的。每次打开 App 先播它，播完进首页；最长 30 秒，超过就跳过。支持 GIF、MP4、MKV。'));
      var box = el('div'); body.appendChild(box);
      function draw() {
        box.innerHTML = '';
        var sp = ST.get('splash') || { url: '', name: '', size: 0 };
        if (!sp.url) {
          box.appendChild(txt('div', 'row-t', '还没有开屏。'));
        } else {
          box.appendChild(txt('div', 'row-t', '当前开屏：' + (sp.name || '未命名') + ' · ' + mb(sp.size || 0)));
          var prev = el('div'); prev.style.cssText = 'margin:8px 0;';
          var k = splashKind(sp.name);
          if (k === 'gif') { var im = new Image(); im.src = N.toPageUrl(sp.url); im.style.cssText = 'max-width:100%;max-height:200px;border-radius:10px;'; prev.appendChild(im); }
          else { var v = el('video'); v.src = N.toPageUrl(sp.url); v.controls = true; v.playsInline = true; v.style.cssText = 'max-width:100%;max-height:200px;border-radius:10px;'; prev.appendChild(v); }
          box.appendChild(prev);
          var play = el('button', 'btn primary wide'); play.textContent = '播放看看';
          play.onclick = function () { root.PSSplash && root.PSSplash.play(true); };
          var rm = el('button', 'btn danger wide'); rm.textContent = '删除这个开屏（不再开屏，也不占空间）';
          rm.onclick = async function () { if (await UI.confirmBox('删除当前开屏？删除后不再开屏。', '删除')) { ST.set('splash', { url: '', name: '', size: 0 }); draw(); UI.toast('已删除'); } };
          box.appendChild(play); box.appendChild(rm);
        }
        var add1 = el('button', 'btn wide'); add1.textContent = '＋ 从相册选（可选视频、GIF）';
        add1.onclick = function () { addFrom('gallery'); };
        var add2 = el('button', 'btn wide'); add2.textContent = '＋ 从文件选（一层层找）';
        add2.onclick = function () { addFrom('files'); };
        box.appendChild(add1); box.appendChild(add2);
        if (Cv.isReady()) Cv.apply(box);
      }
      async function addFrom(mode) {
        var r = await N.pickMedia(mode);
        if (!r || !r.url) { UI.toast('没有选中文件'); return; }
        var kind = splashKind(r.name);
        if (!kind) { UI.toast('只支持 GIF、MP4、MKV'); return; }
        ST.set('splash', { url: r.url, name: r.name || '', size: r.size || 0 });
        draw(); UI.toast('已替换为新的开屏');
      }
      draw();
    });
  }

  // ---------------------------------------------------------------- 水晶球（图案可换）
  // 结构：加图（相册 / 文件）→ 下拉选当前图 → 选中后出现小预览 → 三个按钮：美化、正常、本机
  function openCrystal() {
    UI.openPage('水晶球', function (body) {
      body.appendChild(txt('p', 'tip', '首页两个水晶球和诗页的水晶球，都用这里选中的图。加图后，选一张，下面可以选三种效果。'));
      var box = el('div'); body.appendChild(box);

      function current() { return ST.get('crystal') || { url: '', name: '', mode: 'local', list: [] }; }

      async function draw() {
        box.innerHTML = '';
        var c = current(), list = c.list || [];

        // 1. 下拉：选当前图（最前面一项是"本机"）
        var sel = el('select'); sel.style.cssText = 'width:100%;padding:10px;border-radius:10px;border:1px solid var(--line);margin:8px 0;';
        var o0 = el('option'); o0.value = ''; o0.textContent = '本机（原来的水晶球）'; sel.appendChild(o0);
        list.forEach(function (it, i) { var op = el('option'); op.value = String(i); op.textContent = it.name || ('图 ' + (i + 1)); sel.appendChild(op); });
        var curIdx = list.findIndex(function (it) { return it.url === c.url; });
        sel.value = curIdx >= 0 && c.url ? String(curIdx) : '';
        sel.onchange = function () {
          var v = sel.value;
          if (v === '') { ST.set('crystal', { url: '', name: '', mode: 'local', list: list }); PSCrystal.applyCurrent(); draw(); return; }
          var it = list[+v];
          ST.set('crystal', { url: it.url, name: it.name, mode: 'normal', list: list }); draw();
        };
        box.appendChild(sel);

        // 2. 选中图后：小预览 + 三个按钮
        if (c.url && c.mode !== 'local') {
          var prev = el('div'); prev.style.cssText = 'display:flex;align-items:center;gap:14px;margin:10px 0;';
          var pim = new Image(); pim.src = N.toPageUrl(c.url);   /* 先用原图占位；下面算好所选效果再换上 */ pim.style.cssText = 'width:80px;height:80px;object-fit:contain;border-radius:50%;background:#e8e0cc;';
          var pname = txt('div', 'row-s', c.name || '');
          prev.appendChild(pim); prev.appendChild(pname); box.appendChild(prev);

          var btns = el('div'); btns.style.cssText = 'display:flex;gap:8px;';
          [['美化', 'beauty'], ['正常', 'normal'], ['本机', 'local']].forEach(function (x) {
            var b = el('button', 'btn' + (c.mode === x[1] ? ' primary' : '')); b.textContent = x[0]; b.style.flex = '1';
            b.onclick = function () {
              ST.set('crystal', { url: c.url, name: c.name, mode: x[1], list: list });
              PSCrystal.applyCurrent();
              UI.toast(x[0] === '本机' ? '已回到本机的水晶球' : '已设为：' + x[0]);
              draw();
            };
            btns.appendChild(b);
          });
          box.appendChild(btns);
          PSCrystal.render(c.url, c.mode).then(function (d) { if (d) pim.src = d; }).catch(function () {});
        }

        // 3. 加图（相册 / 文件），加进列表；新加的图自动选中，并默认"正常"
        var add1 = el('button', 'btn wide'); add1.textContent = '＋ 从相册加图';
        add1.onclick = function () { addFrom('gallery'); };
        var add2 = el('button', 'btn wide'); add2.textContent = '＋ 从文件加图（一层层找）';
        add2.onclick = function () { addFrom('files'); };
        box.appendChild(add1); box.appendChild(add2);
        if (list.length) {
          var clr = el('button', 'btn danger wide'); clr.textContent = '清空水晶球图片列表';
          clr.onclick = async function () { if (await UI.confirmBox('清空列表？当前水晶球会回到本机的。', '清空')) { ST.set('crystal', { url: '', name: '', mode: 'local', list: [] }); PSCrystal.applyCurrent(); draw(); } };
          box.appendChild(clr);
        }
        if (Cv.isReady()) Cv.apply(box);
      }

      async function addFrom(mode) {
        var r = await N.pickImage('crystal-' + mode);
        if (!r || !r.url) { UI.toast('没有选中图片'); return; }
        var c = current(), list = (c.list || []).concat([{ url: r.url, name: r.name || '' }]);
        ST.set('crystal', { url: r.url, name: r.name || '', mode: 'normal', list: list });
        PSCrystal.applyCurrent();
        UI.toast('已加入，并设为当前水晶球');
        draw();
      }
      draw();
    });
  }

  // ---------------------------------------------------------------- 换背景（自动更换的图片）
  function openAutoChange() {
    UI.openPage('换背景', function (body) {
      body.appendChild(txt('p', 'tip', '这里的图每次打开 App 会换一张（"自动更换"）。往里加图，有相册和文件两种方式。'));
      var box = el('div'); body.appendChild(box);
      function draw() {
        box.innerHTML = '';
        var a = ST.get('autoChange') || {}, list = a.list || [];
        box.appendChild(txt('div', 'row-t', '已加入 ' + list.length + ' 张'));
        list.forEach(function (u, i) {
          var r = el('div', 'switch'); var im = new Image(); im.src = N.toPageUrl(u); im.style.cssText = 'width:52px;height:52px;object-fit:cover;border-radius:8px;margin-right:8px';
          var lab = txt('span', '', '第 ' + (i + 1) + ' 张'); r.appendChild(im); r.appendChild(lab);
          var d = el('button', 'dl'); d.textContent = '删除';
          d.onclick = function () { var l = (ST.get('autoChange').list || []).slice(); l.splice(i, 1); ST.update('autoChange', function (x) { x.list = l; }); draw(); UI.toast('已删除'); };
          r.appendChild(d); box.appendChild(r);
        });
        var add1 = el('button', 'btn wide'); add1.textContent = '＋ 从相册加图';
        add1.onclick = function () { addFrom('gallery'); };
        var add2 = el('button', 'btn wide'); add2.textContent = '＋ 从文件加图（单张）';
        add2.onclick = function () { addFrom('files'); };
        var add3 = el('button', 'btn wide'); add3.textContent = '＋ 直接引用手机里一个文件夹（不复制，省空间）';
        add3.onclick = async function () {
          var f = await N.pickFolder();
          if (f && f.uri) { ST.update('autoChange', function (x) { x.mode = 'phone'; x.folderUri = f.uri; x.folderName = f.name || ''; }); UI.toast('已引用文件夹：' + (f.name || '')); draw(); }
          else UI.toast('没有选中文件夹');
        };
        box.appendChild(add1); box.appendChild(add2); box.appendChild(add3);
        if (list.length) {
          var clr = el('button', 'btn danger wide'); clr.textContent = '清空这个列表';
          clr.onclick = async function () { if (await UI.confirmBox('清空自动更换的图片列表？（手机里的原图不受影响）', '清空')) { ST.update('autoChange', function (x) { x.list = []; }); draw(); UI.toast('已清空'); } };
          box.appendChild(clr);
        }
        if (Cv.isReady()) Cv.apply(box);
      }
      async function addFrom(mode) {
        var r = await N.pickImage(mode);
        if (r && r.url) { ST.update('autoChange', function (x) { x.list = (x.list || []).concat([r.url]); x.mode = x.mode || 'own'; }); draw(); UI.toast('已加入'); }
      }
      draw();
    });
  }

  // ---------------------------------------------------------------- 导入
  function openImport() {
    UI.openPage('导入', function (body) {
      body.appendChild(rowBtn('本地导入', '从手机选文件：txt、csv、json、dbf+fpt……导入后进入"文集"', function () { $('fileIn').click(); }));
      body.appendChild(rowBtn('在线导入（GitHub 网址）', '粘贴 github.com 上数据库的网址，挑要导入的文件（下一阶段加入）', function () { UI.toast('在线导入将在下一阶段加入', 3000); }));
      body.appendChild(txt('p', 'tip', '导入成功的数据文件，会加到首页左侧"文集"的列表里，可以单独勾选作为搜索范围。'));
    });
  }

  // ---------------------------------------------------------------- 数据库（已下载的文件）
  function openDbSettings() {
    UI.openPage('数据库', function (body) {
      body.appendChild(txt('p', 'tip', '默认在线搜索：边下载边搜，搜完不保存。只有你在首页"数据库"里点 ⬇ 下载的文件，才保存在手机里。'));
      var use = txt('div', 'tip', '读取存储用量……'); body.appendChild(use);
      St.usage().then(function (u) { use.textContent = u ? '本 App 已占用约 ' + mb(u.usage) + '（手机分给 App 的额度约 ' + mb(u.quota) + '）' : ''; });
      var th = input('number', ST.get('confirmMB'));
      th.onchange = function () { var v = Math.max(1, parseInt(th.value, 10) || 60); ST.set('confirmMB', v); th.value = v; };
      body.appendChild(field('一次搜索要从网上下载超过多少 MB，就先问我', th));
      var box = el('div'); body.appendChild(box);
      // 按库分段 → 按文件夹（朝代/分类）分组 → 文件；每一层都能单独删，并标注大小
      function groupOf(m) {
        var f = Src.getFile(m.key);
        var repo = f ? f.repoId : 'other';
        var dir = f ? (f.dir || '（根目录）') : '（其他）';
        return { repo: repo, dir: dir, f: f, m: m };
      }
      function repoLabel(id) { var r = Src.REPOS.filter(function (x) { return x.id === id; })[0]; return r ? r.label : id; }
      async function draw() {
        box.innerHTML = '';
        var list = await St.listFiles();
        var total = list.reduce(function (a, m) { return a + m.size; }, 0);
        box.appendChild(txt('div', 'row-t', '已下载到手机的文件（' + list.length + ' 个，共 ' + mb(total) + '）'));
        if (!list.length) box.appendChild(txt('p', 'tip', '还没有。'));
        var byRepo = {};
        list.map(groupOf).forEach(function (g) { (byRepo[g.repo] = byRepo[g.repo] || []).push(g); });
        Object.keys(byRepo).forEach(function (rid) {
          var items = byRepo[rid], rsize = items.reduce(function (a, g) { return a + g.m.size; }, 0);
          var head = el('div', 'switch'); head.appendChild(txt('span', 'row-t', repoLabel(rid) + ' · ' + mb(rsize)));
          var rd = el('button', 'dl'); rd.textContent = '删除整库';
          rd.onclick = async function () {
            if (!(await UI.confirmBox('删除"' + repoLabel(rid) + '"下已下载的全部文件（' + mb(rsize) + '）？删除后搜索会重新在线读取。', '删除'))) return;
            for (var i = 0; i < items.length; i++) await St.deleteFile(items[i].m.key);
            draw(); UI.toast('已删除');
          };
          head.appendChild(rd); box.appendChild(head);
          var dirs = {};
          items.forEach(function (g) { (dirs[g.dir] = dirs[g.dir] || []).push(g); });
          Object.keys(dirs).forEach(function (dname) {
            var fs = dirs[dname], dsize = fs.reduce(function (a, g) { return a + g.m.size; }, 0);
            var dr = el('div', 'switch'); dr.style.paddingLeft = '18px';
            dr.appendChild(txt('span', '', dname + ' · ' + mb(dsize)));
            var dd = el('button', 'dl'); dd.textContent = '删除这一层';
            dd.onclick = async function () {
              if (!(await UI.confirmBox('删除"' + dname + '"下的文件（' + mb(dsize) + '）？', '删除'))) return;
              for (var i = 0; i < fs.length; i++) await St.deleteFile(fs[i].m.key);
              draw(); UI.toast('已删除');
            };
            dr.appendChild(dd); box.appendChild(dr);
            fs.forEach(function (g) {
              var r = el('div', 'switch'); r.style.paddingLeft = '36px';
              r.appendChild(txt('span', '', (g.f ? g.f.name : g.m.key) + ' · ' + mb(g.m.size)));
              var d = el('button', 'dl'); d.textContent = '删除';
              d.onclick = async function () { await St.deleteFile(g.m.key); draw(); UI.toast('已删除'); };
              r.appendChild(d); box.appendChild(r);
            });
          });
        });
        if (list.length) {
          var all = el('button', 'btn danger wide'); all.textContent = '删除全部已下载文件';
          all.onclick = async function () { if (await UI.confirmBox('删除手机里全部已下载的数据文件？', '全部删除')) { await St.clearFiles(); draw(); UI.toast('已清空'); } };
          box.appendChild(all);
        }
        if (Cv.isReady()) Cv.apply(box);
      }
      draw();
    });
  }

  // ---------------------------------------------------------------- 字体与字号
  var SIZE_ORDER = ['min', 's', 'm', 'l', 'pl', 'xl', 'xxl'], fontsRedraw = null;
  function setFont(key, patch) { ST.update('fonts', function (f) { f[key] = Object.assign({}, f[key], patch); }); F.apply(); if (fontsRedraw) fontsRedraw(); }
  function openFonts() {
    UI.openPage('字体与字号', function (body) {
      function draw() {
        body.innerHTML = '';
        try {
        F.KEYS.forEach(function (k) {
          var f = (ST.get('fonts') || {})[k] || {}, desc = (f.font === 'system' ? '系统字体' : f.font === 'file' ? '自选字体文件' : '默认字体') + ' · ' + F.SIZE_NAMES[f.size || 'm'];
          body.appendChild(rowBtn(F.NAMES[k], desc, function () { openFontItem(k); }));
        });
        body.appendChild(txt('p', 'tip', '点任意一项，可选"默认""字体""字号"。'));
        if (Cv.isReady()) Cv.apply(body);
        } catch (e) { body.appendChild(txt('p', 'tip', '字体与字号页面出错：' + (e && e.message ? e.message : e))); }
      }
      fontsRedraw = draw; draw();
    }, { onClose: function () { fontsRedraw = null; } });
  }
  function openFontItem(key) {
    UI.openSheet(F.NAMES[key], function (b) {
      b.appendChild(rowBtn('默认', '恢复默认字体和字号', function () { setFont(key, { font: 'default', file: '', size: 'm' }); next(function () { UI.toast('已恢复默认'); }); }));
      b.appendChild(rowBtn('字体', '系统字体，或选一个字体文件', function () { next(function () { openFontPick(key); }); }));
      b.appendChild(rowBtn('字号', '最小到最大，共 7 档', function () { next(function () { openSizePick(key); }); }));
    }, { hideOk: true });
  }
  root.PSFontItem = { open: function (key) { openFontItem(key); } };
  function openFontPick(key) {
    var cur = (ST.get('fonts')[key] || {}).font;
    UI.openSheet(F.NAMES[key] + ' · 字体', function (b) {
      b.appendChild(optBtn('系统字体（手机自带）', cur === 'system', function () { setFont(key, { font: 'system', file: '' }); next(function () { UI.toast('已用系统字体'); }); }));
      b.appendChild(optBtn('其他：选择字体文件（.ttf .otf）', cur === 'file', async function () {
        UI.closeSheet();
        var r = await N.pickFont();
        if (r && r.url) { setFont(key, { font: 'file', file: r.url }); UI.toast('已使用 ' + (r.name || '所选字体')); }
      }));
    }, { hideOk: true });
  }
  function openSizePick(key) {
    var cur = (ST.get('fonts')[key] || {}).size || 'm';
    UI.openSheet(F.NAMES[key] + ' · 字号', function (b) {
      SIZE_ORDER.forEach(function (s) { b.appendChild(optBtn(F.SIZE_NAMES[s], cur === s, function () { setFont(key, { size: s }); next(function () { UI.toast('字号：' + F.SIZE_NAMES[s]); }); })); });
    }, { hideOk: true });
  }

  // ---------------------------------------------------------------- 可编辑列表（诗词网站、搜索引擎、网络图库、AI生图网站）
  var SITES = { title: '诗词网站', key: 'sites', sub: function (it) { return it.url; }, fields: [['name', '名称', 'text'], ['url', '链接', 'url']], blank: function () { return { name: '', url: 'https://' }; }, check: function (it) { return /^https?:\/\//.test(it.url) ? '' : '链接要以 http:// 或 https:// 开头'; } };
  var ENGINES = {
    title: '搜索引擎', key: 'engines', sub: function (it) { return it.url; },
    fields: [['name', '名称', 'text'], ['url', '网址（用 {q} 代表关键字）', 'url']],
    blank: function () { return { id: 'custom-' + Date.now(), name: '', url: 'https://example.com/search?q={q}' }; },
    check: function (it) { return /^https?:\/\//.test(it.url) && it.url.indexOf('{q}') >= 0 ? '' : '网址要以 http 开头，并包含 {q}'; },
    extra: function (body) {
      body.appendChild(txt('div', 'row-t', '港台搜索'));
      var sel = el('select'); [['normal', '普通：只转繁体关键字'], ['prefer', '偏好本地：再加语言、地区参数（默认）'], ['strict', '严格本地：只要当地网页，结果会少']].forEach(function (o) { var op = el('option'); op.value = o[0]; op.textContent = o[1]; sel.appendChild(op); });
      sel.value = ST.get('engineLocal'); sel.onchange = function () { ST.set('engineLocal', sel.value); };
      body.appendChild(field('本地内容优先的强度（谷歌香港、谷歌台湾）', sel));
      body.appendChild(switchRow('谷歌结果页去掉 AI 概览（网址加 udm=14）', ST.get('googleNoAI'), function (v) { ST.set('googleNoAI', v); }));
      body.appendChild(switchRow('港台搜索时，把关键字转成对应的繁体写法', ST.get('engineConv'), function (v) { ST.set('engineConv', v); }));
    }
  };
  var GALLERIES = { title: '网络图库', key: 'galleries', sub: function (it) { return (it.enabled ? '已开启' : '已关闭') + (it.url ? ' · ' + it.url : ''); }, fields: [['name', '名称', 'text'], ['url', '网址（可选，自己添加的图库）', 'url']], blank: function () { return { id: 'custom-' + Date.now(), name: '', url: '', enabled: true }; }, check: function (it) { return !it.name ? '请填名称' : (it.url && !/^https?:\/\//.test(it.url) ? '网址要以 http 开头' : ''); }, toggle: true, tip: '前三家是公有领域图库。自己添加的图库只会先记录名称和网址；能不能直接搜图，要看它的接口，需要单独适配。' };
  var AISITES = {
    title: 'AI生图网站', key: 'aiSites', sub: function (it) { return (it.mode === 'api' ? '一键出图 · ' : '网页 · ') + it.url; },
    fields: [['name', '名称', 'text'], ['url', '链接（一键出图的链接里用 {prompt} 代表提示词）', 'url'], ['mode', '用法', 'mode']],
    blank: function () { return { name: '', url: 'https://', mode: 'web' }; },
    check: function (it) { return !/^https?:\/\//.test(it.url) ? '链接要以 http 开头' : (it.mode === 'api' && it.url.indexOf('{prompt}') < 0 ? '"一键出图"的链接里要有 {prompt}' : ''); }
  };

  function openListEditor(cfg) {
    UI.openPage(cfg.title, function (body, api) {
      var wrap = el('div'); body.appendChild(wrap);
      function draw() {
        wrap.innerHTML = '';
        ST.get(cfg.key).forEach(function (it, i) {
          var r = el('button', 'row'); r.appendChild(txt('div', 'row-t', it.name || '（未命名）')); r.appendChild(txt('div', 'row-s', cfg.sub(it)));
          r.onclick = function () { editItem(cfg, i, draw); };
          wrap.appendChild(r);
        });
        if (cfg.tip) wrap.appendChild(txt('p', 'tip', cfg.tip));
        if (Cv.isReady()) Cv.apply(wrap);
      }
      draw();
      if (cfg.extra) cfg.extra(body);
      api.redraw = draw;
    }, { actions: cfg.noAdd ? [] : [{ label: '＋添加', fn: function (api) { editItem(cfg, -1, api.redraw); } }] });
  }
  function editItem(cfg, idx, done) {
    var list = ST.get(cfg.key).slice(), isNew = idx < 0, it = isNew ? cfg.blank() : Object.assign({}, list[idx]), ins = {};
    UI.openSheet(isNew ? '添加' : '修改', function (b) {
      cfg.fields.forEach(function (f) {
        var k = f[0], w;
        if (f[2] === 'mode') { w = el('select'); [['web', '打开网站（提示词自动复制）'], ['api', '一键出图（链接里有 {prompt}）']].forEach(function (o) { var op = el('option'); op.value = o[0]; op.textContent = o[1]; w.appendChild(op); }); w.value = it.mode || 'web'; }
        else w = input(f[2] === 'url' ? 'url' : 'text', it[k]);
        ins[k] = w; b.appendChild(field(f[1], w));
      });
      if (cfg.toggle) b.appendChild(switchRow('开启这个图库', it.enabled, function (v) { it.enabled = v; }));
      var row = el('div', 'btn-row'), save = el('button', 'btn primary'); save.textContent = '保存';
      save.onclick = function () {
        cfg.fields.forEach(function (f) { it[f[0]] = ins[f[0]].value.trim(); });
        if (!it.name) { UI.toast('请填名称'); return; }
        var err = cfg.check(it); if (err) { UI.toast(err, 3500); return; }
        if (isNew) list.push(it); else list[idx] = it;
        ST.set(cfg.key, list); UI.closeSheet(); done(); UI.toast('已保存');
      };
      row.appendChild(save);
      if (!isNew && !cfg.noAdd) {
        var up = el('button', 'btn'); up.textContent = '上移'; up.onclick = function () { if (idx > 0) { var t = list[idx - 1]; list[idx - 1] = list[idx]; list[idx] = t; ST.set(cfg.key, list); UI.closeSheet(); done(); } };
        var dn = el('button', 'btn'); dn.textContent = '下移'; dn.onclick = function () { if (idx < list.length - 1) { var t = list[idx + 1]; list[idx + 1] = list[idx]; list[idx] = t; ST.set(cfg.key, list); UI.closeSheet(); done(); } };
        var del = el('button', 'btn danger'); del.textContent = '删除'; del.onclick = function () { list.splice(idx, 1); ST.set(cfg.key, list); UI.closeSheet(); done(); UI.toast('已删除'); };
        row.appendChild(up); row.appendChild(dn); row.appendChild(del);
      }
      b.appendChild(row);
    }, { hideOk: true });
  }

  // ---------------------------------------------------------------- 其他
  function openOther() {
    UI.openPage('其他', function (body) {
      body.appendChild(rowBtn('关于与诊断', '版本、手机 WebView 版本、各库和图库连通测试', openAbout));
      body.appendChild(rowBtn('繁体写法', '简繁按钮转出的繁体：标准、台湾、香港', function () {
        var cur = Cv.getVariant();
        UI.openSheet('繁体写法', function (b) {
          [['std', '标准繁体'], ['tw', '台湾写法'], ['hk', '香港写法']].forEach(function (o) { b.appendChild(optBtn(o[1], cur === o[0], function () { Cv.setMode(Cv.getMode(), o[0]); next(function () { UI.toast('已设为' + o[1]); }); })); });
        }, { hideOk: true });
      }));
      body.appendChild(rowBtn('搜索记录', '共 ' + (ST.get('history') || []).length + ' 条，点这里清除', async function () { if (await UI.confirmBox('清除全部搜索记录？', '清除')) { ST.set('history', []); UI.toast('已清除'); } }));
      body.appendChild(rowBtn('备份与恢复', '把设置、各个链接列表复制出来，或粘贴回来', openBackup));
      body.appendChild(rowBtn('恢复默认设置', '链接列表、字体字号等恢复成出厂样子（不删数据和收藏）', async function () { if (await UI.confirmBox('恢复全部设置为默认？', '恢复')) { ST.reset(); F.apply(); root.PSBg.applyHome(); UI.toast('已恢复默认'); } }));
    });
  }
  function openBackup() {
    UI.openPage('备份与恢复', function (body) {
      var ta = el('textarea'); ta.rows = 12; ta.style.cssText = 'width:100%;border:1px solid var(--line);border-radius:10px;padding:8px;font-size:12px';
      ta.value = JSON.stringify(ST.all(), null, 1);
      body.appendChild(txt('p', 'tip', '下面是当前设置。"复制"可以保存到备忘录；换手机或重装后，把它粘贴回来点"恢复"。'));
      body.appendChild(ta);
      var cp = el('button', 'btn wide'); cp.textContent = '复制'; cp.onclick = function () { ta.select(); try { document.execCommand('copy'); UI.toast('已复制'); } catch (e) { UI.toast('请长按文字手动复制'); } };
      var rs = el('button', 'btn primary wide'); rs.textContent = '用上面的内容恢复';
      rs.onclick = function () {
        try { var o = JSON.parse(ta.value); if (!o || typeof o !== 'object') throw new Error('x'); Object.keys(o).forEach(function (k) { ST.set(k, o[k]); }); F.apply(); root.PSBg.applyHome(); UI.toast('已恢复'); }
        catch (e) { UI.toast('内容不是有效的设置'); }
      };
      body.appendChild(cp); body.appendChild(rs);
    });
  }
  function openAbout() {
    UI.openPage('关于与诊断', function (body) {
      var info = txt('div', 'tip', '读取中……'); body.appendChild(info);
      N.info().then(function (v) { info.textContent = '搜诗 ' + (v.app || '') + '\nWebView：' + (v.webview || '未知') + (v.device ? '\n设备：' + v.device : '') + '\n浏览器内核标识：' + navigator.userAgent; info.style.whiteSpace = 'pre-wrap'; });
      var out = el('div');
      var b1 = el('button', 'btn wide'); b1.textContent = '测试三家图库';
      b1.onclick = async function () {
        out.innerHTML = ''; out.appendChild(txt('p', 'tip', '测试中，请稍等……'));
        try {
          var r = await I.testGalleries(); var arr = Array.isArray(r) ? r : Object.keys(r || {}).map(function (k) { return Object.assign({ name: k }, r[k]); });
          out.innerHTML = '';
          arr.forEach(function (x) { out.appendChild(rowBtn((x.name || x.id || '图库') + (x.ok ? '：正常' : '：失败'), [x.ms ? x.ms + ' 毫秒' : '', x.error || x.msg || x.detail || ''].filter(Boolean).join(' · '), function () { })); });
        } catch (e) { out.innerHTML = ''; out.appendChild(txt('p', 'tip', '测试出错：' + (e.message || e))); }
        if (Cv.isReady()) Cv.apply(out);
      };
      var b2 = el('button', 'btn wide'); b2.textContent = '测试数据源连通（jsDelivr、GitHub 原始文件）';
      b2.onclick = async function () {
        out.innerHTML = ''; var f = Src.getFile('wn:唐.csv') || Src.allFiles()[0];
        if (!f) { out.appendChild(txt('p', 'tip', '没有读到数据库清单')); return; }
        var urls = Src.urls(f);
        for (var i = 0; i < urls.length; i++) {
          var t0 = Date.now(), msg;
          try { var rr = await fetch(urls[i], { headers: { Range: 'bytes=0-1023' }, cache: 'no-store' }); msg = rr.ok ? '正常 ' + (Date.now() - t0) + ' 毫秒' : '失败 HTTP ' + rr.status; }
          catch (e) { msg = '失败：' + (e.message || e); }
          out.appendChild(rowBtn(urls[i].split('/')[2], msg, function () { }));
        }
        if (Cv.isReady()) Cv.apply(out);
      };
      body.appendChild(b1); body.appendChild(b2); body.appendChild(out);
      body.appendChild(txt('p', 'tip', '联网的功能出问题时，把这里的结果截图发给我，我能更快找到原因。'));
    });
  }

  root.PSApp = root.PSApp || {};
  root.PSApp.openSettings = openSettings;
})(window);
