/* images.js — 诗页水墨背景：意象匹配、在线图库（大都会/芝加哥/克利夫兰，均为公有领域/CC0）、本地图、保存、AI 提示词 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory(root);
  else root.PSImages = factory(root);
})(typeof self !== 'undefined' ? self : this, function (root) {
  'use strict';

  var LOCAL_COUNT = 36;

  // 意象 → 英文检索词（博物馆资料是英文）。顺序靠前的优先。
  var DICT = [
    ['月', 'moon'], ['山', 'mountain'], ['松', 'pine'], ['梅', 'plum blossom'], ['竹', 'bamboo'], ['雪', 'snow'],
    ['舟', 'boat'], ['船', 'boat'], ['帆', 'boat'], ['渔', 'fisherman'], ['钓', 'fisherman'],
    ['江', 'river'], ['河', 'river'], ['湖', 'lake'], ['水', 'river'], ['海', 'sea'], ['瀑', 'waterfall'], ['泉', 'spring'],
    ['云', 'clouds'], ['雨', 'rain'], ['烟', 'mist'], ['雾', 'mist'], ['霜', 'frost'],
    ['菊', 'chrysanthemum'], ['兰', 'orchid'], ['荷', 'lotus'], ['莲', 'lotus'], ['柳', 'willow'], ['桃', 'peach'],
    ['杏', 'apricot'], ['牡丹', 'peony'], ['桐', 'wutong tree'], ['蕉', 'banana plant'], ['花', 'flowers'], ['草', 'grass'], ['林', 'forest'],
    ['鹤', 'crane'], ['雁', 'geese'], ['燕', 'swallow'], ['鸦', 'crow'], ['鹭', 'egret'], ['鸟', 'bird'], ['鸡', 'rooster'],
    ['马', 'horse'], ['牛', 'ox'], ['虎', 'tiger'], ['龙', 'dragon'], ['猿', 'gibbon'], ['鱼', 'fish'], ['蝶', 'butterfly'],
    ['亭', 'pavilion'], ['楼', 'pavilion'], ['桥', 'bridge'], ['寺', 'temple'], ['钟', 'temple'], ['塔', 'pagoda'], ['村', 'village'], ['城', 'city'],
    ['琴', 'qin'], ['酒', 'wine'], ['书', 'scholar'], ['僧', 'monk'], ['隐', 'hermit'],
    ['秋', 'autumn'], ['春', 'spring'], ['冬', 'winter'], ['夏', 'summer'],
    ['夜', 'night'], ['日', 'sun'], ['星', 'stars'], ['石', 'rock'], ['路', 'road'], ['风', 'wind']
  ];

  function hash(s) {
    var h = 2166136261;
    s = String(s);
    for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); }
    return h >>> 0;
  }
  function poemKey(p) {
    return [p.src || '', p.author || '', p.title || '', Array.from(p.content || '').slice(0, 12).join('')].join('|');
  }

  // 取诗里出现最多的意象（至多 max 个英文词）；一个都没有就用 landscape
  function imageryTerms(text, max) {
    max = max || 3;
    var t = String(text || ''), score = {}, order = {};
    DICT.forEach(function (d, idx) {
      var n = t.split(d[0]).length - 1;
      if (n > 0) {
        score[d[1]] = (score[d[1]] || 0) + n;
        if (order[d[1]] === undefined) order[d[1]] = idx;
      }
    });
    var terms = Object.keys(score).sort(function (a, b) { return score[b] - score[a] || order[a] - order[b]; });
    if (!terms.length) terms = ['landscape'];
    return terms.slice(0, max);
  }

  function localUrl(n) { return 'img/bg/bg' + String(n).padStart(2, '0') + '.webp'; }
  function localIndexFor(key) { return (hash(key) % LOCAL_COUNT) + 1; }

  // ---------------------------------------------------------------- 图库
  async function getJson(url, signal, timeout) {
    var ctl = new AbortController();
    var to = setTimeout(function () { ctl.abort(); }, timeout || 8000);
    if (signal) { if (signal.aborted) ctl.abort(); else signal.addEventListener('abort', function () { ctl.abort(); }); }
    try {
      var r = await fetch(url, { signal: ctl.signal });
      if (!r.ok) throw new Error('HTTP ' + r.status);
      return await r.json();
    } finally { clearTimeout(to); }
  }

  var MET = 'https://collectionapi.metmuseum.org/public/collection/v1/';
  async function metSearch(term, n, signal) {
    var s = await getJson(MET + 'search?hasImages=true&departmentId=6&q=' + encodeURIComponent(term), signal);
    var ids = (s.objectIDs || []).slice(0, 60), out = [];
    for (var i = 0; i < ids.length && out.length < n; i += 6) {
      var objs = await Promise.all(ids.slice(i, i + 6).map(function (id) { return getJson(MET + 'objects/' + id, signal).catch(function () { return null; }); }));
      for (var k = 0; k < objs.length; k++) {
        var o = objs[k];
        if (!o || !o.isPublicDomain || !o.primaryImageSmall) continue;
        if (!/china|chinese/i.test((o.culture || '') + ' ' + (o.country || '') + ' ' + (o.objectName || ''))) continue;
        if (!/paint|scroll|album|leaf|fan|hanging/i.test((o.classification || '') + ' ' + (o.objectName || ''))) continue;
        out.push({
          id: 'met:' + o.objectID, thumb: o.primaryImageSmall, url: o.primaryImageSmall, source: 'met',
          credit: '大都会艺术博物馆 · ' + (o.title || '') + (o.artistDisplayName ? ' · ' + o.artistDisplayName : ''), link: o.objectURL || ''
        });
        if (out.length >= n) break;
      }
    }
    return out;
  }

  async function aicSearch(term, n, signal) {
    var u = 'https://api.artic.edu/api/v1/artworks/search?q=' + encodeURIComponent(term + ' chinese') +
      '&query[term][is_public_domain]=true&limit=30&fields=id,title,artist_display,image_id,place_of_origin,classification_title';
    var j = await getJson(u, signal);
    var iiif = (j.config && j.config.iiif_url) || 'https://www.artic.edu/iiif/2';
    return (j.data || []).filter(function (a) { return a.image_id && /china|chinese/i.test(a.place_of_origin || ''); }).slice(0, n).map(function (a) {
      return {
        id: 'aic:' + a.id, thumb: iiif + '/' + a.image_id + '/full/240,/0/default.jpg', url: iiif + '/' + a.image_id + '/full/843,/0/default.jpg', source: 'aic',
        credit: '芝加哥艺术博物馆 · ' + (a.title || '') + (a.artist_display ? ' · ' + String(a.artist_display).split('\n')[0] : ''), link: 'https://www.artic.edu/artworks/' + a.id
      };
    });
  }

  var CMA = 'https://openaccess-api.clevelandart.org/api/artworks/?cc0=1&has_image=1&limit=30&fields=id,title,creators,images,url,culture,type&q=';
  async function cmaSearch(term, n, signal) {
    var j = await getJson(CMA + encodeURIComponent(term) + '&department=' + encodeURIComponent('Chinese Art') + '&type=Painting', signal);
    var list = j.data || [];
    if (!list.length) { j = await getJson(CMA + encodeURIComponent(term + ' chinese painting'), signal); list = j.data || []; }
    return list.filter(function (a) { return a.images && a.images.web && a.images.web.url; }).slice(0, n).map(function (a) {
      var cr = a.creators && a.creators[0] ? a.creators[0].description : '';
      return { id: 'cma:' + a.id, thumb: a.images.web.url, url: a.images.web.url, source: 'cma', credit: '克利夫兰艺术博物馆 · ' + (a.title || '') + (cr ? ' · ' + cr : ''), link: a.url || '' };
    });
  }

  var GALLERIES = [
    { id: 'met', name: '大都会艺术博物馆（Met）', search: metSearch },
    { id: 'aic', name: '芝加哥艺术博物馆', search: aicSearch },
    { id: 'cma', name: '克利夫兰艺术博物馆', search: cmaSearch }
  ];

  var memo = {}; // 同一词同一图库的结果只取一次
  async function searchGallery(g, term, n, signal) {
    var k = g.id + '|' + term;
    if (memo[k]) return memo[k];
    var r = await g.search(term, n || 12, signal);
    if (r.length) memo[k] = r;
    return r;
  }

  // 自动匹配：按意象词、按图库顺序，第一个有结果的就用，并按诗的哈希挑一张（同一首诗每次一样）
  // 自动更换（每点一次换一张）：按图库顺序从网络图库取，排除当前这张，随机挑一张新的
  async function autoPickNew(poem, enabled, excludeUrl, signal) {
    var terms = imageryTerms((poem.title || '') + (poem.content || ''), 3).concat(['mountain landscape']);
    var gs = GALLERIES.filter(function (g) { return enabled[g.id]; });
    for (var i = 0; i < terms.length; i++) {
      for (var j = 0; j < gs.length; j++) {
        if (signal && signal.aborted) return null;
        try {
          var r = await searchGallery(gs[j], terms[i], 12, signal);
          var fresh = r.filter(function (x) { return x.url && x.url !== excludeUrl; });
          if (fresh.length) return fresh[Math.floor(Math.random() * fresh.length)];
        } catch (e) { /* 这个图库打不开，换下一个 */ }
      }
    }
    return null;
  }

  async function autoMatch(poem, enabled, signal) {
    var terms = imageryTerms((poem.title || '') + (poem.content || ''), 3).concat(['mountain landscape']);
    var gs = GALLERIES.filter(function (g) { return enabled[g.id]; });
    for (var i = 0; i < terms.length; i++) {
      for (var j = 0; j < gs.length; j++) {
        if (signal && signal.aborted) return null;
        try {
          var r = await searchGallery(gs[j], terms[i], 12, signal);
          if (r.length) return r[hash(poemKey(poem)) % r.length];
        } catch (e) { /* 这个图库打不开，换下一个 */ }
      }
    }
    return null;
  }

  // 换图候选：所有已开启图库各取几张（并行，互不拖累）
  async function candidates(poem, enabled, signal) {
    var terms = imageryTerms((poem.title || '') + (poem.content || ''), 2);
    var gs = GALLERIES.filter(function (g) { return enabled[g.id]; });
    var jobs = [];
    gs.forEach(function (g) {
      terms.forEach(function (t) { jobs.push(searchGallery(g, t, 8, signal).catch(function () { return []; })); });
    });
    var lists = await Promise.all(jobs), seen = {}, out = [];
    lists.forEach(function (l) { l.forEach(function (c) { if (!seen[c.id]) { seen[c.id] = 1; out.push(c); } }); });
    return { list: out, terms: terms };
  }

  function loadImage(url, timeout) {
    return new Promise(function (res) {
      var im = new Image(), done = false;
      function fin(ok) { if (!done) { done = true; res(ok); } }
      im.onload = function () { fin(true); };
      im.onerror = function () { fin(false); };
      setTimeout(function () { fin(false); }, timeout || 6000);
      im.src = url;
    });
  }

  async function testGalleries(enabled) {
    var out = [];
    for (var i = 0; i < GALLERIES.length; i++) {
      var g = GALLERIES[i], t0 = Date.now(), res = { id: g.id, name: g.name, enabled: !!enabled[g.id] };
      try {
        var list = await g.search('moon', 3);
        res.count = list.length; res.ms = Date.now() - t0;
        res.ok = list.length > 0;
        if (list[0]) res.imageOk = await loadImage(list[0].thumb, 7000);
      } catch (e) { res.ok = false; res.error = String(e.message || e); res.ms = Date.now() - t0; }
      out.push(res);
    }
    return out;
  }

  // ---------------------------------------------------------------- 保存到本地 / 显示
  async function downloadBlob(url) {
    var r = await fetch(url);
    if (!r.ok) throw new Error('HTTP ' + r.status);
    return await r.blob();
  }
  async function saveCandidate(Store, poem, cand) {
    var blob = await downloadBlob(cand.url);
    var id = 'img-' + cand.id.replace(/[^\w:.-]/g, '_');
    await Store.putImage({ id: id, blob: blob, credit: cand.credit, link: cand.link || '', source: cand.source, added: Date.now() });
    if (poem) await Store.setMap(poemKey(poem), { kind: 'blob', id: id });
    return id;
  }

  // 解析这首诗该用的背景：先看是否已选定 → 再在线自动匹配（限时）→ 否则本地图
  async function resolveBackground(Store, poem, settings, timeoutMs) {
    var key = poemKey(poem), ref = null;
    try { ref = await Store.getMap(key); } catch (e) { ref = null; }
    if (ref) {
      if (ref.kind === 'local') return { kind: 'local', url: localUrl(ref.n), credit: '' };
      if (ref.kind === 'blob') {
        try {
          var rec = await Store.getImage(ref.id);
          if (rec && rec.blob) return { kind: 'blob', url: URL.createObjectURL(rec.blob), credit: rec.credit || '', link: rec.link || '', revoke: true };
        } catch (e) { /* 取不到就往下走 */ }
      }
      if (ref.kind === 'url' && ref.url) return { kind: 'url', url: ref.url, credit: ref.credit || '', link: ref.link || '', fallback: localUrl(localIndexFor(key)) };
    }
    var local = { kind: 'local', url: localUrl(localIndexFor(key)), credit: '' };
    if (!settings.autoOnline || (typeof navigator !== 'undefined' && navigator.onLine === false)) return local;
    var ctl = new AbortController();
    var timer = new Promise(function (res) { setTimeout(function () { res('timeout'); }, timeoutMs || 3500); });
    var match = autoMatch(poem, settings.galleries || {}, ctl.signal);
    var r = await Promise.race([match, timer]);
    if (r === 'timeout') { ctl.abort(); return local; }
    if (!r) return local;
    var ok = await loadImage(r.url, 4000);
    if (!ok) return local;
    try { await Store.setMap(key, { kind: 'url', url: r.url, credit: r.credit, link: r.link || '' }); } catch (e) { /* ignore */ }
    return { kind: 'url', url: r.url, credit: r.credit, link: r.link || '', fallback: local.url };
  }

  // ---------------------------------------------------------------- AI 生图提示词（半自动：复制后到你选的 AI 网站粘贴）
  function aiPrompt(poem) {
    var lines = String(poem.content || '').replace(/\r\n?/g, '\n').split('\n').filter(Boolean).slice(0, 4).join('');
    var terms = imageryTerms((poem.title || '') + (poem.content || ''), 3);
    return {
      zh: '中国传统水墨画，宣纸质感，淡墨渲染，大量留白，意境：' + (poem.title ? '《' + poem.title + '》' : '') + lines.slice(0, 60).replace(/[。，、；：！？\s]+$/, '') + '。画面不要出现文字和印章。竖构图。',
      en: 'Traditional Chinese ink wash painting on rice paper, misty, lots of empty space, subjects: ' + terms.join(', ') + '. No text, vertical composition.'
    };
  }

  return {
    LOCAL_COUNT: LOCAL_COUNT, DICT: DICT, GALLERIES: GALLERIES, hash: hash, poemKey: poemKey, imageryTerms: imageryTerms,
    localUrl: localUrl, localIndexFor: localIndexFor, autoMatch: autoMatch, autoPickNew: autoPickNew, candidates: candidates, testGalleries: testGalleries,
    saveCandidate: saveCandidate, resolveBackground: resolveBackground, aiPrompt: aiPrompt, loadImage: loadImage, downloadBlob: downloadBlob
  };
});
