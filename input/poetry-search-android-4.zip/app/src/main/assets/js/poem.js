/* poem.js — 诗词全文页：文字直接透明地写在背景图上；上下滑动看上一首/下一首；收藏；换图；全屏（点屏幕恢复）；明暗；简繁 */
(function (root) {
  'use strict';
  var UI = root.PSUI, ST = root.PSSettings, St = root.PSStore, I = root.PSImages, Bg = root.PSBg, N = root.PSNative, Cv = root.PSConvert;
  var el = UI.el, S = { list: [], i: 0, layer: null, full: false, open: false, handle: null, bg: null, token: 0, onClose: null };
  var $ = function (id) { return document.getElementById(id); };

  // 排版规则（Derek 确认）：
  // 五言：上下句并成一行，总长不超过约 12 字（含标点）。
  // 七言、杂言：每个句末标点结束一句，一句一行，不并行。
  // 宋词（有逗号的长句）：句号、问号、感叹号断行；超过约 12 字的句子在逗号处拆开；
  //   三字一逗号的短句可以并在一行；同一行已有两个逗号，之后再出现的逗号另起一行。
  var MAXLINE = 12;
  function splitSents(text) {
    return String(text).split(/(?<=[。！？；!?])/).map(function (x) { return x.trim(); }).filter(Boolean);
  }
  function wrapLong(sent) {
    // 超长句：在逗号处拆开，且同一行最多两个逗号
    if (Array.from(sent).length <= MAXLINE) return [sent];
    var parts = sent.split(/(?<=[，,、])/).map(function (x) { return x.trim(); }).filter(Boolean), out = [], cur = '', commas = 0;
    parts.forEach(function (p) {
      var join = cur + p, nc = (join.match(/[，,、]/g) || []).length;
      if (cur && (Array.from(join).length > MAXLINE || nc > 2)) { out.push(cur); cur = p; }
      else cur = join;
    });
    if (cur) out.push(cur);
    return out;
  }
  function lines(c) {
    c = String(c || '').replace(/\r\n?/g, '\n');
    var raw = c.indexOf('\n') >= 0 ? c.split('\n').map(function (x) { return x.trim(); }).filter(Boolean) : splitSents(c);
    var out = [];
    raw.forEach(function (ln) {
      if (Array.from(ln).length <= MAXLINE && (ln.match(/[。！？；!?]/g) || []).length === 2) {
        out.push(ln);                       // 五言上下句：并一行（一行里正好两个句末标点，总长不超过约 12 字）
      } else {
        splitSents(ln).forEach(function (sent) { wrapLong(sent).forEach(function (x) { out.push(x); }); });
      }
    });
    return out;
  }
  function slim(p) { return { src: p.src, srcLabel: p.srcLabel, book: p.book, title: p.title, author: p.author, dynasty: p.dynasty, content: p.content, tr: p.tr, an: p.an, cm: p.cm }; }

  function build() {
    if (S.layer) return;
    var L = el('div', 'poem-layer hidden');
    L.innerHTML =
      '<div class="p-bg" id="pBg"></div><div class="p-shade" id="pShade"></div>' +
      '<div class="p-scroll" id="pScroll"><div class="p-in" id="pIn"><h2 id="pTitle"></h2><div id="pMeta"></div><div id="pText"></div><div id="pExtra"></div><div id="pCredit"></div></div></div>' +
      '<div class="p-bar" id="pBar"><button id="pBack" aria-label="返回">‹</button><span class="sp"></span>' +
      '<div class="p-tools" id="pTools"><button id="pConv" data-noconv>简</button><button id="pSwap">换图</button><button id="pFont">字体</button><button id="pDim">明暗</button></div>' +
      '<button class="p-orb" id="pOrb" aria-label="展开功能"></button></div>' +
      '<button class="p-pick" id="pWhole">整首</button><button class="p-pick" id="pPart">部分</button>' +
      '<div class="p-dim hidden" id="pDimRow"><input type="range" min="-50" max="50" step="5" id="pDimR"></div><div class="p-pos" id="pPos"></div>';
    document.body.appendChild(L); S.layer = L;
    $('pBack').onclick = function () { UI.closeTop(); };
    $('pSwap').onclick = function () {
      var p = S.list[S.i];
      Bg.openSourceDialog(p, function () { return (S.bg && S.bg.url) || ''; }, function () { loadBg(p); });
    };
    $('pFont').onclick = function (e) { e.stopPropagation(); if (root.PSFontItem) root.PSFontItem.open('poem'); };
    $('pDim').onclick = function () { $('pDimRow').classList.toggle('hidden'); };
    $('pDimR').oninput = function () { ST.set('dim', +this.value); shade(); };
    $('pOrb').onclick = function (e) { e.stopPropagation(); toggleTools(); };
    if (root.PSCrystal && root.PSCrystal.applyPoem) root.PSCrystal.applyPoem();
    $('pWhole').onclick = function (e) { e.stopPropagation(); $('pWhole').classList.remove('show'); toggleFav(); };
    $('pPart').onclick = function (e) { e.stopPropagation(); $('pPart').classList.remove('show'); savePart(); };
    // 双击诗页任意位置（不含按钮条）→ 显示"整首"
    var lastTap = 0;
    L.addEventListener('touchend', function (e) {
      if (e.target.closest && e.target.closest('#pBar, #pDimRow, .p-pick')) return;
      var now = Date.now();
      if (now - lastTap < 350) { e.preventDefault(); showWhole(); lastTap = 0; } else lastTap = now;
    }, { passive: false });
    // 选中文字 → 显示"部分"按钮
    document.addEventListener('selectionchange', function () {
      if (!S.open) return;
      var sel = window.getSelection ? window.getSelection().toString().trim() : '';
      var inPoem = $('pIn') && window.getSelection && window.getSelection().anchorNode && $('pIn').contains(window.getSelection().anchorNode);
      $('pPart').classList.toggle('show', !!sel && !!inPoem);
    });
    $('pConv').onclick = function () { Cv.toggle(); };
    Cv.onChange(syncConv);
    // 上下滑动：到边之后再滑，切到下一首/上一首
    var sc = $('pScroll'), y0 = 0, x0 = 0, moved = false;
    sc.addEventListener('touchstart', function (e) { var t = e.touches[0]; y0 = t.clientY; x0 = t.clientX; moved = false; }, { passive: true });
    sc.addEventListener('touchmove', function (e) { var t = e.touches[0]; if (Math.abs(t.clientY - y0) > 8 || Math.abs(t.clientX - x0) > 8) moved = true; }, { passive: true });
    sc.addEventListener('touchend', function (e) {
      var t = e.changedTouches[0], dy = t.clientY - y0, dx = t.clientX - x0;
      if (!moved) return;
      if (Math.abs(dy) < 70 || Math.abs(dx) > 80) return;
      var atBottom = sc.scrollTop + sc.clientHeight >= sc.scrollHeight - 3, atTop = sc.scrollTop <= 3;
      if (dy < 0 && atBottom) go(1); else if (dy > 0 && atTop) go(-1);
    }, { passive: true });
    L.addEventListener('click', function (e) {                                             // 全屏时点一下屏幕：恢复按钮
      if (e.target.closest && e.target.closest('#pBar, #pDimRow')) return;
      if (!moved) hideAll();
    });
  }

  function toggleTools() { var t = $('pTools'); t.classList.toggle('open'); }
  function hideAll() { var bar = $('pBar'); if (bar.classList.contains('gone')) { bar.classList.remove('gone'); $('pTools').classList.remove('open'); } else { bar.classList.add('gone'); $('pTools').classList.remove('open'); } }
  // 双击诗页任意位置，弹出"整首"按钮；点它就整首收藏
  function showWhole() {
    var b = $('pWhole'); b.classList.add('show');
    clearTimeout(showWhole.t); showWhole.t = setTimeout(function () { b.classList.remove('show'); }, 3500);
  }
  function syncConv() { var b = $('pConv'); if (b) b.textContent = Cv.getMode() === 's' ? '简' : '繁'; }

  function shade() {
    var sh = $('pShade'), d = ST.get('dim') || 0, base = (S.layer.dataset.tone === 'unk') ? 0.22 : 0;
    sh.style.background = d >= 0 ? 'rgba(0,0,0,' + (base + d / 100).toFixed(2) + ')' : 'rgba(255,255,255,' + (-d / 100).toFixed(2) + ')';
    $('pDimR').value = d;
  }
  function measure(url) {                                  // 量一下背景图明暗，决定字用浅色还是深色
    return new Promise(function (res) {
      var im = new Image(); im.crossOrigin = 'anonymous';
      im.onload = function () {
        try {
          var c = document.createElement('canvas'); c.width = c.height = 24;
          var g = c.getContext('2d'); g.drawImage(im, 0, 0, 24, 24);
          var d = g.getImageData(0, 0, 24, 24).data, s = 0;
          for (var i = 0; i < d.length; i += 4) s += 0.299 * d[i] + 0.587 * d[i + 1] + 0.114 * d[i + 2];
          res(s / (d.length / 4) < 120 ? 'dark' : 'light');   // 图暗 → 字浅；图亮 → 字深
        } catch (e) { res('unk'); }
      };
      im.onerror = function () { res('unk'); };
      im.src = url;
    });
  }
  async function setBg(bg) {
    S.bg = bg;
    $('pBg').style.backgroundImage = 'url("' + bg.url + '")';
    var tone = await measure(bg.url);
    S.layer.dataset.tone = tone; shade();
    $('pCredit').textContent = bg.credit ? '图：' + bg.credit : '';
    if (Cv.isReady()) Cv.apply($('pCredit'));
  }
  async function loadBg(p) {
    var tk = ++S.token;
    if (S.handle) S.handle.cancel();
    var h = await Bg.forPoem(p, function (nb) { if (tk === S.token) setBg(nb); });
    if (tk !== S.token) { h.cancel(); return; }
    S.handle = h; setBg(h.bg);
  }

  async function refreshFav() {
    var p = S.list[S.i]; if (!p) return;
    var r = null; try { r = await St.getFav(I.poemKey(p)); } catch (e) { r = null; }
    $('pFav').textContent = r ? '★' : '☆';
  }
  async function toggleFav() {
    var p = S.list[S.i], key = I.poemKey(p), r = await St.getFav(key);
    if (r) { await St.deleteFav(key); UI.toast('已取消收藏'); }
    else { await St.putFav({ key: key, kind: 'whole', poem: slim(p), at: Date.now() }); UI.toast('已收藏整首'); }
    refreshFav();
    if (S.onFavChange) S.onFavChange();
  }

  // 部分收藏：把选中的文字存进收藏的"部分"（句子）
  async function savePart() {
    var sel = window.getSelection ? window.getSelection().toString().trim() : '';
    if (!sel) return;
    var p = S.list[S.i], key = 'part:' + I.poemKey(p) + ':' + sel;
    await St.putFav({ key: key, kind: 'part', text: sel, poem: slim(p), at: Date.now() });
    if (window.getSelection) window.getSelection().removeAllRanges();
    UI.toast('已收藏选中部分');
    if (S.onFavChange) S.onFavChange();
  }

  function render(dir) {
    var p = S.list[S.i];
    $('pTitle').textContent = p.title || '（无题）';
    $('pMeta').textContent = [p.author, p.dynasty, p.srcLabel && (p.srcLabel + (p.book ? ' · ' + p.book : ''))].filter(Boolean).join('  ·  ');
    var t = $('pText'); t.innerHTML = '';
    lines(p.content).forEach(function (ln) { var d = el('div', 'p-line'); d.textContent = ln; t.appendChild(d); });
    var ex = $('pExtra'); ex.innerHTML = '';
    [['译文', p.tr], ['注释', p.an], ['赏析', p.cm]].forEach(function (x) {
      if (!x[1]) return;
      var d = el('details', 'p-ex'), s = el('summary'); s.textContent = x[0]; d.appendChild(s);
      var b = el('div', 'p-ex-b'); b.textContent = x[1]; d.appendChild(b); ex.appendChild(d);
    });
    $('pPos').textContent = S.list.length > 1 ? (S.i + 1) + ' / ' + S.list.length : '';
    $('pScroll').scrollTop = 0;
    var inn = $('pIn'); inn.classList.remove('enter-up', 'enter-down'); void inn.offsetWidth;
    if (dir) inn.classList.add(dir > 0 ? 'enter-up' : 'enter-down');
    if (Cv.isReady()) Cv.apply(S.layer);
    syncConv(); refreshFav(); loadBg(p);
  }
  function go(d) {
    var n = S.i + d;
    if (n < 0) { UI.toast('已经是第一首'); return; }
    if (n >= S.list.length) { UI.toast('已经是最后一首'); return; }
    S.i = n; render(d);
  }

  // list：当前这批诗（搜索结果或收藏）；index：先看哪一首
  function open(list, index, opts) {
    build();
    S.list = list; S.i = Math.max(0, Math.min(index || 0, list.length - 1)); S.onClose = opts && opts.onClose; S.onFavChange = opts && opts.onFavChange;
    S.layer.style.zIndex = UI.nextZ(); S.layer.classList.remove('hidden', 'full'); S.open = true;
    $('pBar').classList.remove('gone'); $('pTools').classList.remove('open');
    $('pDimRow').classList.add('hidden');
    N.statusIcons(false);                                    // 背景图多是深色：状态栏图标用白色
    UI.pushOverlay(function () {
      S.layer.classList.add('hidden'); S.open = false; S.token++; if (S.handle) S.handle.cancel(); N.statusIcons(true);
      if (S.onClose) S.onClose();
    });
    render(0);
  }
  root.PSPoem = { open: open, isOpen: function () { return S.open; }, lines: lines };
})(window);
