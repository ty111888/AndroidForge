/* parsers.js — 导入用的文件解析：编码识别、CSV、JSON/JSONL、TXT 段落、dBase/FoxPro(.dbf + .fpt)
 * 浏览器里挂在 window.PSParsers，Node 里用 require 引入（方便测试）。
 * 所有"文件"参数只要有 size、name、slice(a,b).arrayBuffer() 就行（浏览器 File/Blob、Node Blob 都可以）。 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.PSParsers = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  var MB = 1024 * 1024;

  // ---------------------------------------------------------------- 编码
  function detectEncoding(u8) {
    if (u8.length >= 3 && u8[0] === 0xEF && u8[1] === 0xBB && u8[2] === 0xBF) return 'utf-8';
    if (u8.length >= 2 && u8[0] === 0xFF && u8[1] === 0xFE) return 'utf-16le';
    if (u8.length >= 2 && u8[0] === 0xFE && u8[1] === 0xFF) return 'utf-16be';
    try { new TextDecoder('utf-8', { fatal: true }).decode(u8, { stream: true }); return 'utf-8'; } catch (e) { /* not utf-8 */ }
    return 'gb18030';
  }

  function decodeBest(u8, encoding) {
    var enc = encoding && encoding !== 'auto' ? encoding : detectEncoding(u8.subarray(0, Math.min(u8.length, 262144)));
    return { text: new TextDecoder(enc).decode(u8), encoding: enc };
  }

  // ---------------------------------------------------------------- CSV（流式逐行，支持引号、引号内逗号/换行、CRLF、BOM）
  function* csvRows(text) {
    var n = text.length, i = 0;
    if (text.charCodeAt(0) === 0xFEFF) i = 1;
    var row = [];
    while (i < n) {
      var field;
      if (text.charCodeAt(i) === 34) { // "
        i++;
        var parts = '';
        for (;;) {
          var j = text.indexOf('"', i);
          if (j < 0) { parts += text.slice(i); i = n; break; }
          parts += text.slice(i, j);
          if (text.charCodeAt(j + 1) === 34) { parts += '"'; i = j + 2; continue; }
          i = j + 1; break;
        }
        // 引号后到分隔符之间的杂字符直接并入
        var k = i;
        while (k < n) { var cc = text.charCodeAt(k); if (cc === 44 || cc === 10 || cc === 13) break; k++; }
        if (k > i) { parts += text.slice(i, k); i = k; }
        field = parts;
      } else {
        var e = i;
        while (e < n) { var c0 = text.charCodeAt(e); if (c0 === 44 || c0 === 10 || c0 === 13) break; e++; }
        field = text.slice(i, e); i = e;
      }
      row.push(field);
      var c = text.charCodeAt(i);
      if (c === 44) { // 逗号：下一个字段
        i++;
        if (i >= n) { row.push(''); yield row; row = []; }
        continue;
      }
      // 行尾
      if (c === 13) { i++; if (text.charCodeAt(i) === 10) i++; }
      else if (c === 10) i++;
      if (!(row.length === 1 && row[0] === '')) yield row; // 跳过空行
      row = [];
    }
    if (row.length) yield row;
  }

  // ---------------------------------------------------------------- 字段猜测
  var GUESS = {
    title: ['题目', '标题', '诗题', '篇名', 'title', 'rhythmic', '词牌', 'name', '题'],
    author: ['作者', '诗人', '作家', 'author', 'poet', 'writer'],
    dynasty: ['朝代', '年代', '时代', 'dynasty'],
    content: ['内容', '正文', '原文', '全文', '诗词', 'content', 'paragraphs', 'text', 'body'],
    book: ['书名', '书籍', '文集', '出处', 'book', 'collection', 'source']
  };
  function guessMapping(names) {
    var out = {}, used = {};
    Object.keys(GUESS).forEach(function (key) {
      var found = '';
      var lower = names.map(function (x) { return String(x).trim().toLowerCase(); });
      for (var a = 0; a < GUESS[key].length && !found; a++) {
        var g = GUESS[key][a].toLowerCase();
        var idx = lower.indexOf(g);
        if (idx >= 0 && !used[names[idx]]) found = names[idx];
      }
      for (var b = 0; b < GUESS[key].length && !found; b++) {
        var g2 = GUESS[key][b].toLowerCase();
        for (var m = 0; m < lower.length; m++) {
          if (lower[m].indexOf(g2) >= 0 && !used[names[m]]) { found = names[m]; break; }
        }
      }
      if (found) used[found] = 1;
      out[key] = found;
    });
    return out;
  }

  // ---------------------------------------------------------------- JSON / JSONL
  function flattenValue(v) {
    if (v == null) return '';
    if (Array.isArray(v)) return v.map(flattenValue).join('\n');
    if (typeof v === 'object') {
      if (v.name != null) return String(v.name);
      return JSON.stringify(v);
    }
    return String(v);
  }
  function firstArrayOfObjects(o, depth) {
    if (depth > 2 || !o || typeof o !== 'object') return null;
    var keys = Object.keys(o);
    for (var i = 0; i < keys.length; i++) {
      var v = o[keys[i]];
      if (Array.isArray(v) && v.length && typeof v[0] === 'object') return v;
    }
    for (var j = 0; j < keys.length; j++) {
      var r = firstArrayOfObjects(o[keys[j]], depth + 1);
      if (r) return r;
    }
    return null;
  }
  async function readJsonRecords(file, encoding) {
    var buf = new Uint8Array(await file.slice(0, file.size).arrayBuffer());
    var s = decodeBest(buf, encoding).text.replace(/^\uFEFF/, '').trim();
    var first = s.charAt(0);
    var arr = null;
    if (first === '[') arr = JSON.parse(s);
    else if (first === '{') {
      try {
        var o = JSON.parse(s);
        arr = Array.isArray(o) ? o : (firstArrayOfObjects(o, 0) || [o]);
      } catch (e) { arr = null; }
    }
    if (!arr) { // JSONL
      arr = [];
      var lines = s.split(/\r?\n/);
      for (var i = 0; i < lines.length; i++) {
        var l = lines[i].trim();
        if (l) arr.push(JSON.parse(l));
      }
    }
    return arr.map(function (r) {
      if (r && typeof r === 'object' && !Array.isArray(r)) {
        var o2 = {};
        Object.keys(r).forEach(function (k) { o2[k] = flattenValue(r[k]); });
        return o2;
      }
      return { text: flattenValue(r) };
    });
  }

  // ---------------------------------------------------------------- CSV 文件 → 记录
  async function readCsvRecords(file, encoding, hasHeader) {
    var buf = new Uint8Array(await file.slice(0, file.size).arrayBuffer());
    var text = decodeBest(buf, encoding).text;
    var rows = csvRows(text), names = null, out = [];
    for (var r of rows) {
      if (!names) {
        if (hasHeader === false) names = r.map(function (_, i) { return '列' + (i + 1); });
        else { names = r.map(function (x) { return String(x).trim(); }); continue; }
      }
      var o = {};
      for (var i = 0; i < names.length; i++) o[names[i]] = r[i] == null ? '' : r[i];
      out.push(o);
    }
    return { fields: names || [], records: out };
  }

  // ---------------------------------------------------------------- TXT → 段落（流式，适合很大的文件）
  async function* readParagraphs(file, encoding) {
    var chunk = 4 * MB, size = file.size, enc = encoding && encoding !== 'auto' ? encoding : null, dec = null, carry = '';
    for (var off = 0; off < size; off += chunk) {
      var buf = new Uint8Array(await file.slice(off, Math.min(size, off + chunk)).arrayBuffer());
      if (!enc) enc = detectEncoding(buf.subarray(0, Math.min(buf.length, 262144)));
      if (!dec) dec = new TextDecoder(enc);
      var last = off + chunk >= size;
      var text = carry + dec.decode(buf, { stream: !last });
      var lines = text.split(/\r\n|\r|\n/);
      carry = last ? '' : lines.pop();
      for (var li = 0; li < lines.length; li++) {
        var t = lines[li].replace(/^\uFEFF/, '').trim();
        if (!t) continue;
        if (t.length <= 1200) { yield t; continue; }
        // 超长的一行：在句末标点处切成约 600 字一段
        var piece = '';
        var parts = t.split(/(?<=[。！？!?；;])/u);
        for (var pi = 0; pi < parts.length; pi++) {
          piece += parts[pi];
          if (piece.length >= 600) { yield piece; piece = ''; }
        }
        if (piece.trim()) yield piece;
      }
    }
    if (carry.trim()) yield carry.trim();
  }

  // ---------------------------------------------------------------- dBase / FoxPro
  function dbfEncodingFromLdid(ldid) {
    switch (ldid) {
      case 0x4D: case 0x7A: return 'gbk';
      case 0x4F: case 0x78: return 'big5';
      case 0x4E: case 0x79: return 'euc-kr';
      case 0x7B: return 'shift_jis';
      case 0x03: return 'windows-1252';
      default: return 'auto';
    }
  }

  function trimBytes(u8) { // 去掉右侧空格/0
    var e = u8.length;
    while (e > 0 && (u8[e - 1] === 0x20 || u8[e - 1] === 0x00)) e--;
    return u8.subarray(0, e);
  }

  function readMemoRef(u8, len) {
    if (len === 4) return (u8[0] | (u8[1] << 8) | (u8[2] << 16) | (u8[3] << 24)) >>> 0;
    var s = '';
    for (var i = 0; i < u8.length; i++) if (u8[i] >= 0x30 && u8[i] <= 0x39) s += String.fromCharCode(u8[i]);
    return s ? parseInt(s, 10) : 0;
  }

  // 备注文件（.fpt = FoxPro；.dbt = dBase III）。带滑动窗口，顺序读很快
  function MemoReader(file, kind) {
    this.file = file; this.kind = kind; this.blockSize = 64; this.win = null;
  }
  MemoReader.prototype.init = async function () {
    var head = new Uint8Array(await this.file.slice(0, 512).arrayBuffer());
    if (this.kind === 'fpt') {
      var bs = (head[6] << 8) | head[7];
      this.blockSize = bs > 0 ? bs : 64;
    } else {
      this.blockSize = 512;
    }
  };
  MemoReader.prototype._ensure = async function (off, need) {
    var w = this.win;
    if (w && off >= w.start && off + need <= w.start + w.u8.length) return;
    var len = Math.max(need, 8 * MB);
    var end = Math.min(this.file.size, off + len);
    this.win = { start: off, u8: new Uint8Array(await this.file.slice(off, end).arrayBuffer()) };
  };
  MemoReader.prototype.get = async function (block) {
    if (!block) return new Uint8Array(0);
    var off = block * this.blockSize;
    if (off >= this.file.size) return new Uint8Array(0);
    if (this.kind === 'fpt') {
      await this._ensure(off, 8);
      var w = this.win, p = off - w.start;
      if (p + 8 > w.u8.length) return new Uint8Array(0);
      var len = ((w.u8[p + 4] << 24) | (w.u8[p + 5] << 16) | (w.u8[p + 6] << 8) | w.u8[p + 7]) >>> 0;
      await this._ensure(off, 8 + len);
      w = this.win; p = off - w.start;
      return w.u8.subarray(p + 8, Math.min(w.u8.length, p + 8 + len));
    }
    // dbt：到 0x1A 结束
    await this._ensure(off, 4096);
    var w2 = this.win, p2 = off - w2.start, e = p2;
    for (;;) {
      while (e < w2.u8.length && w2.u8[e] !== 0x1A) e++;
      if (e < w2.u8.length) break;
      await this._ensure(off, (e - p2) + 1 + 65536);
      w2 = this.win; p2 = off - w2.start;
      if (e >= w2.u8.length) break;
    }
    return w2.u8.subarray(p2, Math.min(e, w2.u8.length));
  };

  async function openDbf(file, memoFile, memoName, opts) {
    opts = opts || {};
    var head = new Uint8Array(await file.slice(0, 32).arrayBuffer());
    if (head.length < 32) throw new Error('不是有效的 dbf 文件（太短）');
    var dv = new DataView(head.buffer, head.byteOffset, 32);
    var nrec = dv.getUint32(4, true), hlen = dv.getUint16(8, true), rlen = dv.getUint16(10, true), ldid = head[29];
    if (!hlen || !rlen || hlen < 33) throw new Error('不是有效的 dbf 文件（头部异常）');
    var h = new Uint8Array(await file.slice(0, hlen).arrayBuffer());
    var rawFields = [], off = 32;
    while (off + 32 <= hlen && off + 32 <= h.length && h[off] !== 0x0D) {
      var end = off; while (end < off + 11 && h[end] !== 0) end++;
      rawFields.push({ nameBytes: h.slice(off, end), type: String.fromCharCode(h[off + 11]), len: h[off + 16], dec: h[off + 17] });
      off += 32;
    }
    if (h[off] !== 0x0D || !rawFields.length) throw new Error('不是有效的 dbf 文件（找不到字段表）');
    var pos = 1;
    rawFields.forEach(function (f) { f.pos = pos; pos += f.len; });
    if (pos > rlen) throw new Error('不是有效的 dbf 文件（字段长度对不上）');

    // 编码
    var enc = opts.encoding && opts.encoding !== 'auto' ? opts.encoding : dbfEncodingFromLdid(ldid);
    if (enc === 'auto') {
      // 取前 50 条的字符型字段字节做 UTF-8 严格检测
      var sampleN = Math.min(nrec, 50);
      var sbuf = new Uint8Array(await file.slice(hlen, hlen + sampleN * rlen).arrayBuffer());
      var ok = true, utf = new TextDecoder('utf-8', { fatal: true });
      for (var r = 0; r < sampleN && ok; r++) {
        for (var fi = 0; fi < rawFields.length && ok; fi++) {
          var f0 = rawFields[fi];
          if (f0.type !== 'C') continue;
          try { utf.decode(trimBytes(sbuf.subarray(r * rlen + f0.pos, r * rlen + f0.pos + f0.len))); } catch (e) { ok = false; }
        }
      }
      enc = ok ? 'utf-8' : 'gbk';
    }
    var dec = new TextDecoder(enc);
    var fields = rawFields.map(function (f) {
      return { name: dec.decode(f.nameBytes).trim(), type: f.type, len: f.len, dec: f.dec, pos: f.pos };
    });

    var memo = null;
    if (memoFile) {
      var kind = /\.dbt$/i.test(memoName || '') ? 'dbt' : 'fpt';
      memo = new MemoReader(memoFile, kind);
      await memo.init();
    }
    var hasMemoFields = fields.some(function (f) { return f.type === 'M'; });

    async function* records(batch) {
      batch = batch || 2000;
      var perChunk = Math.max(1, Math.floor((4 * MB) / rlen));
      var out = [];
      for (var start = 0; start < nrec; start += perChunk) {
        var cnt = Math.min(perChunk, nrec - start);
        var buf = new Uint8Array(await file.slice(hlen + start * rlen, hlen + (start + cnt) * rlen).arrayBuffer());
        for (var i = 0; i < cnt; i++) {
          var base = i * rlen;
          if (base + rlen > buf.length) break;
          if (buf[base] === 0x2A) continue; // 已删除
          var rec = {};
          for (var k = 0; k < fields.length; k++) {
            var f = fields[k], raw = buf.subarray(base + f.pos, base + f.pos + f.len), v = '';
            if (f.type === 'C') v = dec.decode(trimBytes(raw));
            else if (f.type === 'M') {
              if (memo) {
                var ref = readMemoRef(raw, f.len);
                var mb = ref ? await memo.get(ref) : null;
                v = mb && mb.length ? dec.decode(trimBytes(mb)) : '';
              }
            }
            else if (f.type === 'N' || f.type === 'F' || f.type === 'D' || f.type === 'L') v = dec.decode(trimBytes(raw)).trim();
            else if (f.type === 'I' && f.len === 4) v = String(new DataView(raw.buffer, raw.byteOffset, 4).getInt32(0, true));
            else continue; // 图片/OLE/二进制字段忽略
            rec[f.name] = v;
          }
          out.push(rec);
          if (out.length >= batch) { yield out; out = []; }
        }
      }
      if (out.length) yield out;
    }
    return { fields: fields, count: nrec, encoding: enc, hasMemoFields: hasMemoFields, memoMissing: hasMemoFields && !memo, records: records };
  }

  return {
    detectEncoding: detectEncoding, decodeBest: decodeBest, csvRows: csvRows, guessMapping: guessMapping,
    readJsonRecords: readJsonRecords, readCsvRecords: readCsvRecords, readParagraphs: readParagraphs,
    openDbf: openDbf, dbfEncodingFromLdid: dbfEncodingFromLdid, MemoReader: MemoReader, flattenValue: flattenValue
  };
});
