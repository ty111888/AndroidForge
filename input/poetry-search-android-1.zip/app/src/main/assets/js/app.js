/* app.js — 主界面：搜索页（范围/朝代/书籍/数据库选择、结果）、数据库页、设置页、诗词搜索（外部网站）页 */
(function () {
  'use strict';
  var UI = PSUI, C = PSCore, S = PSSources, SR = PSSearch, I = PSImages, St = PSStore;
  var $ = UI.$, el = UI.el;

  // ---------------------------------------------------------------- 设置与状态（存在本机）
  var SETTINGS_KEY = 'ps-settings', STATE_KEY = 'ps-state';
  var SETTING_DEFAULT = { convert: true, autoOnline: true, galleries: { met: true, aic: true, cma: true }, aiSites: [] };
  var STATE_DEFAULT = { scope: 'all', dynasties: [], books: [], dbs: ['orig-tang', 'orig-ci'] };
  function load(key, def) {
    try { return Object.assign({}, def, JSON.parse(localStorage.getItem(key) || '{}')); } catch (e) { return Object.assign({}, def); }
  }
  var settings = load(SETTINGS_KEY, SETTING_DEFAULT);
  settings.galleries = Object.assign({}, SETTING_DEFAULT.galleries, settings.galleries || {});
  if (!Array.isArray(settings.aiSites)) settings.aiSites = [];
  var state = load(STATE_KEY, STATE_DEFAULT);
  function saveSettings() { try { localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings)); } catch (e) { /* ignore */ } }
  function saveState() { try { localStorage.setItem(STATE_KEY, JSON.stringify(state)); } catch (e) { /* ignore */ } }

  // ---------------------------------------------------------------- 诗词搜索（外部网站）——网址按你给的原样
  var SITES = [
    ['搜韵', 'https://www.sou-yun.cn/index.aspx'],
    ['识典古籍', 'https://www.shidianguji.com/'],
    ['汉典诗词', 'https://sc.zdic.net/'],
    ['中国哲学书电子化计划', 'https://ctext.org/pre-qin-and-han/zhs'],
    ['中华经典古籍库', 'https://jingdian.ancientbooks.cn/6'],
    ['汉籍全文资料库', 'https://hanchi.ihp.sinica.edu.tw/ihp/hanji.htm'],
    ['韵典网', 'https://ytenx.org/'],
    ['古诗文断句', 'https://seg.shenshen.wiki/'],
    ['古籍文本对勘', 'https://guji.xueheng.net/'],
    ['AI太炎', 'https://t.shenshen.wiki/']
  ];

  var datasets = [];
  function allDefs() { return S.BUILTIN.concat(S.datasetDefs(datasets)); }
  function defById(id) { return allDefs().filter(function (d) { return d.id === id; })[0]; }
  async function refreshDatasets() { try { datasets = await St.getDatasets(); } catch (e) { datasets = []; } }

  // ---------------------------------------------------------------- 页面切换
  function showPage(name) {
    document.querySelectorAll('.page').forEach(function (p) { p.classList.toggle('on', p.id === 'pg-' + name); });
    document.querySelectorAll('.tabs button').forEach(function (b) { b.classList.toggle('on', b.getAttribute('data-pg') === name); });
    $('main').scrollTop = 0;
    if (name === 'data') renderData();
  }

  // ---------------------------------------------------------------- 筛选条
  function renderFilters() {
    $('scope').value = state.scope;
    $('fDyn').textContent = '朝代：' + (state.dynasties.length ? state.dynasties.join('、') : '不限') + ' ▾';
    $('fDyn').classList.toggle('on', state.dynasties.length > 0);
    $('fBook').textContent = '书籍/文集：' + (state.books.length ? state.books.length + ' 个' : '不限') + ' ▾';
    $('fBook').classList.toggle('on', state.books.length > 0);
    var n = state.dbs.filter(function (id) { return defById(id); }).length;
    $('fDb').textContent = '数据库：' + n + ' 个 ▾';
  }

  function openDynSheet() {
    UI.openSheet('限定朝代（可多选，不选=不限）', function (b) {
      var box = el('div', 'chips');
      C.DYNASTIES.forEach(function (d) {
        var c = el('button', 'chip' + (state.dynasties.indexOf(d) >= 0 ? ' on' : ''), d); c.type = 'button';
        c.onclick = function () {
          var i = state.dynasties.indexOf(d);
          if (i >= 0) state.dynasties.splice(i, 1); else state.dynasties.push(d);
          c.classList.toggle('on'); saveState(); renderFilters();
        };
        box.appendChild(c);
      });
      b.appendChild(box);
      var clr = el('button', 'btn', '清空（不限朝代）'); clr.type = 'button';
      clr.onclick = function () { state.dynasties = []; saveState(); renderFilters(); box.querySelectorAll('.chip').forEach(function (x) { x.classList.remove('on'); }); };
      b.appendChild(clr);
      b.appendChild(el('p', 'hint', '“元末明初”这类跨朝代的会同时算元和明。没有朝代信息的记录选了朝代后不会出现。'));
    });
  }

  function knownBooks() {
    var seen = {}, out = [];
    allDefs().forEach(function (d) {
      if (d.book && !seen[d.book]) { seen[d.book] = 1; out.push(d.book); }
    });
    return out;
  }
  function openBookSheet() {
    UI.openSheet('限定书籍/文集（不选=不限）', function (b) {
      var books = knownBooks();
      books.forEach(function (name) {
        var row = el('label', 'opt');
        var cb = el('input'); cb.type = 'checkbox'; cb.checked = state.books.indexOf(name) >= 0;
        cb.onchange = function () {
          var i = state.books.indexOf(name);
          if (cb.checked && i < 0) state.books.push(name);
          if (!cb.checked && i >= 0) state.books.splice(i, 1);
          saveState(); renderFilters();
        };
        row.appendChild(cb); row.appendChild(el('span', '', C.esc(name)));
        b.appendChild(row);
      });
      b.appendChild(el('p', 'hint', '选了书籍后，没有书籍信息的库（Werneror、诗泉）不会出结果。导入的数据库会以书名出现在这里。'));
    });
  }

  function openDbSheet() {
    UI.openSheet('选择要搜索的数据库', function (b) {
      var group = '';
      allDefs().forEach(function (d) {
        if (d.group !== group) { group = d.group; b.appendChild(el('div', 'grp', C.esc(group))); }
        var row = el('label', 'opt');
        var cb = el('input'); cb.type = 'checkbox'; cb.checked = state.dbs.indexOf(d.id) >= 0;
        cb.onchange = function () {
          var i = state.dbs.indexOf(d.id);
          if (cb.checked && i < 0) state.dbs.push(d.id);
          if (!cb.checked && i >= 0) state.dbs.splice(i, 1);
          saveState(); renderFilters();
        };
        var t = el('span', '', C.esc(d.label) + '<span class="sub">' + C.esc(d.note || '') + '</span>');
        row.appendChild(cb); row.appendChild(t); b.appendChild(row);
      });
      if (!datasets.length) b.appendChild(el('p', 'hint', '导入的数据库会出现在这里（到“数据库”页导入）。'));
    });
  }

  // ---------------------------------------------------------------- 搜索
  var running = null, hitCount = 0;

  function srcLabels(item) {
    var out = [];
    item.srcs.forEach(function (id) { var d = defById(id); if (d) out.push(d.label); });
    return out;
  }
  function tagsHTML(item) {
    return srcLabels(item).slice(0, 3).map(function (x) { return '<span class="tag">' + C.esc(x) + '</span>'; }).join('');
  }
  function metaHTML(p, item) {
    var name = p.title ? '《' + p.title + '》' : (p.book ? '《' + p.book + '》' : '');
    var parts = [p.author ? C.esc(p.author) : '', C.esc(name), p.dynasty ? C.esc(p.dynasty) : ''].filter(Boolean);
    if (p.title && p.book && p.book !== p.title) parts.push(C.esc(p.book));
    return parts.join(' · ') + '<span class="tags">' + tagsHTML(item) + '</span>';
  }

  function snippetHTML(p, hits) {
    var lines = C.poemLines(p.content);
    if (lines.length > 8) {
      var i = 0;
      for (; i < lines.length; i++) { if (hits.some(function (h) { return lines[i].indexOf(h) >= 0; })) break; }
      if (i >= lines.length) i = 0;
      lines = lines.slice(Math.max(0, i - 1), i + 2);
    }
    return lines.map(function (l) { return '<p>' + C.highlight(l, hits) + '</p>'; }).join('');
  }

  function makeHit(item) {
    var p = item.poem, h = item.hit, card;
    if (h.kind === 'sentence') {
      card = el('article', 'hit',
        '<div class="sent">' + (h.pre ? '…' : '') + C.highlight(h.text, h.hits) + (h.post ? '…' : '') + '</div>' +
        (h.neighbor ? '<div class="nb">' + C.esc(h.neighbor) + '</div>' : '') +
        '<div class="meta"></div>');
    } else {
      card = el('article', 'hit poem',
        '<h3>' + C.esc(p.title || p.book || '') + '</h3>' + snippetHTML(p, h.hits) + '<div class="meta"></div>');
    }
    card.querySelector('.meta').innerHTML = metaHTML(p, item);
    card.onclick = function () { PSPoem.open(p, h.hits); };
    item.el = card;
    return card;
  }

  function setRunning(on) { $('go').textContent = on ? '停止' : '搜索'; }
  function status(msg) { $('st').textContent = msg; }

  async function doSearch() {
    if (running) { running.abort(); return; }
    var query = $('q').value;
    if (!query.trim()) { status('请输入关键字'); return; }
    var defs = allDefs().filter(function (d) { return state.dbs.indexOf(d.id) >= 0; });
    if (!defs.length) { status('请先在“数据库”里至少选一个'); return; }
    var ctl = new AbortController(); var sig = ctl.signal; running = ctl; setRunning(true);
    $('out').innerHTML = ''; $('notes').textContent = ''; hitCount = 0;
    $('bar').firstElementChild.style.width = '0';
    var big = defs.filter(function (d) { return d.kind === 'csv'; });
    if (big.length) $('notes').textContent = '提示：' + big.map(function (d) { return d.label; }).join('、') + ' 首次搜索要下载较大的文件，建议连 Wi‑Fi；下载后会缓存。';
    status('开始搜索…');
    try {
      var r = await SR.run({
        query: query, scope: state.scope,
        filters: { dynasties: new Set(state.dynasties), books: new Set(state.books) },
        defs: defs, convert: !!settings.convert, cap: 400, signal: sig,
        onHit: function (item) { hitCount++; $('out').appendChild(makeHit(item)); },
        onMerge: function (item) { if (item.el) item.el.querySelector('.meta').innerHTML = metaHTML(item.poem, item); },
        onProgress: function (p) {
          $('bar').firstElementChild.style.width = (p.total ? Math.round(p.done / p.total * 100) : 0) + '%';
          status('已搜 ' + p.done + '/' + p.total + '，命中 ' + p.hits + (p.fails ? '，失败 ' + p.fails : ''));
        },
        onNote: function (m) { var n = $('notes'); n.textContent += (n.textContent ? '\n' : '') + m; }
      });
      var msg = r.aborted ? '已停止，' : '完成，';
      msg += '命中 ' + r.hits + ' 条' + (r.capped ? '（到达上限 400 条，请缩小范围）' : '') + (r.fails ? '，' + r.fails + ' 个文件没取到' : '');
      if (!r.hits && !r.aborted) msg += r.multi ? '。提示：空格分隔的词必须在同一句里。' : '。';
      status(msg);
    } catch (e) {
      status('出错：' + (e.message || e));
    } finally {
      running = null; setRunning(false);
      $('bar').firstElementChild.style.width = '0';
    }
  }

  // ---------------------------------------------------------------- 数据库页
  function renderData() {
    var bl = $('builtinList'); bl.innerHTML = '';
    S.BUILTIN.forEach(function (d) {
      bl.appendChild(el('div', 'card', '<b>' + C.esc(d.label) + '</b> <span class="sub">· ' + C.esc(d.group) + '</span><div class="sub">' + C.esc(d.note || '') + '</div>'));
    });
    var il = $('importedList'); il.innerHTML = '';
    if (!datasets.length) il.appendChild(el('p', 'hint', '还没有导入过。'));
    datasets.forEach(function (m) {
      var card = el('div', 'card');
      var row = el('div', 'row');
      row.appendChild(el('div', '', '<b>' + C.esc(m.name) + '</b><div class="sub">' + (m.mode === 'book' ? '全文资料' : '诗词库') + ' · ' + (m.count || 0) + ' 条</div>'));
      var del = el('button', 'btn', '删除'); del.type = 'button';
      del.onclick = async function () {
        if (!(await UI.confirmBox('删除“' + m.name + '”？删除后要重新导入。', '删除'))) return;
        await St.deleteDataset(m.id);
        state.dbs = state.dbs.filter(function (x) { return x !== 'ds-' + m.id; });
        state.books = state.books.filter(function (x) { return x !== (m.book || m.name); });
        saveState(); await refreshDatasets(); renderData(); renderFilters(); UI.toast('已删除');
      };
      row.appendChild(del); card.appendChild(row); il.appendChild(card);
    });
    St.usage().then(function (u) {
      $('usage').textContent = u ? '本 App 已用存储约 ' + (u.usage / 1048576).toFixed(1) + ' MB（可用上限约 ' + Math.round(u.quota / 1048576) + ' MB）' : '';
    });
  }

  // ---------------------------------------------------------------- 设置页
  function renderSettings() {
    $('stConvert').checked = !!settings.convert;
    $('stAuto').checked = !!settings.autoOnline;
    var gl = $('galleryList'); gl.innerHTML = '';
    I.GALLERIES.forEach(function (g) {
      var row = el('label', 'sw');
      var cb = el('input'); cb.type = 'checkbox'; cb.checked = !!settings.galleries[g.id];
      cb.onchange = function () { settings.galleries[g.id] = cb.checked; saveSettings(); };
      row.appendChild(cb); row.appendChild(el('span', '', C.esc(g.name)));
      gl.appendChild(row);
    });
    renderAiList();
  }
  function renderAiList() {
    var l = $('aiList'); l.innerHTML = '';
    if (!settings.aiSites.length) l.appendChild(el('p', 'hint', '还没添加。'));
    settings.aiSites.forEach(function (s, i) {
      var card = el('div', 'card'), row = el('div', 'row');
      row.appendChild(el('div', '', '<b>' + C.esc(s.name) + '</b><div class="sub">' + C.esc(s.url) + '</div>'));
      var del = el('button', 'btn', '删除'); del.type = 'button';
      del.onclick = function () { settings.aiSites.splice(i, 1); saveSettings(); renderAiList(); };
      row.appendChild(del); card.appendChild(row); l.appendChild(card);
    });
  }

  async function testGalleries() {
    var out = $('galRes'); out.textContent = '测试中，每个图库最多等几秒…';
    var res = await I.testGalleries(settings.galleries);
    out.textContent = res.map(function (r) {
      return (r.ok ? '✓ ' : '✗ ') + r.name + (r.ok ? '：取到 ' + r.count + ' 张，图片' + (r.imageOk ? '能显示' : '没能显示') + '（' + r.ms + ' ms）' : '：失败 ' + (r.error || '没有结果') + '（' + r.ms + ' ms）');
    }).join('\n');
  }
  async function testShiquan() {
    var out = $('sqRes'); out.textContent = '测试中…';
    var r = await S.testShiquan('明月光');
    if (!r.ok && r.error) { out.textContent = '✗ 失败：' + r.error; return; }
    out.textContent = (r.ok ? '✓ ' : '✗ 能连上但格式没认出来 · ') + r.ms + ' ms · 返回 ' + r.count + ' 条\n地址：' + r.url +
      (r.first ? '\n第一条：' + [r.first.author, r.first.title, r.first.dynasty].filter(Boolean).join(' · ') + '\n' + Array.from(r.first.content).slice(0, 30).join('') : '') +
      '\n\n原始内容开头（出问题时请把这段截图发给我）：\n' + r.raw;
  }

  // ---------------------------------------------------------------- 诗词搜索（外部网站）页
  function renderSites() {
    var l = $('sitesList'); l.innerHTML = '';
    SITES.forEach(function (s) {
      var a = el('a', 'card site', '<b>' + C.esc(s[0]) + '</b><div class="sub">' + C.esc(s[1]) + '</div>');
      a.href = s[1];
      l.appendChild(a);
    });
  }

  // ---------------------------------------------------------------- 启动
  async function init() {
    await refreshDatasets();
    // 清掉已不存在的数据库勾选
    state.dbs = state.dbs.filter(function (id) { return defById(id); });
    if (!state.dbs.length) state.dbs = STATE_DEFAULT.dbs.slice();
    renderFilters(); renderSettings(); renderSites();

    document.querySelectorAll('.tabs button').forEach(function (b) { b.onclick = function () { showPage(b.getAttribute('data-pg')); }; });
    $('btnSites').onclick = function () { showPage('sites'); };
    $('sitesBack').onclick = function () { showPage('search'); };
    $('searchForm').addEventListener('submit', function (e) { e.preventDefault(); doSearch(); });
    $('go').addEventListener('click', function (e) { if (running) { e.preventDefault(); running.abort(); } });
    $('scope').onchange = function () { state.scope = $('scope').value; saveState(); };
    $('fDyn').onclick = openDynSheet; $('fBook').onclick = openBookSheet; $('fDb').onclick = openDbSheet;

    $('btnImport').onclick = function () { $('fileIn').value = ''; $('fileIn').click(); };
    $('fileIn').addEventListener('change', function (e) { PSImport.start(e.target.files); });
    PSImport.init({
      onDone: async function (id) {
        await refreshDatasets();
        if (state.dbs.indexOf('ds-' + id) < 0) state.dbs.push('ds-' + id);
        saveState(); renderData(); renderFilters();
      }
    });
    PSPoem.init({ settings: function () { return settings; } });

    $('stConvert').onchange = function () { settings.convert = $('stConvert').checked; saveSettings(); };
    $('stAuto').onchange = function () { settings.autoOnline = $('stAuto').checked; saveSettings(); };
    $('btnTestGal').onclick = testGalleries;
    $('btnTestSq').onclick = testShiquan;
    $('btnClearImg').onclick = async function () {
      if (!(await UI.confirmBox('清除所有保存到手机的背景图和每首诗的选图记录？', '清除'))) return;
      await St.clearImages(); UI.toast('已清除');
    };
    $('aiAdd').onclick = function () {
      var name = $('aiName').value.trim(), url = $('aiUrl').value.trim();
      if (!name || !/^https?:\/\//i.test(url)) { UI.toast('请填名称和以 http 开头的网址'); return; }
      settings.aiSites.push({ name: name, url: url }); saveSettings(); renderAiList();
      $('aiName').value = ''; $('aiUrl').value = '';
    };
    $('out').appendChild(el('div', 'empty'));
  }

  document.addEventListener('DOMContentLoaded', init);
})();
