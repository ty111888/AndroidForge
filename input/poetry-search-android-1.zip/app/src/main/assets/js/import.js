/* import.js — 导入向导：txt（全文资料）、csv、json/jsonl、dbf+fpt（诗词库，选字段对应关系）
 * 导入后的数据存在手机 App 里（IndexedDB），之后和别的数据库一样可以勾选搜索。 */
(function (root) {
  'use strict';
  var UI = root.PSUI, P = root.PSParsers, St = root.PSStore;
  var $ = UI.$, el = UI.el;

  var hooks = { onDone: function () {} };
  function init(h) { hooks = h; }

  var LATER = ['pdf', 'epub', 'mobi', 'azw3', 'azw', 'fb2', 'html', 'htm', 'db', 'sqlite', 'sqlite3', 'docx', 'xlsx', 'xls'];

  function ext(name) { var m = /\.([^.]+)$/.exec(name || ''); return m ? m[1].toLowerCase() : ''; }
  function base(name) { return (name || '').replace(/\.[^.]+$/, ''); }
  function field(label, node) { var r = el('label', 'frm'); r.appendChild(el('span', '', label)); r.appendChild(node); return r; }

  async function sniff(file) {
    try {
      var u = new Uint8Array(await file.slice(0, 16).arrayBuffer());
      var s = String.fromCharCode.apply(null, Array.from(u));
      if (s.indexOf('SQLite format 3') === 0) return 'sqlite';
      if (s.indexOf('%PDF') === 0) return 'pdf';
      if (s.indexOf('PK') === 0) return 'zip';
    } catch (e) { /* ignore */ }
    return '';
  }

  // ---------------------------------------------------------------- 入口
  async function start(fileList) {
    var files = Array.prototype.slice.call(fileList || []);
    if (!files.length) return;
    var groups = [], by = {};
    files.forEach(function (f) {
      var e = ext(f.name), b = base(f.name).toLowerCase();
      if (e === 'fpt' || e === 'dbt') { (by[b] = by[b] || {}).memo = f; return; }
      if (e === 'dbf') { (by[b] = by[b] || {}).dbf = f; return; }
      groups.push({ kind: 'file', file: f });
    });
    Object.keys(by).forEach(function (b) {
      var g = by[b];
      if (g.dbf) groups.push({ kind: 'dbf', file: g.dbf, memo: g.memo || null });
      else if (g.memo) groups.push({ kind: 'orphan', file: g.memo });
    });
    for (var i = 0; i < groups.length; i++) await handle(groups[i]);
  }

  async function handle(g) {
    if (g.kind === 'orphan') { UI.toast('只选了 ' + g.file.name + '：请把同名的 .dbf 一起选上', 4000); return; }
    if (g.kind === 'dbf') return wizardRecords(g, 'dbf', function (enc) { return loadDbf(g, enc); });
    var e = ext(g.file.name);
    if (e === 'txt' || e === 'text') return wizardText(g);
    if (e === 'csv') return wizardRecords(g, 'CSV', function (enc) { return loadCsv(g, enc); });
    if (e === 'json' || e === 'jsonl' || e === 'ndjson') return wizardRecords(g, 'JSON', function (enc) { return loadJson(g, enc); });
    var kind = LATER.indexOf(e) >= 0 ? e : await sniff(g.file);
    if (kind) { UI.toast('“' + g.file.name + '”这个格式（' + kind + '）下一版才支持', 4500); return; }
    UI.toast('不认识的格式：' + g.file.name + '。现在支持 txt、csv、json/jsonl、dbf+fpt', 4500);
  }

  // ---------------------------------------------------------------- 读取各种格式
  async function loadDbf(g, enc) {
    var db = await P.openDbf(g.file, g.memo, g.memo ? g.memo.name : '', { encoding: enc });
    var preview = [];
    for await (var b of db.records(3)) { preview = b.slice(0, 3); break; }
    return {
      fields: db.fields.map(function (f) { return f.name; }), count: db.count, preview: preview,
      info: '编码：' + db.encoding + '，共 ' + db.count + ' 条' + (db.memoMissing ? '' : ''),
      warn: db.memoMissing ? '这个库有“备注”字段（长文本，诗的正文通常在里面），但你没有一起选 .fpt，备注内容会是空的。请把同名的 .fpt 也一起选上再导入。' : '',
      batches: function () { return db.records(2000); }
    };
  }
  function arrayBatches(records) {
    return async function* () { for (var i = 0; i < records.length; i += 2000) yield records.slice(i, i + 2000); };
  }
  async function loadCsv(g, enc) {
    var r = await P.readCsvRecords(g.file, enc, true);
    return { fields: r.fields, count: r.records.length, preview: r.records.slice(0, 3), info: '共 ' + r.records.length + ' 条', warn: '', batches: arrayBatches(r.records) };
  }
  async function loadJson(g, enc) {
    var recs = await P.readJsonRecords(g.file, enc), fields = [], seen = {};
    recs.slice(0, 50).forEach(function (r) { Object.keys(r).forEach(function (k) { if (!seen[k]) { seen[k] = 1; fields.push(k); } }); });
    return { fields: fields, count: recs.length, preview: recs.slice(0, 3), info: '共 ' + recs.length + ' 条', warn: '', batches: arrayBatches(recs) };
  }

  // ---------------------------------------------------------------- 写入
  function norm(r, map, name) {
    return {
      title: map.title ? String(r[map.title] || '').trim() : '',
      author: map.author ? String(r[map.author] || '').trim() : '',
      dynasty: map.dynasty ? String(r[map.dynasty] || '').trim() : '',
      book: map.book ? String(r[map.book] || '').trim() || name : name,
      content: map.content ? String(r[map.content] || '').trim() : ''
    };
  }
  function newId() { return 'd' + Date.now().toString(36) + Math.random().toString(36).slice(2, 5); }

  async function importBatches(o) {
    var id = newId(), chunk = 0, buf = [], count = 0, seen = 0;
    try {
      for await (var batch of o.batches()) {
        if (o.isCancelled()) throw 'cancel';
        for (var i = 0; i < batch.length; i++) {
          seen++;
          var rec = o.convert(batch[i]);
          if (!rec.content) continue;
          buf.push(rec); count++;
          if (buf.length >= 2000) { await St.putChunk(id, chunk++, buf); buf = []; }
        }
        o.onProgress(seen);
      }
      if (buf.length) await St.putChunk(id, chunk++, buf);
      await St.putDataset({ id: id, name: o.name, mode: o.mode, count: count, chunks: chunk, book: o.name, createdAt: Date.now() });
      return { id: id, count: count };
    } catch (e) {
      try { await St.deleteDataset(id); } catch (x) { /* ignore */ }
      if (e === 'cancel') return { cancelled: true };
      throw e;
    }
  }

  // ---------------------------------------------------------------- 向导：诗词库（有字段）
  function wizardRecords(g, label, loader) {
    return new Promise(function (resolve) {
      var cancel = false;
      UI.openSheet('导入 ' + label + '：' + g.file.name, function (body) {
        var nameIn = el('input', 'inp'); nameIn.value = base(g.file.name);
        var encSel = el('select', 'sel');
        [['auto', '自动识别'], ['utf-8', 'UTF-8'], ['gbk', 'GBK（简体中文常用）'], ['big5', 'Big5（繁体）']].forEach(function (x) { encSel.appendChild(new Option(x[1], x[0])); });
        body.appendChild(field('名称', nameIn));
        body.appendChild(field('编码', encSel));
        var info = el('p', 'hint'), mapBox = el('div'), prev = el('div', 'preview'), warn = el('p', 'warn');
        body.appendChild(info); body.appendChild(mapBox); body.appendChild(prev); body.appendChild(warn);
        var prog = el('div', 'prog hidden', '<div class="bar"><i></i></div><p></p>');
        body.appendChild(prog);
        var go = el('button', 'btn primary', '开始导入'); go.type = 'button'; go.disabled = true;
        body.appendChild(go);

        var src = null, sel = {};
        function mapNow() { var m = {}; Object.keys(sel).forEach(function (k) { m[k] = sel[k].value; }); return m; }
        function refreshPreview() {
          var m = mapNow(), name = nameIn.value.trim() || base(g.file.name);
          prev.innerHTML = '';
          src.preview.forEach(function (r) {
            var n = norm(r, m, name);
            var d = el('div', 'pv-row');
            d.appendChild(el('b', '', root.PSCore.esc(n.title || '（无题）') + ' ' + root.PSCore.esc([n.author, n.dynasty].filter(Boolean).join(' · '))));
            d.appendChild(el('span', '', root.PSCore.esc(Array.from(n.content).slice(0, 40).join('') || '（正文为空）')));
            prev.appendChild(d);
          });
          if (!src.preview.length) prev.textContent = '没有读到记录。';
        }
        async function load() {
          prev.textContent = '读取中…'; go.disabled = true; mapBox.innerHTML = ''; warn.textContent = '';
          try { src = await loader(encSel.value); }
          catch (e) { prev.textContent = '读取失败：' + (e.message || e); return; }
          info.textContent = src.info || '';
          warn.textContent = src.warn || '';
          var guess = P.guessMapping(src.fields); sel = {};
          [['title', '题目'], ['author', '作者'], ['dynasty', '朝代'], ['content', '正文（必选）'], ['book', '书籍/文集（可选）']].forEach(function (x) {
            var s = el('select', 'sel'); s.appendChild(new Option('（不使用）', ''));
            src.fields.forEach(function (f) { s.appendChild(new Option(f, f)); });
            s.value = guess[x[0]] || ''; s.onchange = refreshPreview; sel[x[0]] = s;
            mapBox.appendChild(field(x[1], s));
          });
          refreshPreview(); go.disabled = false;
        }
        encSel.onchange = load;
        load();

        go.onclick = async function () {
          var m = mapNow();
          if (!m.content) { UI.toast('请先选“正文”对应的是哪个字段'); return; }
          var name = nameIn.value.trim() || base(g.file.name);
          go.disabled = true; prog.classList.remove('hidden');
          var bar = prog.querySelector('i'), txt = prog.querySelector('p');
          try {
            var res = await importBatches({
              name: name, mode: 'poems', batches: src.batches, isCancelled: function () { return cancel; },
              convert: function (r) { return norm(r, m, name); },
              onProgress: function (n) {
                bar.style.width = (src.count ? Math.min(100, Math.round(n / src.count * 100)) : 0) + '%';
                txt.textContent = '已处理 ' + n + (src.count ? ' / ' + src.count : '') + ' 条';
              }
            });
            if (res.cancelled) UI.toast('已取消');
            else { UI.toast('已导入 ' + res.count + ' 条', 3500); hooks.onDone(res.id); }
          } catch (e) { UI.toast('导入失败：' + (e.message || e), 5000); }
          UI.closeSheet();
        };
      }, { hideOk: true, onClose: function () { cancel = true; resolve(); } });
    });
  }

  // ---------------------------------------------------------------- 向导：txt（全文资料）
  function wizardText(g) {
    return new Promise(function (resolve) {
      var cancel = false;
      UI.openSheet('导入 txt：' + g.file.name, function (body) {
        var nameIn = el('input', 'inp'); nameIn.value = base(g.file.name);
        var encSel = el('select', 'sel');
        [['auto', '自动识别'], ['utf-8', 'UTF-8'], ['gbk', 'GBK（简体中文常用）'], ['big5', 'Big5（繁体）']].forEach(function (x) { encSel.appendChild(new Option(x[1], x[0])); });
        body.appendChild(field('书名', nameIn)); body.appendChild(field('编码', encSel));
        body.appendChild(el('p', 'hint', 'txt 按“全文资料”导入：每一段当一条记录，搜到后显示命中的那一句和相邻句，标上书名。'));
        var prev = el('div', 'preview'); body.appendChild(prev);
        var prog = el('div', 'prog hidden', '<div class="bar"><i></i></div><p></p>'); body.appendChild(prog);
        var go = el('button', 'btn primary', '开始导入'); go.type = 'button'; body.appendChild(go);

        async function showPreview() {
          prev.textContent = '读取中…';
          try {
            var n = 0; prev.innerHTML = '';
            for await (var p of P.readParagraphs(g.file.slice(0, 200000), encSel.value)) {
              prev.appendChild(el('div', 'pv-row', '<span>' + root.PSCore.esc(Array.from(p).slice(0, 60).join('')) + '</span>'));
              if (++n >= 3) break;
            }
            if (!n) prev.textContent = '没有读到文字，试试换一个编码。';
          } catch (e) { prev.textContent = '读取失败：' + (e.message || e); }
        }
        encSel.onchange = showPreview; showPreview();

        go.onclick = async function () {
          var name = nameIn.value.trim() || base(g.file.name);
          go.disabled = true; prog.classList.remove('hidden');
          var bar = prog.querySelector('i'), txt = prog.querySelector('p');
          var total = g.file.size, enc = encSel.value;
          try {
            var res = await importBatches({
              name: name, mode: 'book', isCancelled: function () { return cancel; },
              batches: async function* () {
                var buf = [];
                for await (var p of P.readParagraphs(g.file, enc)) {
                  buf.push({ content: p });
                  if (buf.length >= 2000) { yield buf; buf = []; }
                }
                if (buf.length) yield buf;
              },
              convert: function (r) { return { title: '', author: '', dynasty: '', book: name, content: r.content }; },
              onProgress: function (n) { bar.style.width = '50%'; txt.textContent = '已处理 ' + n + ' 段（文件 ' + Math.round(total / 1048576 * 10) / 10 + ' MB）'; }
            });
            bar.style.width = '100%';
            if (res.cancelled) UI.toast('已取消');
            else { UI.toast('已导入 ' + res.count + ' 段', 3500); hooks.onDone(res.id); }
          } catch (e) { UI.toast('导入失败：' + (e.message || e), 5000); }
          UI.closeSheet();
        };
      }, { hideOk: true, onClose: function () { cancel = true; resolve(); } });
    });
  }

  root.PSImport = { init: init, start: start, ext: ext };
})(window);
