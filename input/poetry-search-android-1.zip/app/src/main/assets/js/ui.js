/* ui.js — 界面小工具：提示、底部抽屉、确认框、和安卓返回键配合的"层"管理 */
(function (root) {
  'use strict';
  var $ = function (id) { return document.getElementById(id); };

  // ---- 层栈：打开层时 pushState，安卓返回键 → popstate → 关掉最上面一层
  var stack = [];
  function pushOverlay(closeFn) {
    stack.push(closeFn);
    history.pushState({ ps: stack.length }, '');
  }
  window.addEventListener('popstate', function () {
    var c = stack.pop();
    if (c) c();
  });
  function closeTop() { if (stack.length) history.back(); }

  // ---- 提示
  var toastTimer = null;
  function toast(msg, ms) {
    var t = $('toast');
    t.textContent = msg; t.classList.add('on');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { t.classList.remove('on'); }, ms || 2400);
  }

  // ---- 底部抽屉
  var sheetDone = null;
  function openSheet(title, build, opts) {
    opts = opts || {};
    $('sheetTitle').textContent = title;
    var body = $('sheetBody');
    body.innerHTML = '';
    build(body);
    $('sheetOk').textContent = opts.okLabel || '完成';
    $('sheetOk').style.display = opts.hideOk ? 'none' : '';
    sheetDone = opts.onClose || null;
    $('sheet').classList.remove('hidden');
    pushOverlay(function () {
      $('sheet').classList.add('hidden');
      var f = sheetDone; sheetDone = null;
      if (f) f();
    });
  }
  function closeSheet() { if (!$('sheet').classList.contains('hidden')) closeTop(); }

  // ---- 确认框（WebView 里 confirm() 不可靠，自己做）
  function confirmBox(message, okLabel) {
    return new Promise(function (resolve) {
      var answered = false;
      openSheet('请确认', function (b) {
        var p = document.createElement('p');
        p.className = 'confirm-msg'; p.textContent = message;
        b.appendChild(p);
        var row = document.createElement('div'); row.className = 'btn-row';
        var no = document.createElement('button'); no.className = 'btn'; no.textContent = '取消';
        var yes = document.createElement('button'); yes.className = 'btn danger'; yes.textContent = okLabel || '确定';
        no.onclick = function () { closeSheet(); };
        yes.onclick = function () { answered = true; closeSheet(); };
        row.appendChild(no); row.appendChild(yes); b.appendChild(row);
      }, { hideOk: true, onClose: function () { resolve(answered); } });
    });
  }

  function el(tag, cls, html) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (html != null) e.innerHTML = html;
    return e;
  }

  document.addEventListener('DOMContentLoaded', function () {
    $('sheetOk').addEventListener('click', closeSheet);
    document.querySelector('#sheet .sheet-mask').addEventListener('click', closeSheet);
  });

  root.PSUI = { $: $, el: el, toast: toast, openSheet: openSheet, closeSheet: closeSheet, confirmBox: confirmBox, pushOverlay: pushOverlay, closeTop: closeTop };
})(window);
