/* search.js — 搜索调度：把选中的数据库拆成任务并发执行，逐条匹配、去重、限量 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory(root);
  else root.PSSearch = factory(root);
})(typeof self !== 'undefined' ? self : this, function (root) {
  'use strict';

  var Core = root.PSCore || (typeof require !== 'undefined' ? require('./core.js') : null);
  var Sources = root.PSSources || (typeof require !== 'undefined' ? require('./sources.js') : null);

  function Semaphore(n) { this.n = n; this.q = []; }
  Semaphore.prototype.acquire = function () {
    var self = this;
    if (self.n > 0) { self.n--; return Promise.resolve(); }
    return new Promise(function (res) { self.q.push(res); });
  };
  Semaphore.prototype.release = function () {
    if (this.q.length) this.q.shift()(); else this.n++;
  };

  /* opts: {
   *   query, scope('all'|'content'|'title'|'author'),
   *   filters:{dynasties:Set, books:Set}, defs:[来源定义],
   *   convert:boolean(繁简通搜), cap:number,
   *   signal:AbortSignal, onHit(item), onProgress({done,total,hits,fails,label}), onNote(msg)
   * }
   * 返回 {hits, fails, capped, notes, variants}
   */
  async function run(opts) {
    var q = Core.parseQuery(opts.query);
    if (!q.tokens.length) throw new Error('请输入关键字');
    var cap = opts.cap || 400, signal = opts.signal || { aborted: false };
    var conv = opts.convert ? await Sources.convertFns() : [];
    var variants = Core.makeVariants(q.tokens, conv);

    function quick(s) {
      for (var i = 0; i < variants.length; i++) {
        var ok = false, vs = variants[i];
        for (var j = 0; j < vs.length; j++) if (s.indexOf(vs[j]) >= 0) { ok = true; break; }
        if (!ok) return false;
      }
      return true;
    }
    var notes = [];
    function note(m) { if (notes.indexOf(m) < 0) { notes.push(m); if (opts.onNote) opts.onNote(m); } }

    var env = { tokens: q.tokens, scope: opts.scope || 'all', onNote: note };
    var jobs = [];
    for (var i = 0; i < opts.defs.length; i++) {
      try { jobs = jobs.concat(await Sources.plan(opts.defs[i], env)); }
      catch (e) { note(opts.defs[i].label + '：' + (e.message || e)); }
    }
    var total = jobs.length, done = 0, hits = 0, fails = 0, capped = false;
    var seen = new Map(), heavy = new Semaphore(1);
    var ctx = { quick: quick, quickFile: quick, signal: signal };

    function progress(label) {
      if (opts.onProgress) opts.onProgress({ done: done, total: total, hits: hits, fails: fails, label: label || '' });
    }
    progress('');

    async function worker() {
      while (jobs.length && !capped && !signal.aborted) {
        var job = jobs.shift(), poems = [];
        try {
          if (job.heavy) await heavy.acquire();
          try { poems = await job.run(ctx); } finally { if (job.heavy) heavy.release(); }
        } catch (e) {
          if (signal.aborted) return;
          fails++;
          note(job.label + ' 失败：' + (e.message || e));
          poems = [];
        }
        for (var k = 0; k < poems.length && !capped; k++) {
          var p = poems[k];
          if (!Core.passFilters(p, opts.filters)) continue;
          var ms = Core.matchPoem(p, variants, env.scope, q.multi);
          for (var m = 0; m < ms.length; m++) {
            var key = Core.dedupKey(p, ms[m]);
            var ex = seen.get(key);
            if (ex) { ex.srcs.add(p.src); if (opts.onMerge) opts.onMerge(ex); continue; }
            var item = { poem: p, hit: ms[m], srcs: new Set([p.src]) };
            seen.set(key, item);
            hits++;
            if (opts.onHit) opts.onHit(item);
            if (hits >= cap) { capped = true; break; }
          }
        }
        done++;
        progress(job.label);
      }
    }
    var n = Math.min(6, Math.max(1, jobs.length));
    await Promise.all(Array.from({ length: n }, worker));
    return { hits: hits, fails: fails, capped: capped, notes: notes, variants: variants, multi: q.multi, aborted: !!signal.aborted };
  }

  return { run: run, Semaphore: Semaphore };
});
