/* poem.js — 诗页：水墨背景（在线图库自动匹配 / 本地图）、换图、AI 提示词、从相册选图 */
(function (root) {
  'use strict';
  var UI = root.PSUI, C = root.PSCore, I = root.PSImages, St = root.PSStore;
  var $ = UI.$, el = UI.el;

  var hooks = { settings: function () { return {}; } };
  var cur = null, curUrl = null, token = 0;

  function init(h) { hooks = h; }

  function revoke() { if (curUrl) { try { URL.revokeObjectURL(curUrl); } catch (e) { /* ignore */ } curUrl = null; } }

  function setBg(url, credit, revokeAfter) {
    var bg = $('pvBg');
    bg.classList.remove('in');
    void bg.offsetWidth;
    bg.style.backgroundImage = 'url("' + url + '")';
    bg.classList.add('in');
    revoke();
    if (revokeAfter) curUrl = url;
    $('pvCredit').textContent = credit || '';
  }

  async function applyBackground() {
    var my = ++token, poem = cur.poem;
    $('pvBg').classList.add('loading');
    var res;
    try { res = await I.resolveBackground(St, poem, hooks.settings(), 3500); }
    catch (e) { res = { kind: 'local', url: I.localUrl(I.localIndexFor(I.poemKey(poem))), credit: '' }; }
    if (my !== token || !cur) return;
    // 之前选定的在线图如果现在打不开，就退回本地图
    if (res.kind === 'url' && res.fallback) {
      var ok = await I.loadImage(res.url, 4000);
      if (my !== token || !cur) return;
      if (!ok) res = { kind: 'local', url: res.fallback, credit: '（在线图暂时打不开，已用本地图）' };
    }
    $('pvBg').classList.remove('loading');
    setBg(res.url, res.credit, !!res.revoke);
  }

  function renderText(poem, hits) {
    $('pvTitle').textContent = poem.title || poem.book || '';
    var meta = [poem.author, poem.dynasty, poem.title && poem.book ? poem.book : ''].filter(Boolean).join(' · ');
    $('pvMeta').textContent = meta;
    var box = $('pvText');
    box.innerHTML = '';
    C.poemLines(poem.content).forEach(function (line) {
      box.appendChild(el('p', '', C.highlight(line, hits)));
    });
  }

  function open(poem, hits) {
    cur = { poem: poem, hits: hits || [] };
    renderText(poem, cur.hits);
    $('pvPanel').scrollTop = 0;
    $('poemView').classList.remove('hidden');
    UI.pushOverlay(close);
    applyBackground();
  }
  function close() {
    $('poemView').classList.add('hidden');
    cur = null; token++;
    revoke();
    $('pvBg').style.backgroundImage = '';
  }

  function copyText(text) {
    function legacy() {
      var ta = document.createElement('textarea');
      ta.value = text; ta.style.position = 'fixed'; ta.style.opacity = '0';
      document.body.appendChild(ta); ta.select();
      try { document.execCommand('copy'); UI.toast('已复制'); } catch (e) { UI.toast('复制失败，请长按文字手动复制'); }
      document.body.removeChild(ta);
    }
    if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(text).then(function () { UI.toast('已复制'); }, legacy);
    else legacy();
  }

  // ---------------------------------------------------------------- 换图
  function cell(src, label, onClick) {
    var b = el('button', 'cell');
    b.type = 'button';
    var im = el('img'); im.loading = 'lazy'; im.alt = ''; im.src = src;
    b.appendChild(im);
    if (label) b.appendChild(el('span', '', label));
    b.onclick = onClick;
    return b;
  }

  async function pickLocal(n) {
    await St.setMap(I.poemKey(cur.poem), { kind: 'local', n: n });
    UI.closeSheet(); applyBackground();
  }
  async function pickSaved(id) {
    await St.setMap(I.poemKey(cur.poem), { kind: 'blob', id: id });
    UI.closeSheet(); applyBackground();
  }
  async function pickOnline(c) {
    var poem = cur.poem;
    UI.toast('正在下载到手机…', 6000);
    try {
      await I.saveCandidate(St, poem, c);
      UI.toast('已保存，以后可离线使用');
    } catch (e) {
      await St.setMap(I.poemKey(poem), { kind: 'url', url: c.url, credit: c.credit, link: c.link || '' });
      UI.toast('下载失败，先在线显示');
    }
    UI.closeSheet(); applyBackground();
  }

  function openSwap() {
    if (!cur) return;
    var poem = cur.poem;
    UI.openSheet('换一张背景', function (body) {
      body.appendChild(el('h4', '', '在线图库'));
      var onNote = el('p', 'hint', '正在从已开启的图库取图…');
      var onGrid = el('div', 'grid');
      body.appendChild(onNote); body.appendChild(onGrid);
      body.appendChild(el('h4', '', '我保存过的'));
      var savedHint = el('p', 'hint', ''); body.appendChild(savedHint);
      var savedGrid = el('div', 'grid'); body.appendChild(savedGrid);
      body.appendChild(el('h4', '', '内置水墨图'));
      var localGrid = el('div', 'grid'); body.appendChild(localGrid);
      for (var n = 1; n <= I.LOCAL_COUNT; n++) (function (n) { localGrid.appendChild(cell(I.localUrl(n), '', function () { pickLocal(n); })); })(n);

      St.listImages().then(function (list) {
        if (!list.length) { savedHint.textContent = '还没有。选在线图或从相册选图后会存在这里。'; return; }
        list.sort(function (a, b) { return (b.added || 0) - (a.added || 0); }).forEach(function (rec) {
          var u = URL.createObjectURL(rec.blob);
          savedGrid.appendChild(cell(u, '', function () { pickSaved(rec.id); }));
        });
      });

      var s = hooks.settings();
      var any = Object.keys(s.galleries || {}).some(function (k) { return s.galleries[k]; });
      if (!any) { onNote.textContent = '在线图库都关着（设置 → 图库）。'; return; }
      I.candidates(poem, s.galleries, null).then(function (r) {
        if (!r.list.length) { onNote.textContent = '在线图库这次没取到图（网络或图库打不开）。可以用下面的本地图。'; return; }
        onNote.textContent = '按诗里的意象（' + r.terms.join('、') + '）匹配。点一张会保存到手机。';
        r.list.forEach(function (c) { onGrid.appendChild(cell(c.thumb, '', function () { pickOnline(c); })); });
      }).catch(function () { onNote.textContent = '在线图库这次没取到图。'; });
    });
  }

  // ---------------------------------------------------------------- AI 生图（半自动）
  function openAI() {
    if (!cur) return;
    var pr = I.aiPrompt(cur.poem), sites = hooks.settings().aiSites || [];
    UI.openSheet('AI 生成背景', function (body) {
      body.appendChild(el('p', 'hint', '做法：复制提示词 → 在你选的 AI 网站生成一张图 → 保存到手机相册 → 回到这里点“从相册选图”。'));
      [['中文提示词', pr.zh], ['English prompt', pr.en]].forEach(function (x) {
        body.appendChild(el('h4', '', x[0]));
        var ta = el('textarea', 'ta'); ta.readOnly = true; ta.value = x[1]; ta.rows = 4;
        body.appendChild(ta);
        var b = el('button', 'btn', '复制'); b.type = 'button'; b.onclick = function () { copyText(x[1]); };
        body.appendChild(b);
      });
      body.appendChild(el('h4', '', 'AI 网站（用手机浏览器打开）'));
      if (!sites.length) body.appendChild(el('p', 'hint', '还没添加。到 设置 → AI 网站 里加上你常用的。'));
      sites.forEach(function (s) {
        var a = el('a', 'btn', '打开 ' + C.esc(s.name));
        a.href = 'psext://open?u=' + encodeURIComponent(s.url);
        body.appendChild(a);
      });
      var pick = el('button', 'btn primary', '从相册选图'); pick.type = 'button';
      pick.onclick = function () { $('imgIn').value = ''; $('imgIn').click(); };
      body.appendChild(el('div', 'sp')); body.appendChild(pick);
    });
  }

  async function onImagePicked(file) {
    if (!file || !cur) return;
    if (!/^image\//.test(file.type || '') && !/\.(jpe?g|png|webp|gif)$/i.test(file.name || '')) { UI.toast('这不是图片文件'); return; }
    var id = 'img-up-' + Date.now().toString(36);
    await St.putImage({ id: id, blob: file, credit: '我的图片', source: 'user', added: Date.now() });
    await St.setMap(I.poemKey(cur.poem), { kind: 'blob', id: id });
    UI.closeSheet(); applyBackground(); UI.toast('已设为这首诗的背景');
  }

  document.addEventListener('DOMContentLoaded', function () {
    $('pvBack').addEventListener('click', function () { UI.closeTop(); });
    $('pvSwap').addEventListener('click', openSwap);
    $('pvAI').addEventListener('click', openAI);
    $('imgIn').addEventListener('change', function (e) { onImagePicked(e.target.files && e.target.files[0]); });
  });

  root.PSPoem = { init: init, open: open };
})(window);
