/* core.js — 搜索核心：句子切分、同句多词匹配、14字窗口、相邻句、高亮、筛选、去重
 * 浏览器里挂在 window.PSCore，Node 里用 require 引入（方便测试）。 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.PSCore = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  var LIMIT = 14; // 一句话最多显示的字数
  // 任何标点（中英文）、符号、空白都算句子的结尾
  var SEP = /[\p{P}\p{S}\s]+/u;

  var DYNASTIES = ['先秦', '汉', '魏晋', '南北朝', '隋', '唐', '五代', '宋', '金', '元', '明', '清', '近现代', '当代'];

  function esc(s) {
    return String(s).replace(/[&<>"]/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c];
    });
  }
  function escRe(s) { return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }
  function cpLen(s) { var n = 0; for (var _ of s) n++; return n; }

  function splitSentences(text) {
    return String(text == null ? '' : text).split(SEP).filter(Boolean);
  }

  // 把输入拆成词：空格（任意多个、含全角空格）分隔
  function parseQuery(q) {
    var tokens = String(q || '').replace(/\s+/g, ' ').trim().split(' ').filter(Boolean);
    return { tokens: tokens, multi: tokens.length > 1 };
  }

  // variants: 每个词对应一组写法（原样、繁体、简体），命中任一写法即算命中
  function makeVariants(tokens, convert) {
    return tokens.map(function (t) {
      var set = [t];
      if (convert) {
        convert.forEach(function (fn) {
          try { var v = fn(t); if (v && set.indexOf(v) < 0) set.push(v); } catch (e) { /* ignore */ }
        });
      }
      return set;
    });
  }

  // 在 str 里找每个词的命中写法；有一个词不在就返回 null
  function matchAll(str, variants) {
    var hit = [];
    for (var i = 0; i < variants.length; i++) {
      var vs = variants[i], m = null;
      for (var j = 0; j < vs.length; j++) {
        if (vs[j] && str.indexOf(vs[j]) >= 0) { m = vs[j]; break; }
      }
      if (m === null) return null;
      hit.push(m);
    }
    return hit;
  }

  // 超过 limit 字时，取一个含全部命中词的 limit 字窗口；放不下返回 null
  function fitWindow(sentence, hits, limit) {
    var chars = Array.from(sentence), L = chars.length;
    var lim = limit;
    hits.forEach(function (h) { var n = cpLen(h); if (n > lim) lim = n; });
    if (L <= lim) return { text: sentence, start: 0, end: L, len: L };
    var starts = [];
    for (var st = 0; st + lim <= L; st++) {
      var w = chars.slice(st, st + lim).join('');
      var ok = true;
      for (var k = 0; k < hits.length; k++) if (w.indexOf(hits[k]) < 0) { ok = false; break; }
      if (ok) starts.push(st);
    }
    if (!starts.length) return null;
    var s0 = starts[Math.floor(starts.length / 2)];
    return { text: chars.slice(s0, s0 + lim).join(''), start: s0, end: s0 + lim, len: L };
  }

  function clip(s, lim) {
    var a = Array.from(s);
    return a.length > lim ? a.slice(0, lim).join('') + '…' : s;
  }

  // 相邻句：优先下一句，最后一句就取上一句
  function neighborOf(sents, idx, lim) {
    var j = idx + 1 < sents.length ? idx + 1 : idx - 1;
    return j >= 0 ? clip(sents[j], lim) : '';
  }

  // 全部词是否都出现在同一句里；返回例句列表
  function sentenceHits(content, variants, limit) {
    limit = limit || LIMIT;
    var text = String(content == null ? '' : content);
    // 快速预筛：全文里连每个词都凑不齐就不用切句了
    if (!matchAll(text, variants)) return [];
    var sents = splitSentences(text), out = [];
    for (var i = 0; i < sents.length; i++) {
      var hits = matchAll(sents[i], variants);
      if (!hits) continue;
      var w = fitWindow(sents[i], hits, limit);
      if (!w) continue;
      out.push({
        idx: i,
        text: w.text,
        pre: w.start > 0,
        post: w.end < w.len,
        hits: hits,
        neighbor: neighborOf(sents, i, limit)
      });
    }
    return out;
  }

  function highlight(text, hits) {
    var hs = Array.from(new Set((hits || []).filter(Boolean))).sort(function (a, b) { return b.length - a.length; });
    if (!hs.length) return esc(text);
    var re = new RegExp('(' + hs.map(escRe).join('|') + ')', 'g');
    return String(text).split(re).map(function (part, i) {
      return i % 2 ? '<mark>' + esc(part) + '</mark>' : esc(part);
    }).join('');
  }

  // 筛选：朝代（可多选）、书籍/文集（可多选）
  function passFilters(p, f) {
    if (!f) return true;
    if (f.dynasties && f.dynasties.size) {
      var d = p.dynasty || '', ok = false;
      f.dynasties.forEach(function (x) { if (d.indexOf(x) >= 0) ok = true; });
      if (!ok) return false;
    }
    if (f.books && f.books.size) {
      if (!f.books.has(p.book || '')) return false;
    }
    return true;
  }

  // 对一首作品做匹配，返回命中项数组：{kind:'sentence'|'poem', ...}
  // scope: all | content | title | author
  function matchPoem(p, variants, scope, multi) {
    var out = [], content = p.content || '', title = p.title || '', author = p.author || '';
    if (scope === 'title' || scope === 'author') {
      var f = scope === 'title' ? title : author;
      var h = matchAll(f, variants);
      if (h) out.push({ kind: 'poem', hits: h, field: scope });
      return out;
    }
    if (scope === 'content') {
      if (multi) {
        sentenceHits(content, variants).forEach(function (s) { s.kind = 'sentence'; out.push(s); });
      } else {
        var hc = matchAll(content, variants);
        if (hc) out.push({ kind: 'poem', hits: hc, field: 'content' });
      }
      return out;
    }
    // all
    if (multi) {
      sentenceHits(content, variants).forEach(function (s) { s.kind = 'sentence'; out.push(s); });
      var ht = matchAll(title, variants);
      if (ht) out.push({ kind: 'poem', hits: ht, field: 'title' });
      var ha = matchAll(author, variants);
      if (ha) out.push({ kind: 'poem', hits: ha, field: 'author' });
    } else {
      var all = title + '\n' + author + '\n' + content;
      var h2 = matchAll(all, variants);
      if (h2) out.push({ kind: 'poem', hits: h2, field: 'all' });
    }
    return out;
  }

  // 去重键：不同数据库里的同一句/同一首合并
  function dedupKey(p, hit) {
    if (hit.kind === 'sentence') return 's|' + (p.author || '') + '|' + hit.text;
    return 'p|' + (p.author || '') + '|' + (p.title || '') + '|' + Array.from(p.content || '').slice(0, 16).join('');
  }

  // 诗页显示用：把正文拆成行（有换行就按换行，否则在句号/问号/叹号后断行）
  function poemLines(content) {
    var t = String(content || '').replace(/\r\n?/g, '\n').trim();
    if (t.indexOf('\n') >= 0) return t.split('\n').map(function (x) { return x.trim(); }).filter(Boolean);
    var parts = t.split(/(?<=[。！？!?；;])/u).map(function (x) { return x.trim(); }).filter(Boolean);
    return parts.length ? parts : [t];
  }

  return {
    LIMIT: LIMIT, DYNASTIES: DYNASTIES, esc: esc, escRe: escRe,
    splitSentences: splitSentences, parseQuery: parseQuery, makeVariants: makeVariants,
    matchAll: matchAll, fitWindow: fitWindow, clip: clip, neighborOf: neighborOf,
    sentenceHits: sentenceHits, highlight: highlight, passFilters: passFilters,
    matchPoem: matchPoem, dedupKey: dedupKey, poemLines: poemLines
  };
});
