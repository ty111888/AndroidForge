/* sources.js — 数据来源：原始库(chinese-poetry)、Werneror/Poetry(CSV)、诗泉(在线接口)、导入的数据库
 * 每个来源通过 plan() 拆成若干"任务"（一个文件/一页/一块），由 search.js 并发执行。 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory(root);
  else root.PSSources = factory(root);
})(typeof self !== 'undefined' ? self : this, function (root) {
  'use strict';

  var CDN = 'https://cdn.jsdelivr.net/gh/chinese-poetry/chinese-poetry@master/';
  var WCDN = 'https://cdn.jsdelivr.net/gh/Werneror/Poetry@master/';
  var SQ_BASE = 'https://poetry.palemoky.com';
  var OPENCC_URL = 'https://cdn.jsdelivr.net/npm/opencc-js@1.0.5/dist/umd/full.js';

  // 原始库的目录/文件名规则（和第一版一致）
  var ORIG = {
    tang: { dirs: ['全唐诗', 'json'], f: 'poet.tang.', n: 58 },
    ci: { dirs: ['宋词', 'ci'], f: 'ci.song.', n: 22 },
    song: { dirs: ['全唐诗', 'json'], f: 'poet.song.', n: 255 }
  };

  var BUILTIN = [
    { id: 'orig-tang', group: '原始库（chinese-poetry）', label: '唐诗', kind: 'orig', set: 'tang', dynasty: '唐', book: '全唐诗', defaultOn: true, note: '约5.7万首，分58个文件' },
    { id: 'orig-ci', group: '原始库（chinese-poetry）', label: '宋词', kind: 'orig', set: 'ci', dynasty: '宋', book: '宋词', defaultOn: true, note: '约2.1万首，分22个文件' },
    { id: 'orig-song', group: '原始库（chinese-poetry）', label: '宋诗', kind: 'orig', set: 'song', dynasty: '宋', book: '全宋诗', defaultOn: false, note: '约25万首，分255个文件，较慢' },
    { id: 'wn-yuan', group: 'Werneror/Poetry', label: '元（含元末明初）', kind: 'csv', files: ['元.csv', '元末明初.csv'], defaultOn: false, note: '约5.3万首，首次下载约13MB（估算）' },
    { id: 'wn-ming', group: 'Werneror/Poetry', label: '明（含明末清初）', kind: 'csv', files: ['明_1.csv', '明_2.csv', '明_3.csv', '明_4.csv', '明末清初.csv'], defaultOn: false, note: '约25万首，首次下载约63MB（估算）' },
    { id: 'wn-qing', group: 'Werneror/Poetry', label: '清（含清末）', kind: 'csv', files: ['清_1.csv', '清_2.csv', '清末民国初.csv', '清末近现代初.csv'], defaultOn: false, note: '约12万首，首次下载约29MB（估算）' },
    { id: 'shiquan', group: '诗泉（在线接口）', label: '诗泉', kind: 'api', defaultOn: false, note: '服务器上搜，不下载；只检查返回的前若干条' }
  ];

  // 只把真正的 AbortSignal 交给 fetch（浏览器对别的对象会直接报错）
  function realSignal(s) { return (typeof AbortSignal !== 'undefined' && s instanceof AbortSignal) ? s : undefined; }
  function parsers() { return root.PSParsers || (typeof require !== 'undefined' ? require('./parsers.js') : null); }

  // ---------------------------------------------------------------- 取文件（带本地缓存）
  async function cacheOpen(name) { try { return await caches.open(name); } catch (e) { return null; } }
  async function fetchCached(url, cacheName, signal) {
    var c = await cacheOpen(cacheName);
    if (c) { var hit = await c.match(url); if (hit) return hit; }
    var r = await fetch(url, { signal: realSignal(signal) });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    if (c) { try { await c.put(url, r.clone()); } catch (e) { /* 缓存失败不影响搜索 */ } }
    return r;
  }

  var dirCache = {};
  async function pickDir(setKey) {
    var s = ORIG[setKey];
    if (dirCache[setKey]) return dirCache[setKey];
    for (var i = 0; i < s.dirs.length; i++) {
      try {
        await fetchCached(CDN + encodeURIComponent(s.dirs[i]) + '/' + s.f + '0.json', 'poetry-v1');
        dirCache[setKey] = s.dirs[i];
        return s.dirs[i];
      } catch (e) { /* 试下一个目录 */ }
    }
    throw new Error('找不到 ' + setKey + ' 数据目录，请检查网络');
  }

  // ---------------------------------------------------------------- 诗泉
  function pickList(j, depth) {
    depth = depth || 0;
    if (Array.isArray(j)) return j;
    if (!j || typeof j !== 'object' || depth > 2) return null;
    var keys = ['data', 'poems', 'results', 'items', 'list', 'records'];
    for (var i = 0; i < keys.length; i++) {
      var v = j[keys[i]];
      if (Array.isArray(v)) return v;
    }
    for (var k = 0; k < keys.length; k++) {
      var v2 = j[keys[k]];
      if (v2 && typeof v2 === 'object') { var r = pickList(v2, depth + 1); if (r) return r; }
    }
    return null;
  }
  function nm(v) { if (v && typeof v === 'object') return v.name || v.title || ''; return v || ''; }
  function normApiPoem(x) {
    var content = x.content != null ? x.content : (x.paragraphs != null ? x.paragraphs : (x.text != null ? x.text : ''));
    if (Array.isArray(content)) content = content.join('\n');
    return {
      title: String(x.title || x.rhythmic || x.name || ''),
      author: String(nm(x.author)),
      dynasty: String(nm(x.dynasty)),
      book: '诗泉',
      content: String(content),
      src: 'shiquan'
    };
  }
  var SQ_PAGE = 100, SQ_MAX_PAGES = 5;
  function sqUrls(q, type, page) {
    var qs = 'q=' + encodeURIComponent(q) + '&page=' + page + '&page_size=' + SQ_PAGE;
    return [
      SQ_BASE + '/api/v1/poems/search?' + qs + '&type=' + type,
      SQ_BASE + '/api/search?' + qs + '&type=' + type
    ];
  }
  var sqEndpoint = -1; // 记住哪个地址可用
  async function sqFetch(q, type, page, signal) {
    var urls = sqUrls(q, type, page), last = null;
    var order = sqEndpoint >= 0 ? [sqEndpoint] : [0, 1];
    for (var i = 0; i < order.length; i++) {
      var r;
      try { r = await fetch(urls[order[i]], { signal: realSignal(signal) }); } catch (e) { last = e; continue; }
      if (r.status === 429) throw new Error('诗泉限流（429），请过一会儿再试');
      if (!r.ok) { last = new Error('HTTP ' + r.status); continue; }
      var text = await r.text(), j;
      try { j = JSON.parse(text); } catch (e) { last = new Error('诗泉返回的不是 JSON'); continue; }
      sqEndpoint = order[i];
      return { json: j, raw: text, url: urls[order[i]] };
    }
    throw last || new Error('诗泉无法访问');
  }
  async function shiquanSearch(tokens, scope, signal, onNote) {
    var q = tokens.slice().sort(function (a, b) { return b.length - a.length; })[0];
    var type = scope === 'title' ? 'title' : scope === 'author' ? 'author' : scope === 'content' ? 'content' : 'all';
    var out = [];
    for (var page = 1; page <= SQ_MAX_PAGES; page++) {
      if (signal && signal.aborted) break;
      var res = await sqFetch(q, type, page, signal);
      var list = pickList(res.json);
      if (!list) throw new Error('诗泉返回的格式我还没认出来（到 设置 → 测试诗泉 里看原始内容）');
      list.forEach(function (x) { out.push(normApiPoem(x)); });
      if (list.length < SQ_PAGE) break;
    }
    if (onNote) onNote('诗泉：用“' + q + '”向服务器取回 ' + out.length + ' 条（最多检查前 ' + (SQ_PAGE * SQ_MAX_PAGES) + ' 条）');
    return out;
  }
  async function testShiquan(q) {
    q = q || '明月光';
    var t0 = Date.now();
    try {
      var res = await sqFetch(q, 'all', 1);
      var list = pickList(res.json);
      return {
        ok: !!list, ms: Date.now() - t0, url: res.url, count: list ? list.length : 0,
        first: list && list[0] ? normApiPoem(list[0]) : null,
        raw: res.raw.slice(0, 600)
      };
    } catch (e) { return { ok: false, ms: Date.now() - t0, error: String(e.message || e) }; }
  }

  // ---------------------------------------------------------------- OpenCC（繁简通搜，按需从 jsDelivr 加载）
  var opencc;
  async function ensureOpenCC() {
    if (opencc !== undefined) return opencc;
    opencc = null;
    if (typeof document === 'undefined') return opencc;
    try {
      await new Promise(function (res, rej) {
        var s = document.createElement('script');
        s.src = OPENCC_URL; s.onload = res; s.onerror = rej;
        document.head.appendChild(s);
        setTimeout(function () { rej(new Error('timeout')); }, 8000);
      });
      if (root.OpenCC) opencc = {
        toT: root.OpenCC.Converter({ from: 'cn', to: 't' }),
        toS: root.OpenCC.Converter({ from: 't', to: 'cn' })
      };
    } catch (e) { opencc = null; }
    return opencc;
  }
  async function convertFns() { var o = await ensureOpenCC(); return o ? [o.toT, o.toS] : []; }

  // ---------------------------------------------------------------- 任务拆分
  function csvPoemsFromText(text, def, ctx) {
    var P = parsers();
    var out = [], idx = { t: 0, d: 1, a: 2, c: 3 }, first = true;
    for (var row of P.csvRows(text)) {
      if (first) {
        first = false;
        var h0 = String(row[0] || '').trim();
        if (h0 === '题目' || h0 === '題目' || h0.toLowerCase() === 'title') {
          row.forEach(function (name, i) {
            var n = String(name).trim().toLowerCase();
            if (n === '题目' || n === '題目' || n === 'title') idx.t = i;
            else if (n === '朝代' || n === 'dynasty') idx.d = i;
            else if (n === '作者' || n === 'author') idx.a = i;
            else if (n === '内容' || n === '內容' || n === 'content') idx.c = i;
          });
          continue;
        }
      }
      var t = row[idx.t] || '', a = row[idx.a] || '', c = row[idx.c] || '';
      if (!ctx.quick(t + '\n' + a + '\n' + c)) continue;
      out.push({ title: t, author: a, dynasty: row[idx.d] || '', book: '', content: c, src: def.id });
    }
    return out;
  }

  async function plan(def, env) {
    var jobs = [];
    if (def.kind === 'orig') {
      var s = ORIG[def.set];
      var dir = await pickDir(def.set);
      for (var i = 0; i < s.n; i++) {
        (function (i) {
          var u = CDN + encodeURIComponent(dir) + '/' + s.f + i * 1000 + '.json';
          jobs.push({
            label: def.label + ' ' + (i + 1) + '/' + s.n,
            run: async function (ctx) {
              var arr = await (await fetchCached(u, 'poetry-v1', ctx.signal)).json();
              var out = [];
              for (var k = 0; k < arr.length; k++) {
                var p = arr[k], t = p.title || p.rhythmic || '', a = p.author || '', c = (p.paragraphs || []).join('\n');
                if (!ctx.quick(t + '\n' + a + '\n' + c)) continue;
                out.push({ title: t, author: a, dynasty: def.dynasty, book: def.book, content: c, src: def.id });
              }
              return out;
            }
          });
        })(i);
      }
    } else if (def.kind === 'csv') {
      def.files.forEach(function (f) {
        jobs.push({
          label: def.label + ' ' + f, heavy: true,
          run: async function (ctx) {
            var r = await fetchCached(WCDN + encodeURIComponent(f), 'poetry-csv-v1', ctx.signal);
            var buf = new Uint8Array(await r.arrayBuffer());
            var text = parsers().decodeBest(buf).text;
            if (!ctx.quickFile(text)) return []; // 整个文件里都凑不齐关键词，直接跳过解析
            return csvPoemsFromText(text, def, ctx);
          }
        });
      });
    } else if (def.kind === 'api') {
      jobs.push({
        label: '诗泉（在线）',
        run: async function (ctx) {
          var poems = await shiquanSearch(env.tokens, env.scope, ctx.signal, env.onNote);
          return poems; // 服务器已按词筛过，仍交给统一匹配逻辑做同句判断
        }
      });
    } else if (def.kind === 'dataset') {
      for (var c = 0; c < def.chunks; c++) {
        (function (c) {
          jobs.push({
            label: def.label + ' 块' + (c + 1) + '/' + def.chunks,
            run: async function (ctx) {
              var recs = await root.PSStore.getChunk(def.dsId, c), out = [];
              for (var k = 0; k < recs.length; k++) {
                var p = recs[k];
                if (!ctx.quick((p.title || '') + '\n' + (p.author || '') + '\n' + (p.content || ''))) continue;
                out.push({ title: p.title || '', author: p.author || '', dynasty: p.dynasty || '', book: p.book || def.label, content: p.content || '', src: def.id });
              }
              return out;
            }
          });
        })(c);
      }
    }
    return jobs;
  }

  function datasetDefs(metas) {
    return metas.map(function (m) {
      return { id: 'ds-' + m.id, dsId: m.id, kind: 'dataset', group: '导入的数据库', label: m.name, book: m.book || m.name, chunks: m.chunks || 0, count: m.count || 0, mode: m.mode, defaultOn: false, note: (m.count || 0) + ' 条' };
    });
  }

  return {
    BUILTIN: BUILTIN, plan: plan, datasetDefs: datasetDefs, convertFns: convertFns, ensureOpenCC: ensureOpenCC,
    testShiquan: testShiquan, shiquanSearch: shiquanSearch, pickList: pickList, normApiPoem: normApiPoem,
    csvPoemsFromText: csvPoemsFromText, fetchCached: fetchCached, URLS: { CDN: CDN, WCDN: WCDN, SQ_BASE: SQ_BASE }
  };
});
