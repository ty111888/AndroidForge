package com.example.poetry;

import android.app.Activity;
import android.content.ClipData;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.webkit.WebViewAssetLoader;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class MainActivity extends Activity {
    private static final int REQ_FILE = 1001;

    // 这些网站的接口/图片不一定允许网页跨域读取，所以由 App 代为请求，并补上跨域许可。
    private static final Set<String> PROXY_HOSTS = new HashSet<String>(Arrays.asList(
            "poetry.palemoky.com",
            "collectionapi.metmuseum.org", "images.metmuseum.org",
            "api.artic.edu", "www.artic.edu",
            "openaccess-api.clevelandart.org", "openaccess-cdn.clevelandart.org"));

    WebView w;
    private ValueCallback<Uri[]> filePathCallback;
    private String userAgent = "";

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this)).build();
        w = new WebView(this);
        setContentView(w);
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        userAgent = s.getUserAgentString();

        w.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                WebResourceResponse res = loader.shouldInterceptRequest(r.getUrl());
                if (res != null) return res;
                return proxy(r);
            }

            // psext://open?u=<网址> ：用手机自带浏览器打开（比如去 AI 网站生成图片后保存到相册）
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if ("psext".equals(u.getScheme())) {
                    String target = u.getQueryParameter("u");
                    if (target != null && (target.startsWith("https://") || target.startsWith("http://"))) {
                        try {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(target)));
                        } catch (Exception e) {
                            // 没有可用的浏览器就算了
                        }
                    }
                    return true;
                }
                return false; // 其他链接（比如“诗词搜索”里的网站）在 App 内打开
            }
        });

        // 让网页里的 <input type="file"> 能弹出系统的文件选择器（导入文件、选图用）
        w.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = cb;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                try {
                    startActivityForResult(Intent.createChooser(i, "选择文件"), REQ_FILE);
                } catch (Exception e) {
                    filePathCallback = null;
                    cb.onReceiveValue(null);
                    return false;
                }
                return true;
            }
        });

        w.loadUrl("https://appassets.androidplatform.net/assets/index.html");
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (req == REQ_FILE) {
            Uri[] results = null;
            if (res == RESULT_OK && data != null) {
                ClipData cd = data.getClipData();
                if (cd != null) {
                    results = new Uri[cd.getItemCount()];
                    for (int k = 0; k < results.length; k++) results[k] = cd.getItemAt(k).getUri();
                } else if (data.getData() != null) {
                    results = new Uri[]{data.getData()};
                }
            }
            if (filePathCallback != null) filePathCallback.onReceiveValue(results);
            filePathCallback = null;
            return;
        }
        super.onActivityResult(req, res, data);
    }

    // 代取白名单网站的内容；失败就返回 null，交给 WebView 自己去请求。
    private WebResourceResponse proxy(WebResourceRequest r) {
        try {
            Uri u = r.getUrl();
            String host = u.getHost();
            if (host == null || !PROXY_HOSTS.contains(host)) return null;
            if (!"GET".equalsIgnoreCase(r.getMethod())) return null;
            HttpURLConnection c = (HttpURLConnection) new URL(u.toString()).openConnection();
            c.setConnectTimeout(15000);
            c.setReadTimeout(30000);
            c.setRequestProperty("User-Agent", userAgent);
            c.setRequestProperty("Accept", "*/*");
            int code = c.getResponseCode();
            if (code < 200 || code > 599 || (code >= 300 && code < 400)) return null;
            InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
            if (in == null) in = new ByteArrayInputStream(new byte[0]);
            String mime = "application/octet-stream";
            String enc = null;
            String ct = c.getContentType();
            if (ct != null) {
                String[] parts = ct.split(";");
                mime = parts[0].trim();
                for (int k = 1; k < parts.length; k++) {
                    String p = parts[k].trim();
                    if (p.toLowerCase().startsWith("charset=")) enc = p.substring(8).trim();
                }
            }
            Map<String, String> h = new HashMap<String, String>();
            h.put("Access-Control-Allow-Origin", "*");
            String reason = c.getResponseMessage();
            if (reason == null || reason.length() == 0) reason = code < 400 ? "OK" : "Error";
            return new WebResourceResponse(mime, enc, code, reason, h, in);
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public void onBackPressed() {
        if (w.canGoBack()) w.goBack(); else super.onBackPressed();
    }
}
