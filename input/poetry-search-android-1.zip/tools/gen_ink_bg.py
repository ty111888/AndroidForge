#!/usr/bin/env python3
"""生成离线水墨风底图（程序绘制，无版权问题）。
用法: python3 tools/gen_ink_bg.py <输出目录> [张数]
画法：宣纸底色 + 多层远近山峦（越远越淡）+ 山间云雾 + 随机的月/日/孤舟/松/飞鸟 + 纸张纤维颗粒。"""
import sys, os
import numpy as np
from PIL import Image, ImageFilter, ImageDraw

W, H = 800, 1400
PAPERS = [(241, 233, 215), (233, 234, 226), (228, 216, 192), (238, 230, 222)]
SEAL = (176, 52, 42)


def fbm2d(w, h, rng, octaves=5, base=3):
    out = np.zeros((h, w), np.float32)
    amp, tot = 1.0, 0.0
    for o in range(octaves):
        gw = base * (2 ** o)
        gh = max(2, int(gw * h / w))
        g = rng.random((gh + 1, gw + 1)).astype(np.float32)
        im = Image.fromarray((g * 255).astype(np.uint8)).resize((w, h), Image.BICUBIC)
        out += np.asarray(im, np.float32) / 255 * amp
        tot += amp
        amp *= 0.55
    return out / tot


def ridge(rng, base, amp, rough=0.55, peaky=1.0):
    x = np.arange(W)
    y = np.zeros(W)
    tot = 0.0
    for o in range(7):
        n = int(3 * 2 ** o) + 2
        pts = rng.random(n)
        xs = np.linspace(0, W - 1, n)
        y += np.interp(x, xs, pts) * (rough ** o)
        tot += rough ** o
    y = y / tot
    y = np.clip(y, 0, 1) ** peaky
    return base + (0.5 - y) * 2 * amp  # y 越大山越高


def soft(img_l, sigma):
    return np.asarray(Image.fromarray(np.clip(img_l * 255, 0, 255).astype(np.uint8)).filter(ImageFilter.GaussianBlur(sigma)), np.float32) / 255


def make(seed):
    rng = np.random.default_rng(seed)
    paper = np.array(PAPERS[seed % len(PAPERS)], np.float32)
    img = np.ones((H, W, 3), np.float32) * paper
    # 天空：上方略暗、下方略亮的淡墨晕
    ys = np.linspace(0, 1, H, dtype=np.float32)[:, None, None]
    sky = 0.035 * (1 - ys) * rng.uniform(0.6, 1.4)
    img *= (1 - sky)

    kinds = ['moon', 'sun', 'boat', 'pine', 'plain']
    kind = kinds[seed % len(kinds)]
    yy = np.arange(H, dtype=np.float32)[:, None]

    # 日月（先画，被山遮住）
    if kind in ('moon', 'sun'):
        cx = rng.uniform(0.25, 0.75) * W
        cy = rng.uniform(0.12, 0.26) * H
        r = rng.uniform(0.055, 0.085) * W
        d = np.sqrt((np.arange(W)[None, :] - cx) ** 2 + (yy - cy) ** 2)
        disc = np.clip((r - d) / 3.0, 0, 1)
        glow = np.exp(-(np.maximum(d - r, 0) / (r * 1.2)) ** 2) * 0.10
        if kind == 'moon':
            img = img * (1 - glow[..., None] * 0.35) + glow[..., None] * 255 * 0.35
            img = img * (1 - disc[..., None]) + np.array([252, 250, 244], np.float32) * disc[..., None]
            ring = np.clip(1 - np.abs(d - r) / 2.2, 0, 1) * 0.22
            img = img * (1 - ring[..., None] * 0.6)
        else:
            img = img * (1 - disc[..., None] * 0.9) + np.array(SEAL, np.float32) * disc[..., None] * 0.9

    # 多层山
    nl = int(rng.integers(4, 7))
    horizon = rng.uniform(0.38, 0.5)
    for i in range(nl):
        t = i / max(1, nl - 1)
        base = H * (horizon + 0.40 * t ** 1.1)
        amp = H * (0.16 - 0.07 * t) * rng.uniform(0.8, 1.2)
        rl = ridge(rng, base, amp, rough=rng.uniform(0.5, 0.62), peaky=rng.uniform(0.8, 1.5))
        mask = (yy >= rl[None, :]).astype(np.float32)
        sig = 5.0 - 3.6 * t
        mask = soft(mask, sig)
        dark = 0.10 + 0.74 * t ** 1.35  # 近处更浓
        # 山体内部：靠近山脊更浓，向下渐淡（云雾）
        dist = np.clip((yy - rl[None, :]) / (H * 0.22), 0, 1)
        shade = (1 - 0.55 * dist) * (0.85 + 0.3 * fbm2d(W, H, rng, 4, 3))
        a = np.clip(mask * dark * shade, 0, 0.95)[..., None]
        ink = np.array([28, 28, 30], np.float32) * (1 - 0.15 * (1 - t))
        img = img * (1 - a) + ink * a
        # 山脚云雾
        if i < nl - 1:
            band_c = base + amp * 0.35 + H * 0.02
            band = np.exp(-((yy - band_c) / (H * 0.045)) ** 2) * rng.uniform(0.55, 0.85)
            band = band * (0.6 + 0.4 * fbm2d(W, H, rng, 3, 2))
            img = img * (1 - band[..., None]) + paper * band[..., None]
        # 孤舟（画在最后一层山之前的水面上）
        if kind == 'boat' and i == nl - 2:
            pil = Image.fromarray(np.clip(img, 0, 255).astype(np.uint8))
            dr = ImageDraw.Draw(pil)
            bx = rng.uniform(0.3, 0.7) * W
            by = base + amp * 0.55 + H * 0.05
            s = W * 0.05
            dr.polygon([(bx - s, by), (bx + s * 1.1, by), (bx + s * 0.7, by + s * 0.28), (bx - s * 0.7, by + s * 0.28)], fill=(40, 40, 42))
            dr.line([(bx, by), (bx, by - s * 1.25)], fill=(50, 50, 52), width=2)
            dr.polygon([(bx + 2, by - s * 1.2), (bx + s * 0.8, by - s * 0.15), (bx + 2, by - s * 0.15)], fill=(95, 95, 98))
            for k in range(7):  # 水纹
                wy = by + s * (0.45 + 0.22 * k)
                wl = s * rng.uniform(1.5, 4.0)
                wx = bx + rng.uniform(-s * 3, s * 3)
                dr.line([(wx - wl, wy), (wx + wl, wy)], fill=(110, 112, 114), width=1)
            pil = pil.filter(ImageFilter.GaussianBlur(0.6))
            img = np.asarray(pil, np.float32)

    # 前景松（近处一侧）
    if kind == 'pine':
        pil = Image.fromarray(np.clip(img, 0, 255).astype(np.uint8))
        dr = ImageDraw.Draw(pil)
        side = -1 if seed % 2 else 1
        x0 = W * (0.12 if side < 0 else 0.88)
        y0 = H * 0.98
        pts = []
        x, y = x0, y0
        for k in range(22):
            x += side * rng.uniform(1.5, 7.0) * (1 if k < 9 else -0.4)
            y -= H * 0.016
            pts.append((x, y))
        for k in range(len(pts) - 1):
            dr.line([pts[k], pts[k + 1]], fill=(32, 30, 28), width=max(2, int(11 - k * 0.42)))
        for k in range(6, len(pts), 3):
            cx, cy = pts[k]
            for b in range(int(rng.integers(2, 4))):
                dirn = side * (1 if b % 2 else -1)
                ex = cx + dirn * rng.uniform(60, 150)
                ey = cy - rng.uniform(5, 40)
                dr.line([(cx, cy), (ex, ey)], fill=(34, 32, 30), width=3)
                for n in range(60):  # 松针
                    tt = rng.random()
                    px = cx + (ex - cx) * tt
                    py = cy + (ey - cy) * tt
                    ang = rng.uniform(0, np.pi * 2)
                    ln = rng.uniform(10, 24)
                    dr.line([(px, py), (px + np.cos(ang) * ln, py + np.sin(ang) * ln)], fill=(30, 30, 28), width=1)
        pil = pil.filter(ImageFilter.GaussianBlur(0.7))
        img = np.asarray(pil, np.float32)

    # 飞鸟
    if rng.random() < 0.55:
        pil = Image.fromarray(np.clip(img, 0, 255).astype(np.uint8))
        dr = ImageDraw.Draw(pil)
        ox, oy = rng.uniform(0.2, 0.75) * W, rng.uniform(0.08, 0.25) * H
        for k in range(int(rng.integers(2, 6))):
            bx = ox + rng.uniform(-90, 90)
            by = oy + rng.uniform(-35, 35)
            s = rng.uniform(7, 14)
            dr.arc([bx - s, by - s * 0.5, bx, by + s * 0.5], 200, 340, fill=(48, 48, 50), width=2)
            dr.arc([bx, by - s * 0.5, bx + s, by + s * 0.5], 200, 340, fill=(48, 48, 50), width=2)
        img = np.asarray(pil.filter(ImageFilter.GaussianBlur(0.5)), np.float32)

    # 纸张纤维与颗粒、暗角
    grain = fbm2d(W, H, rng, 3, 60)
    img *= (0.955 + 0.07 * grain)[..., None]
    fine = rng.normal(0, 2.2, (H, W, 1)).astype(np.float32)
    img += fine
    xs = np.linspace(-1, 1, W, dtype=np.float32)[None, :]
    ysv = np.linspace(-1, 1, H, dtype=np.float32)[:, None]
    vig = 1 - 0.16 * np.clip(xs ** 2 * 0.8 + ysv ** 2 * 0.6, 0, 1.5)
    img *= vig[..., None]
    return Image.fromarray(np.clip(img, 0, 255).astype(np.uint8))


if __name__ == '__main__':
    out = sys.argv[1]
    n = int(sys.argv[2]) if len(sys.argv) > 2 else 30
    os.makedirs(out, exist_ok=True)
    tot = 0
    for i in range(n):
        im = make(i + 1)
        p = os.path.join(out, 'bg%02d.jpg' % (i + 1))
        im.save(p, 'JPEG', quality=70, optimize=True, progressive=True)
        tot += os.path.getsize(p)
    print('done', n, 'images,', round(tot / 1e6, 2), 'MB')
