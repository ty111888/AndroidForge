const fs = require('fs');
const path = require('path');
const http = require('http');
const ASSETS = path.join(__dirname, '..', 'app', 'src', 'main', 'assets');
const SHOTS = '/tmp/shots';
fs.mkdirSync(SHOTS, { recursive: true });
const JPG = fs.readFileSync(path.join(ASSETS, 'img', 'bg', 'bg03.jpg'));
const CORS = { 'access-control-allow-origin': '*' };

// ---------------- 静态服务器（模拟 App 里的 assets）
function serve() {
  return new Promise((res) => {
    const srv = http.createServer((req, rsp) => {
      let p = decodeURIComponent(req.url.split('?')[0]); if (p === '/') p = '/index.html';
      const f = path.join(ASSETS, p);
      if (!f.startsWith(ASSETS) || !fs.existsSync(f)) { rsp.writeHead(404); rsp.end('nf'); return; }
      const ext = path.extname(f);
      const types = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.jpg': 'image/jpeg' };
      rsp.writeHead(200, { 'content-type': types[ext] || 'application/octet-stream' });
      rsp.end(fs.readFileSync(f));
    }).listen(0, '127.0.0.1', () => res(srv));
  });
}

// ---------------- 模拟外部网络
const netLog = [];
const TANG = (i) => i === 0 ? [
  { title: '静夜思', author: '李白', paragraphs: ['床前明月光，疑是地上霜。', '举头望明月，低头思故乡。'] },
  { title: '山居', author: '某人', paragraphs: ['云开见月明，山色空蒙雨亦奇。'] }
] : [{ title: '填充' + i, author: '无名', paragraphs: ['无关的一句话。'] }];
const CI = (i) => i === 0 ? [{ rhythmic: '水调歌头', author: '苏轼', paragraphs: ['明月几时有，把酒问青天。', '不知天上宫阙，今夕是何年。'] }] : [];
const MING_CSV = '题目,朝代,作者,内容\r\n山居图,明,甲某,"雲開見月明，山色空濛雨亦奇。"\r\n夜坐,明末清初,张三,"独坐云深处，月照松间路。"\r\n';
async function mock(page) {
  await page.route('**/*', async (route) => {
    const url = route.request().url();
    if (url.startsWith('http://127.0.0.1')) return route.continue();
    netLog.push(url);
    const dec = decodeURIComponent(url);
    const json = (o, st) => route.fulfill({ status: st || 200, headers: Object.assign({ 'content-type': 'application/json' }, CORS), body: JSON.stringify(o) });
    let m;
    if (dec.includes('opencc-js')) return route.fulfill({ status: 200, headers: Object.assign({ 'content-type': 'text/javascript' }, CORS),
      body: "window.OpenCC={Converter:function(o){var m={'云':'雲','雲':'云','开':'開','開':'开','见':'見','見':'见','蒙':'濛','濛':'蒙'};return function(s){return Array.from(s).map(function(c){return m[c]||c}).join('')}}};" });
    if ((m = dec.match(/chinese-poetry@master\/全唐诗\/poet\.tang\.(\d+)\.json$/))) return json(TANG(Number(m[1]) / 1000));
    if ((m = dec.match(/chinese-poetry@master\/宋词\/ci\.song\.(\d+)\.json$/))) return json(CI(Number(m[1]) / 1000));
    if (dec.includes('Werneror/Poetry@master/明_1.csv')) return route.fulfill({ status: 200, headers: Object.assign({ 'content-type': 'text/csv; charset=utf-8' }, CORS), body: MING_CSV });
    if (dec.includes('Werneror/Poetry@master/')) return route.fulfill({ status: 200, headers: Object.assign({ 'content-type': 'text/csv; charset=utf-8' }, CORS), body: '题目,朝代,作者,内容\r\n' });
    if (dec.includes('poetry.palemoky.com/api/v1/poems/search')) return json({ data: [{ title: '山居', author: { name: '某人' }, dynasty: { name: '明' }, content: '云开见月明，山色空蒙雨亦奇。' }] });
    // 图库
    if (dec.includes('collectionapi.metmuseum.org') && dec.includes('/search')) return json({ total: 2, objectIDs: [101, 102] });
    if ((m = dec.match(/collectionapi\.metmuseum\.org\/public\/collection\/v1\/objects\/(\d+)/))) return json({ objectID: Number(m[1]), isPublicDomain: true, primaryImageSmall: 'https://images.metmuseum.org/x' + m[1] + '.jpg', title: '山水图' + m[1], artistDisplayName: '某画家', culture: 'China', classification: 'Paintings', objectName: 'Hanging scroll', objectURL: 'https://www.metmuseum.org/art/collection/search/' + m[1] });
    if (dec.includes('api.artic.edu/api/v1/artworks/search')) return json({ config: { iiif_url: 'https://www.artic.edu/iiif/2' }, data: [{ id: 7, title: 'Landscape', artist_display: 'Anon', image_id: 'abc', place_of_origin: 'China' }] });
    if (dec.includes('openaccess-api.clevelandart.org')) return json({ data: [{ id: 9, title: 'Moon', creators: [{ description: 'X (Chinese)' }], images: { web: { url: 'https://openaccess-cdn.clevelandart.org/9.jpg' } }, url: 'https://clevelandart.org/9' }] });
    if (/images\.metmuseum\.org|artic\.edu\/iiif|openaccess-cdn/.test(dec)) return route.fulfill({ status: 200, headers: Object.assign({ 'content-type': 'image/jpeg' }, CORS), body: JPG });
    return route.fulfill({ status: 404, body: 'mock 404' });
  });
}


module.exports = { serve, mock, netLog, ASSETS, SHOTS, JPG, CORS };
