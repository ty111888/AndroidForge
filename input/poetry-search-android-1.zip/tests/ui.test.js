const assert = require('assert');
const fs = require('fs');
const path = require('path');
const { chromium } = require('playwright');
const { serve, mock, netLog, ASSETS, SHOTS } = require('./helpers');

let n = 0, failed = 0;
async function t(name, fn) {
  try { await fn(); n++; console.log('ok  -', name); } catch (e) { failed++; console.log('FAIL-', name, '\n   ', String(e.stack || e).split('\n').slice(0, 5).join('\n    ')); }
}

(async () => {
  const srv = await serve();
  const base = 'http://127.0.0.1:' + srv.address().port + '/index.html';
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true, locale: 'zh-CN' });
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', (e) => errors.push('pageerror: ' + e.message));
  page.on('console', (m) => { if (m.type() === 'error' && !/mock 404|Failed to load resource/.test(m.text())) errors.push('console: ' + m.text()); });
  await mock(page);
  await page.goto(base);
  await page.waitForSelector('#fDb');

  const texts = (sel) => page.$$eval(sel, (els) => els.map((e) => e.textContent.trim()));
  const waitDone = () => page.waitForFunction(() => /^(完成|已停止|出错)/.test(document.getElementById('st').textContent), null, { timeout: 15000 });
  async function search(q, scope) {
    if (scope) await page.selectOption('#scope', scope);
    await page.fill('#q', q);
    await page.click('#go');
    await waitDone();
  }

  await t('首页：标题、"诗词搜索"按钮、默认筛选', async () => {
    assert.strictEqual((await page.textContent('.top h1')).includes('诗词搜索'), true);
    assert.strictEqual((await page.textContent('#btnSites')).trim(), '诗词搜索 ›');
    assert.strictEqual((await page.textContent('#fDb')).trim(), '数据库：2 个 ▾');
    assert.strictEqual((await page.textContent('#fDyn')).trim(), '朝代：不限 ▾');
    await page.screenshot({ path: SHOTS + '/01-home.png' });
  });

  await t('普通搜索（紧挨着）：明月 → 静夜思、水调歌头', async () => {
    await search('明月', 'all');
    const titles = await texts('#out .hit h3');
    assert.ok(titles.includes('静夜思') && titles.includes('水调歌头'), titles.join('|'));
    assert.ok(!titles.includes('山居'));
    assert.ok((await page.textContent('#st')).startsWith('完成，命中 2 条'));
    await page.screenshot({ path: SHOTS + '/02-plain.png' });
  });

  await t('同句搜索（有空格）：云 月 → 例句+相邻句+作者诗题', async () => {
    await search('云   月', 'content');
    const sents = await texts('#out .hit .sent');
    assert.deepStrictEqual(sents, ['云开见月明']);
    assert.strictEqual((await texts('#out .hit .nb'))[0], '山色空蒙雨亦奇');
    const meta = (await texts('#out .hit .meta'))[0];
    assert.ok(meta.includes('某人') && meta.includes('《山居》') && meta.includes('唐'), meta);
    assert.strictEqual(await page.$$eval('#out mark', (m) => m.length), 2);
    await page.screenshot({ path: SHOTS + '/03-sentence.png' });
  });

  await t('跨句不算：明月 举头（不同句）→ 没有命中', async () => {
    await search('床前 低头', 'content');
    assert.strictEqual((await page.$$('#out .hit')).length, 0);
    assert.ok((await page.textContent('#st')).includes('同一句'));
  });

  await t('朝代抽屉：选唐 → 标签更新；返回键只关抽屉', async () => {
    await page.click('#fDyn');
    await page.waitForSelector('#sheet:not(.hidden)');
    await page.click('#sheetBody .chip:text-is("唐")');
    assert.strictEqual((await page.textContent('#fDyn')).trim(), '朝代：唐 ▾');
    await page.goBack(); // 相当于安卓返回键
    await page.waitForSelector('#sheet.hidden', { state: 'attached' });
    await search('明月', 'all');
    const titles = await texts('#out .hit h3');
    assert.deepStrictEqual(titles, ['静夜思']); // 宋词水调歌头被朝代筛掉
    await page.click('#fDyn'); await page.click('#sheetBody button:text("清空")'); await page.click('#sheetOk');
    assert.strictEqual((await page.textContent('#fDyn')).trim(), '朝代：不限 ▾');
  });

  await t('范围：作者/诗题', async () => {
    await search('李白', 'author');
    assert.deepStrictEqual(await texts('#out .hit h3'), ['静夜思']);
    await search('水调', 'title');
    assert.deepStrictEqual(await texts('#out .hit h3'), ['水调歌头']);
    await page.selectOption('#scope', 'all');
  });

  await t('数据库抽屉：勾选 Werneror 明 + 诗泉；繁简通搜命中繁体原文；同句跨库合并', async () => {
    await page.click('#fDb');
    await page.waitForSelector('#sheet:not(.hidden)');
    const rows = await texts('#sheetBody .opt');
    assert.ok(rows.some((r) => r.startsWith('明（含明末清初）')));
    await page.click('#sheetBody .opt:has-text("明（含明末清初）") input');
    await page.click('#sheetBody .opt:has-text("诗泉") input');
    await page.click('#sheetOk');
    assert.strictEqual((await page.textContent('#fDb')).trim(), '数据库：4 个 ▾');
    await search('云 月明', 'content');
    const metas = await texts('#out .hit .meta');
    // 唐诗与诗泉里是同一句 → 合并成一条（两个来源标签）；Werneror 里是繁体原文、作者也不同 → 单独一条，但靠繁简通搜找到了
    assert.strictEqual(metas.length, 2, JSON.stringify(metas));
    const tags = await texts('#out .hit:nth-child(1) .tag');
    assert.deepStrictEqual(tags, ['唐诗', '诗泉']);
    assert.ok((await texts('#out .hit .sent')).includes('雲開見月明'));
    await page.screenshot({ path: SHOTS + '/04-merged.png' });
  });

  await t('诗页：打开 → 自动匹配在线图库背景并显示出处', async () => {
    await page.click('#out .hit');
    await page.waitForSelector('#poemView:not(.hidden)');
    await page.waitForFunction(() => document.getElementById('pvCredit').textContent.length > 0, null, { timeout: 8000 });
    const credit = await page.textContent('#pvCredit');
    assert.ok(/博物馆/.test(credit), credit);
    const bg = await page.$eval('#pvBg', (e) => e.style.backgroundImage);
    assert.ok(bg.includes('http'), bg);
    assert.ok((await page.textContent('#pvTitle')).length > 0);
    assert.ok((await page.$$('#pvText p')).length >= 1);
    await page.screenshot({ path: SHOTS + '/05-poem-online.png' });
  });

  await t('换图：在线候选/本地图；选在线图 → 下载保存；返回键逐层关闭', async () => {
    await page.click('#pvSwap');
    await page.waitForSelector('#sheet:not(.hidden)');
    await page.waitForFunction(() => document.querySelectorAll('#sheetBody .grid')[0].children.length > 0, null, { timeout: 8000 });
    assert.strictEqual(await page.$$eval('#sheetBody .grid:nth-of-type(1) .cell', (c) => c.length) > 0, true);
    const localCells = await page.$$eval('#sheetBody .grid', (g) => g[g.length - 1].children.length);
    assert.strictEqual(localCells, 36);
    await page.screenshot({ path: SHOTS + '/06-swap.png' });
    // 选在线候选第一张
    await page.click('#sheetBody .grid >> nth=0 >> .cell >> nth=0');
    await page.waitForSelector('#sheet.hidden', { state: 'attached' });
    await page.waitForFunction(() => /已保存/.test(document.getElementById('toast').textContent) || document.getElementById('pvCredit').textContent.length > 0);
    const saved = await page.evaluate(async () => (await PSStore.listImages()).length);
    assert.strictEqual(saved, 1);
    // 再换成本地图
    await page.click('#pvSwap'); await page.waitForSelector('#sheet:not(.hidden)');
    await page.click('#sheetBody .grid >> nth=2 >> .cell >> nth=4');
    await page.waitForSelector('#sheet.hidden', { state: 'attached' });
    await page.waitForTimeout(700);
    const bg = await page.$eval('#pvBg', (e) => e.style.backgroundImage);
    assert.ok(bg.includes('img/bg/bg05.jpg'), bg);
    // 返回键关闭诗页
    await page.goBack();
    await page.waitForSelector('#poemView.hidden', { state: 'attached' });
  });

  await t('再次打开同一首诗：记住了选定的本地图', async () => {
    await page.click('#out .hit');
    await page.waitForSelector('#poemView:not(.hidden)');
    await page.waitForTimeout(900);
    const bg = await page.$eval('#pvBg', (e) => e.style.backgroundImage);
    assert.ok(bg.includes('img/bg/bg05.jpg'), bg);
    await page.goBack();
  });

  await t('AI 生图：提示词、AI 网站、psext 链接', async () => {
    await page.evaluate(() => { const s = JSON.parse(localStorage.getItem('ps-settings') || '{}'); s.aiSites = [{ name: '某AI', url: 'https://ai.example.com/draw?x=1&y=2' }]; localStorage.setItem('ps-settings', JSON.stringify(s)); });
    await page.reload(); await page.waitForSelector('#fDb');
    await page.fill('#q', '明月'); await page.click('#go'); await waitDone();
    await page.click('#out .hit'); await page.waitForSelector('#poemView:not(.hidden)');
    await page.click('#pvAI'); await page.waitForSelector('#sheet:not(.hidden)');
    const ta = await page.$$eval('#sheetBody textarea', (t) => t.map((x) => x.value));
    assert.ok(ta[0].includes('水墨') && ta[1].includes('ink wash'));
    const href = await page.$eval('#sheetBody a.btn', (a) => a.getAttribute('href'));
    assert.strictEqual(decodeURIComponent(href.replace('psext://open?u=', '')), 'https://ai.example.com/draw?x=1&y=2');
    await page.screenshot({ path: SHOTS + '/07-ai.png' });
    await page.goBack(); await page.goBack();
    await page.waitForSelector('#poemView.hidden', { state: 'attached' });
  });

  await t('导入 dbf+fpt（GBK）：向导 → 字段自动对应 → 导入 → 可搜索', async () => {
    await page.click('.tabs button[data-pg="data"]');
    await page.setInputFiles('#fileIn', [path.join(__dirname, 'fixtures', 'vfp_gbk.dbf'), path.join(__dirname, 'fixtures', 'vfp_gbk.fpt')]);
    await page.waitForSelector('#sheet:not(.hidden)');
    await page.waitForSelector('#sheetBody button.primary:not([disabled])');
    const sels = await page.$$eval('#sheetBody select', (s) => s.map((x) => x.value));
    assert.deepStrictEqual(sels.slice(1), ['TITLE', 'AUTHOR', 'DYNASTY', 'CONTENT', '']);
    assert.ok((await page.textContent('#sheetBody .preview')).includes('静夜思'));
    await page.screenshot({ path: SHOTS + '/08-import-dbf.png' });
    await page.click('#sheetBody button.primary');
    await page.waitForFunction(() => /已导入 2 条/.test(document.getElementById('toast').textContent), null, { timeout: 10000 });
    await page.waitForSelector('#sheet.hidden', { state: 'attached' });
    assert.ok((await texts('#importedList .card')).some((x) => x.includes('vfp_gbk') && x.includes('2 条'))); // 4条里：1条已删除、1条正文为空，都不导入
    await page.screenshot({ path: SHOTS + '/09-data.png' });
    // 只搜导入的库
    await page.click('.tabs button[data-pg="search"]');
    await page.click('#fDb'); await page.waitForSelector('#sheet:not(.hidden)');
    for (const lab of ['唐诗', '宋词', '明（含明末清初）', '诗泉']) {
      const cb = await page.$('#sheetBody .opt:has-text("' + lab + '") input');
      if (await cb.isChecked()) await cb.click();
    }
    await page.click('#sheetOk');
    await search('春眠 啼鸟', 'content');
    assert.strictEqual((await texts('#out .hit')).length, 0); // 春眠/啼鸟 在同一句？"春眠不觉晓，处处闻啼鸟" 分两句
    await search('处处 啼鸟', 'content');
    const s = await texts('#out .hit .sent');
    assert.deepStrictEqual(s, ['处处闻啼鸟']);
    assert.ok((await texts('#out .hit .meta'))[0].includes('孟浩然'));
  });

  await t('导入 txt（GBK 编码）：全文资料，按书名显示例句', async () => {
    const gbk = Buffer.from([0xB4, 0xB2, 0xC7, 0xB0, 0xC3, 0xF7, 0xD4, 0xC2, 0xB9, 0xE2, 0xA3, 0xAC, 0xD2, 0xC9, 0xCA, 0xC7, 0xB5, 0xD8, 0xC9, 0xCF, 0xCB, 0xAA, 0xA1, 0xA3, 0x0D, 0x0A]); // 床前明月光，疑是地上霜。
    await page.click('.tabs button[data-pg="data"]');
    // 用内存文件传入（中文文件名；沙箱里带中文的本地路径会让浏览器收不到 change 事件，与 App 无关）
    await page.setInputFiles('#fileIn', [{ name: '测试书.txt', mimeType: 'text/plain', buffer: gbk }]);
    await page.waitForSelector('#sheet:not(.hidden)');
    await page.waitForFunction(() => document.querySelector('#sheetBody .preview') && document.querySelector('#sheetBody .preview').textContent.includes('床前明月光'));
    await page.click('#sheetBody button.primary');
    await page.waitForFunction(() => /已导入 1 段/.test(document.getElementById('toast').textContent), null, { timeout: 10000 });
    await page.waitForSelector('#sheet.hidden', { state: 'attached' });
    await page.click('.tabs button[data-pg="search"]');
    await search('明月 光', 'content');
    const metas = await texts('#out .hit .meta');
    assert.ok(metas.some((m) => m.includes('《测试书》')), metas.join('|'));
  });

  await t('书籍筛选：选“测试书”后只出这本书', async () => {
    await page.click('#fBook'); await page.waitForSelector('#sheet:not(.hidden)');
    await page.click('#sheetBody .opt:has-text("测试书") input'); await page.click('#sheetOk');
    assert.ok((await page.textContent('#fBook')).includes('1 个'));
    await search('明月', 'content');
    const metas = await texts('#out .hit .meta');
    assert.ok(metas.length >= 1 && metas.every((m) => m.includes('测试书')), metas.join('|'));
    await page.click('#fBook'); await page.click('#sheetBody .opt:has-text("测试书") input'); await page.click('#sheetOk');
  });

  await t('导入：pdf 等下一版格式给出明确提示；只选 .fpt 提示', async () => {
    const pdf = '/tmp/a.pdf'; fs.writeFileSync(pdf, '%PDF-1.4 test');
    await page.click('.tabs button[data-pg="data"]');
    await page.setInputFiles('#fileIn', [pdf]);
    await page.waitForFunction(() => /下一版/.test(document.getElementById('toast').textContent));
    await page.setInputFiles('#fileIn', [path.join(__dirname, 'fixtures', 'vfp_gbk.fpt')]);
    await page.waitForFunction(() => /\.dbf/.test(document.getElementById('toast').textContent));
  });

  await t('删除导入的数据库（确认框）', async () => {
    const before = (await page.$$('#importedList .card')).length;
    await page.click('#importedList .card >> nth=0 >> button');
    await page.waitForSelector('#sheet:not(.hidden)');
    await page.click('#sheetBody .btn.danger');
    await page.waitForFunction((b) => document.querySelectorAll('#importedList .card').length === b - 1, before);
  });

  await t('设置页：图库测试、诗泉测试、AI 网站增删', async () => {
    await page.click('.tabs button[data-pg="set"]');
    await page.click('#btnTestGal');
    await page.waitForFunction(() => /✓/.test(document.getElementById('galRes').textContent), null, { timeout: 20000 });
    const gal = await page.textContent('#galRes');
    assert.ok(gal.includes('大都会') && gal.includes('芝加哥') && gal.includes('克利夫兰'), gal);
    await page.click('#btnTestSq');
    await page.waitForFunction(() => /返回 1 条/.test(document.getElementById('sqRes').textContent), null, { timeout: 10000 });
    await page.fill('#aiName', '另一个'); await page.fill('#aiUrl', 'https://b.example.com/');
    await page.click('#aiAdd');
    assert.strictEqual((await page.$$('#aiList .card')).length, 2);
    await page.click('#aiList .card >> nth=1 >> button');
    assert.strictEqual((await page.$$('#aiList .card')).length, 1);
    await page.screenshot({ path: SHOTS + '/10-settings.png', fullPage: false });
  });

  await t('"诗词搜索"页：10 个网址与给定的一字不差；用普通链接（App 内打开）', async () => {
    await page.click('.tabs button[data-pg="search"]');
    await page.click('#btnSites');
    const hrefs = await page.$$eval('#sitesList a', (a) => a.map((x) => x.getAttribute('href')));
    assert.deepStrictEqual(hrefs, [
      'https://www.sou-yun.cn/index.aspx', 'https://www.shidianguji.com/', 'https://sc.zdic.net/', 'https://ctext.org/pre-qin-and-han/zhs',
      'https://jingdian.ancientbooks.cn/6', 'https://hanchi.ihp.sinica.edu.tw/ihp/hanji.htm', 'https://ytenx.org/', 'https://seg.shenshen.wiki/',
      'https://guji.xueheng.net/', 'https://t.shenshen.wiki/']);
    const names = await texts('#sitesList a b');
    assert.strictEqual(names.length, 10);
    assert.ok(await page.$$eval('#sitesList a', (a) => a.every((x) => !x.target)));
    await page.screenshot({ path: SHOTS + '/11-sites.png' });
    await page.click('#sitesBack');
  });

  await t('停止按钮：搜索中点“停止”', async () => {
    await page.click('#fDb'); await page.waitForSelector('#sheet:not(.hidden)');
    await page.click('#sheetBody .opt:has-text("唐诗") input'); await page.click('#sheetOk');
    await page.fill('#q', '无关');
    await page.click('#go');
    await page.waitForFunction(() => document.getElementById('go').textContent === '停止' || /^完成/.test(document.getElementById('st').textContent));
    if ((await page.textContent('#go')) === '停止') await page.click('#go');
    await waitDone();
    assert.ok(/^(已停止|完成)/.test(await page.textContent('#st')));
    assert.strictEqual((await page.textContent('#go')).trim(), '搜索');
  });

  await t('深色模式截图', async () => {
    await page.emulateMedia({ colorScheme: 'dark' });
    await page.click('.tabs button[data-pg="search"]');
    await page.screenshot({ path: SHOTS + '/12-dark.png' });
    await page.emulateMedia({ colorScheme: 'light' });
  });

  await t('整个过程没有 JS 报错', async () => { assert.deepStrictEqual(errors, []); });

  await browser.close(); srv.close();
  console.log(n + ' passed, ' + failed + ' failed');
  process.exit(failed ? 1 : 0);
})();
