# 生成测试用的 dBase/FoxPro 文件（GBK 编码，含 .fpt 备注文件）
import struct, os
OUT = os.path.join(os.path.dirname(__file__), 'fixtures')

def build(name, version, memo_len, vfp, enc, recs, fields_spec, delete_idx=None):
    # fields_spec: [(name, type, length)]
    fields = b''
    for (n, t, l) in fields_spec:
        nb = n.encode(enc)[:10]
        fields += nb + b'\x00' * (11 - len(nb)) + t.encode() + b'\x00' * 4 + bytes([l, 0]) + b'\x00' * 14
    hlen = 32 + len(fields) + 1 + (263 if vfp else 0)
    rlen = 1 + sum(l for _, _, l in fields_spec)
    ldid = 0x4D if enc == 'gbk' else 0
    head = bytes([version, 24, 1, 1]) + struct.pack('<IHH', len(recs), hlen, rlen) + b'\x00' * 17 + bytes([ldid]) + b'\x00\x00'
    body = b''
    # fpt: 512 字节头，块大小 64，数据从第 8 块开始
    bs = 64
    memo = bytearray(512)
    nextblock = 8
    memo_blocks = {}
    out_recs = b''
    for ri, r in enumerate(recs):
        rec = b'*' if ri == delete_idx else b' '
        for (n, t, l), val in zip(fields_spec, r):
            if t == 'C':
                b = val.encode(enc)[:l]
                rec += b + b' ' * (l - len(b))
            elif t == 'M':
                if val == '':
                    rec += (b'\x00' * 4) if memo_len == 4 else b' ' * 10
                else:
                    data = val.encode(enc)
                    blk = struct.pack('>II', 1, len(data)) + data
                    pad = (-len(blk)) % bs
                    memo += blk + b'\x00' * pad
                    ref = nextblock
                    nextblock += (len(blk) + pad) // bs
                    rec += struct.pack('<I', ref) if memo_len == 4 else str(ref).rjust(10).encode()
        out_recs += rec
    memo[0:4] = struct.pack('>I', nextblock)
    memo[6:8] = struct.pack('>H', bs)
    data = head + fields + b'\x0d' + (b'\x00' * 263 if vfp else b'') + out_recs + b'\x1a'
    open(os.path.join(OUT, name + '.dbf'), 'wb').write(data)
    open(os.path.join(OUT, name + '.fpt'), 'wb').write(bytes(memo))

recs = [
    ('静夜思', '李白', '唐', '床前明月光，疑是地上霜。\r\n举头望明月，低头思故乡。'),
    ('春晓', '孟浩然', '唐', '春眠不觉晓，处处闻啼鸟。夜来风雨声，花落知多少。'),
    ('已删除的', '某人', '宋', '这条被标记为删除，不应读出。'),
    ('无题', '佚名', '', ''),
]
spec_vfp = [('TITLE', 'C', 20), ('AUTHOR', 'C', 10), ('DYNASTY', 'C', 6), ('CONTENT', 'M', 4)]
spec_fox = [('TITLE', 'C', 20), ('AUTHOR', 'C', 10), ('DYNASTY', 'C', 6), ('CONTENT', 'M', 10)]
spec_cn = [('题目', 'C', 20), ('作者', 'C', 10), ('朝代', 'C', 6), ('正文', 'M', 4)]
build('vfp_gbk', 0x30, 4, True, 'gbk', recs, spec_vfp, delete_idx=2)
build('fox2_gbk', 0xF5, 10, False, 'gbk', recs, spec_fox, delete_idx=2)
build('cnfields_gbk', 0x30, 4, True, 'gbk', recs, spec_cn, delete_idx=2)
print('fixtures written:', sorted(os.listdir(OUT)))
