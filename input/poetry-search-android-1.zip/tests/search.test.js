const assert = require('assert');
const Search = require('../app/src/main/assets/js/search.js');
const Sources = require('../app/src/main/assets/js/sources.js');

let n = 0;
async function t(name, fn) {
  try { await fn(); n++; console.log('ok  -', name); } catch (e) { console.log('FAIL-', name, '\n   ', e.stack.split('\n').slice(0, 4).join('\n    ')); process.exitCode = 1; }
}

// ---------------- 模拟网络
const calls = [];
let failUrls = [], apiMode = 'ok';
function tangFile(i) {
  if (i === 0) return [
    { title: '静夜思', author: '李白', paragraphs: ['床前明月光，疑是地上霜。', '举头望明月，低头思故乡。'] },
    { title: '山居', author: '某人', paragraphs: ['云开见月明，山色空蒙雨亦奇。'] }
  ];
  if (i === 3) return [{ title: '访友', author: '佚名', paragraphs: ['云在青山外，月出东山上。'] }];
  return [{ title: '填充' + i, author: '无名', paragraphs: ['无关的一句话。'] }];
}
const MING_CSV = '题目,朝代,作者,内容\r\n' +
  '山居,明,某人,"云开见月明，山色空蒙雨亦奇。"\r\n' +
  '夜坐,明末清初,张三,"独坐云深处，月照松间路。"\r\n';
function resp(body, status) {
  status = status || 200;
  return { ok: status < 400, status, json: async () => (typeof body === 'string' ? JSON.parse(body) : body), text: async () => (typeof body === 'string' ? body : JSON.stringify(body)), arrayBuffer: async () => new TextEncoder().encode(typeof body === 'string' ? body : JSON.stringify(body)).buffer, clone() { return this; } };
}
global.fetch = async (url) => {
  url = String(url); calls.push(url);
  if (failUrls.some((f) => url.includes(f))) return resp('nope', 404);
  const dec = decodeURIComponent(url);
  let m;
  if ((m = dec.match(/chinese-poetry@master\/全唐诗\/poet\.tang\.(\d+)\.json$/))) return resp(tangFile(Number(m[1]) / 1000));
  if (dec.includes('Werneror/Poetry@master/明_1.csv')) return resp(MING_CSV);
  if (dec.includes('Werneror/Poetry@master/明_')) return resp('题目,朝代,作者,内容\r\n');
  if (dec.includes('Werneror/Poetry@master/明末清初.csv')) return resp('题目,朝代,作者,内容\r\n');
  if (dec.includes('poetry.palemoky.com/api/v1/poems/search')) {
    if (apiMode === '429') return resp('{}', 429);
    if (apiMode === 'bad') return resp({ foo: 1 });
    return resp({ data: [
      { title: '山居', author: { name: '某人' }, dynasty: { name: '明' }, content: '云开见月明，山色空蒙雨亦奇。' },
      { title: '无关', author: { name: '乙' }, dynasty: { name: '宋' }, content: '云在青山外，月出东山上。' }
    ] });
  }
  return resp('', 404);
};

const def = (id) => Sources.BUILTIN.find((d) => d.id === id);
async function run(o) {
  const items = [];
  const r = await Search.run(Object.assign({ scope: 'all', filters: null, convert: false, onHit: (it) => items.push(it) }, o));
  return { r, items };
}

(async () => {
  await t('单词搜索（紧挨着）：按整首诗命中', async () => {
    const { r, items } = await run({ query: '明月', defs: [def('orig-tang')] });
    assert.strictEqual(r.fails, 0);
    assert.strictEqual(items.length, 1); // 只有静夜思连写了“明月”；山居是“见月明”，不算
    assert.strictEqual(items[0].poem.title, '静夜思');
    assert.ok(items.every((x) => x.hit.kind === 'poem'));
  });

  await t('同句多词（空格）：只列同一句里同时有的例句；跨句不算', async () => {
    const { r, items } = await run({ query: '云 月', scope: 'content', defs: [def('orig-tang')] });
    assert.strictEqual(items.length, 1);
    assert.strictEqual(items[0].hit.kind, 'sentence');
    assert.strictEqual(items[0].hit.text, '云开见月明');
    assert.strictEqual(items[0].hit.neighbor, '山色空蒙雨亦奇');
    assert.strictEqual(items[0].poem.author, '某人');
    assert.strictEqual(r.multi, true);
  });

  await t('跨数据库去重：原始库和 Werneror 里同一句只出现一条，来源合并', async () => {
    const { r, items } = await run({ query: '云 月', scope: 'content', defs: [def('orig-tang'), def('wn-ming')] });
    const same = items.filter((x) => x.hit.text === '云开见月明');
    assert.strictEqual(same.length, 1);
    assert.strictEqual(same[0].srcs.size, 2);
    // Werneror 里还有“独坐云深处，月照松间路”：云、月在不同句 → 不算
    assert.ok(!items.some((x) => x.poem.title === '夜坐'));
  });

  await t('朝代筛选：明（含明末清初）', async () => {
    const { items } = await run({ query: '云', scope: 'content', defs: [def('orig-tang'), def('wn-ming')], filters: { dynasties: new Set(['明']), books: new Set() } });
    assert.ok(items.length >= 1);
    assert.ok(items.every((x) => (x.poem.dynasty || '').includes('明')));
    assert.ok(items.some((x) => x.poem.dynasty === '明末清初'));
  });

  await t('书籍筛选：只要全唐诗', async () => {
    const { items } = await run({ query: '云', scope: 'content', defs: [def('orig-tang'), def('wn-ming')], filters: { dynasties: new Set(), books: new Set(['全唐诗']) } });
    assert.ok(items.length >= 1 && items.every((x) => x.poem.book === '全唐诗'));
  });

  await t('诗题/作者范围', async () => {
    const a = await run({ query: '李白', scope: 'author', defs: [def('orig-tang')] });
    assert.strictEqual(a.items.length, 1);
    assert.strictEqual(a.items[0].poem.title, '静夜思');
    const b = await run({ query: '静夜', scope: 'title', defs: [def('orig-tang')] });
    assert.strictEqual(b.items.length, 1);
    const c = await run({ query: '静夜', scope: 'content', defs: [def('orig-tang')] });
    assert.strictEqual(c.items.length, 0);
  });

  await t('结果上限：达到上限后停止并标记 capped', async () => {
    const { r, items } = await run({ query: '无关', scope: 'content', defs: [def('orig-tang')], cap: 3 });
    assert.strictEqual(items.length, 3);
    assert.strictEqual(r.capped, true);
  });

  await t('某个文件失败：计入 fails 并给出提示，其余照常搜索', async () => {
    failUrls = ['poet.tang.3000.json'];
    const { r, items } = await run({ query: '云 月', scope: 'content', defs: [def('orig-tang')] });
    failUrls = [];
    assert.strictEqual(r.fails, 1);
    assert.ok(r.notes.some((x) => x.includes('失败')));
    assert.strictEqual(items.length, 1);
  });

  await t('诗泉：用最长的词请求；本地再按同句规则筛选', async () => {
    calls.length = 0;
    const { r, items } = await run({ query: '云 月明', scope: 'content', defs: [def('shiquan')] });
    assert.ok(calls.some((u) => decodeURIComponent(u).includes('q=月明')));
    assert.strictEqual(items.length, 1); // 只有“云开见月明”同句同时含 云 与 月明
    assert.strictEqual(items[0].poem.dynasty, '明');
    assert.strictEqual(items[0].poem.author, '某人');
    assert.ok(r.notes.some((x) => x.includes('诗泉')));
  });

  await t('诗泉：429 限流与格式认不出，给出明确提示而不崩溃', async () => {
    apiMode = '429';
    let o = await run({ query: '云月', defs: [def('shiquan')] });
    assert.ok(o.r.notes.some((x) => x.includes('限流')));
    apiMode = 'bad';
    o = await run({ query: '云月', defs: [def('shiquan')] });
    assert.ok(o.r.notes.some((x) => x.includes('格式')));
    apiMode = 'ok';
  });

  await t('Sources.pickList / normApiPoem 兼容多种返回结构', () => {
    assert.strictEqual(Sources.pickList([1, 2]).length, 2);
    assert.strictEqual(Sources.pickList({ data: { poems: [1] } }).length, 1);
    assert.strictEqual(Sources.pickList({ results: [1, 2, 3] }).length, 3);
    assert.strictEqual(Sources.pickList({ x: 1 }), null);
    const p = Sources.normApiPoem({ title: 'T', author: { name: 'A' }, dynasty: '唐', paragraphs: ['甲', '乙'] });
    assert.deepStrictEqual([p.title, p.author, p.dynasty, p.content], ['T', 'A', '唐', '甲\n乙']);
  });

  await t('中止：signal.aborted 后不再继续', async () => {
    const sig = { aborted: false };
    let cnt = 0;
    const { r } = await run({ query: '无关', scope: 'content', defs: [def('orig-tang')], signal: sig, onProgress: (p) => { if (p.done >= 5) sig.aborted = true; cnt = p.done; } });
    assert.ok(r.aborted);
    assert.ok(cnt < 58);
  });

  await t('没有关键字：报错', async () => {
    let err = null;
    try { await Search.run({ query: '   ', defs: [] }); } catch (e) { err = e; }
    assert.ok(err && err.message.includes('关键字'));
  });

  console.log(n + ' passed');
})();
