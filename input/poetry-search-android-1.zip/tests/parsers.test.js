const assert = require('assert');
const fs = require('fs');
const path = require('path');
const P = require('../app/src/main/assets/js/parsers.js');

let n = 0;
async function t(name, fn) {
  try { await fn(); n++; console.log('ok  -', name); } catch (e) { console.log('FAIL-', name, '\n   ', e.stack.split('\n').slice(0, 3).join('\n    ')); process.exitCode = 1; }
}
const fx = (f) => path.join(__dirname, 'fixtures', f);
const blobOf = (buf, name) => { const b = new Blob([buf]); b.name = name; return b; };
const enc = (s) => new TextEncoder().encode(s);
async function collect(gen) { const out = []; for await (const x of gen) out.push(x); return out; }

(async () => {
  await t('csvRows: 引号/逗号/换行/CRLF/BOM/空行', () => {
    const text = '\uFEFF题目,朝代,作者,内容\r\n静夜思,唐,李白,"床前明月光，疑是地上霜,\r\n举头望明月"\r\n\r\n"带""引号""",宋,佚名,最后一行无换行符';
    const rows = [...P.csvRows(text)];
    assert.deepStrictEqual(rows[0], ['题目', '朝代', '作者', '内容']);
    assert.deepStrictEqual(rows[1], ['静夜思', '唐', '李白', '床前明月光，疑是地上霜,\r\n举头望明月']);
    assert.deepStrictEqual(rows[2], ['带"引号"', '宋', '佚名', '最后一行无换行符']);
    assert.strictEqual(rows.length, 3);
  });

  await t('csvRows: 空字段、行尾逗号', () => {
    const rows = [...P.csvRows('a,,c\n,,\nx,y,')];
    assert.deepStrictEqual(rows[0], ['a', '', 'c']);
    assert.deepStrictEqual(rows[1], ['', '', '']);
    assert.deepStrictEqual(rows[2], ['x', 'y', '']);
  });

  await t('csvRows: 大文件速度（30万行）', () => {
    let s = '题目,朝代,作者,内容\r\n';
    const line = '"静夜思","唐","李白","床前明月光，疑是地上霜。举头望明月，低头思故乡。"\r\n';
    for (let i = 0; i < 300000; i++) s += line;
    const t0 = Date.now(); let c = 0;
    for (const r of P.csvRows(s)) c++;
    const ms = Date.now() - t0;
    console.log('       300000 行用时', ms, 'ms，文本', (s.length / 1e6).toFixed(1), 'M字符');
    assert.strictEqual(c, 300001);
    assert.ok(ms < 5000);
  });

  await t('detectEncoding / decodeBest: UTF-8 与 GBK', () => {
    assert.strictEqual(P.detectEncoding(enc('床前明月光')), 'utf-8');
    const gbk = new Uint8Array([0xB4, 0xB2, 0xC7, 0xB0, 0xC3, 0xF7, 0xD4, 0xC2, 0xB9, 0xE2]); // 床前明月光
    assert.strictEqual(P.detectEncoding(gbk), 'gb18030');
    assert.strictEqual(P.decodeBest(gbk).text, '床前明月光');
    assert.strictEqual(P.decodeBest(gbk, 'gbk').text, '床前明月光');
  });

  await t('guessMapping：中英文表头', () => {
    assert.deepStrictEqual(P.guessMapping(['题目', '朝代', '作者', '内容']), { title: '题目', author: '作者', dynasty: '朝代', content: '内容', book: '' });
    assert.deepStrictEqual(P.guessMapping(['id', 'title', 'author', 'dynasty', 'paragraphs']), { title: 'title', author: 'author', dynasty: 'dynasty', content: 'paragraphs', book: '' });
    const g = P.guessMapping(['rhythmic', 'author', 'paragraphs']);
    assert.strictEqual(g.title, 'rhythmic');
    assert.strictEqual(g.content, 'paragraphs');
  });

  await t('readJsonRecords: 数组 / 带包装对象 / JSONL / 字段展平', async () => {
    const a = await P.readJsonRecords(blobOf(JSON.stringify([{ title: 'A', author: { name: '李白' }, paragraphs: ['甲。', '乙。'] }])));
    assert.deepStrictEqual(a, [{ title: 'A', author: '李白', paragraphs: '甲。\n乙。' }]);
    const b = await P.readJsonRecords(blobOf(JSON.stringify({ code: 0, data: { poems: [{ t: 1 }, { t: 2 }] } })));
    assert.strictEqual(b.length, 2);
    const c = await P.readJsonRecords(blobOf('{"a":"1"}\n{"a":"2"}\n'));
    assert.deepStrictEqual(c, [{ a: '1' }, { a: '2' }]);
  });

  await t('readCsvRecords：表头→记录对象', async () => {
    const r = await P.readCsvRecords(blobOf(enc('题目,作者\n静夜思,李白\n春晓,孟浩然\n')));
    assert.deepStrictEqual(r.fields, ['题目', '作者']);
    assert.deepStrictEqual(r.records, [{ 题目: '静夜思', 作者: '李白' }, { 题目: '春晓', 作者: '孟浩然' }]);
    const r2 = await P.readCsvRecords(blobOf(enc('a,b\nc,d\n')), 'auto', false);
    assert.deepStrictEqual(r2.fields, ['列1', '列2']);
    assert.strictEqual(r2.records.length, 2);
  });

  await t('readParagraphs: UTF-8 与 GBK 的 txt，空行跳过，超长行切分', async () => {
    const p1 = await collect(P.readParagraphs(blobOf(enc('第一段。\r\n\r\n第二段。\n第三段'))));
    assert.deepStrictEqual(p1, ['第一段。', '第二段。', '第三段']);
    const gbk = new Uint8Array([0xB4, 0xB2, 0xC7, 0xB0, 0x0A, 0xC3, 0xF7, 0xD4, 0xC2]); // 床前\n明月
    const p2 = await collect(P.readParagraphs(blobOf(gbk)));
    assert.deepStrictEqual(p2, ['床前', '明月']);
    const long = '这是一句话。'.repeat(500); // 3000 字，一行
    const p3 = await collect(P.readParagraphs(blobOf(enc(long))));
    assert.ok(p3.length >= 4 && p3.every((x) => x.length <= 700));
    assert.strictEqual(p3.join(''), long);
  });

  await t('readParagraphs: 跨 4MB 分块边界不丢字不断行', async () => {
    // 构造 >4MB 的 UTF-8 文本，行内含多字节字符，块边界必然落在字符中间
    const line = '床前明月光疑是地上霜举头望明月低头思故乡\n';
    const reps = Math.ceil((4 * 1024 * 1024 + 1000) / enc(line).length);
    const big = line.repeat(reps);
    const out = await collect(P.readParagraphs(blobOf(enc(big))));
    assert.strictEqual(out.length, reps);
    assert.ok(out.every((x) => x === '床前明月光疑是地上霜举头望明月低头思故乡'));
  });

  async function readDbf(name, memoName, opts) {
    const f = blobOf(fs.readFileSync(fx(name + '.dbf')), name + '.dbf');
    const m = memoName ? blobOf(fs.readFileSync(fx(memoName + '.fpt')), memoName + '.fpt') : null;
    const db = await P.openDbf(f, m, memoName ? memoName + '.fpt' : '', opts);
    const recs = []; for await (const b of db.records()) recs.push(...b);
    return { db, recs };
  }

  await t('dbf+fpt（VFP，GBK，备注4字节指针）', async () => {
    const { db, recs } = await readDbf('vfp_gbk', 'vfp_gbk');
    assert.strictEqual(db.encoding, 'gbk');
    assert.deepStrictEqual(db.fields.map((f) => f.name), ['TITLE', 'AUTHOR', 'DYNASTY', 'CONTENT']);
    assert.strictEqual(recs.length, 3); // 删除的那条不出现
    assert.deepStrictEqual(recs[0], { TITLE: '静夜思', AUTHOR: '李白', DYNASTY: '唐', CONTENT: '床前明月光，疑是地上霜。\r\n举头望明月，低头思故乡。' });
    assert.strictEqual(recs[1].CONTENT, '春眠不觉晓，处处闻啼鸟。夜来风雨声，花落知多少。');
    assert.strictEqual(recs[2].TITLE, '无题');
    assert.strictEqual(recs[2].CONTENT, ''); // 空备注
  });

  await t('dbf+fpt（FoxPro 2.x，备注10位数字指针）', async () => {
    const { recs } = await readDbf('fox2_gbk', 'fox2_gbk');
    assert.strictEqual(recs.length, 3);
    assert.strictEqual(recs[0].CONTENT, '床前明月光，疑是地上霜。\r\n举头望明月，低头思故乡。');
    assert.strictEqual(recs[1].AUTHOR, '孟浩然');
  });

  await t('dbf：中文字段名；手动指定编码', async () => {
    const { db, recs } = await readDbf('cnfields_gbk', 'cnfields_gbk', { encoding: 'gbk' });
    assert.deepStrictEqual(db.fields.map((f) => f.name), ['题目', '作者', '朝代', '正文']);
    assert.strictEqual(recs[0]['题目'], '静夜思');
    assert.strictEqual(recs[0]['正文'].startsWith('床前明月光'), true);
  });

  await t('dbf 没给 .fpt：备注字段为空并标记 memoMissing', async () => {
    const { db, recs } = await readDbf('vfp_gbk', null);
    assert.strictEqual(db.memoMissing, true);
    assert.strictEqual(recs[0].TITLE, '静夜思');
    assert.strictEqual(recs[0].CONTENT, '');
  });

  await t('dbf：非 dbf 文件报错', async () => {
    let err = null;
    try { await P.openDbf(blobOf(enc('hello world, not a dbf file at all, just text')), null, ''); } catch (e) { err = e; }
    assert.ok(err);
  });

  await t('dbf：大量记录 + 备注滑动窗口（5万条）', async () => {
    // 复用 vfp 结构手工拼一个 5 万条的库
    const bs = 64, N = 50000;
    const title = 20, auth = 10, memoLen = 4;
    const fieldsDesc = [['TITLE', 'C', title], ['AUTHOR', 'C', auth], ['CONTENT', 'M', memoLen]];
    const fh = Buffer.concat(fieldsDesc.map(([nm, ty, ln]) => { const b = Buffer.alloc(32); Buffer.from(nm).copy(b, 0); b[11] = ty.charCodeAt(0); b[16] = ln; return b; }));
    const hlen = 32 + fh.length + 1, rlen = 1 + title + auth + memoLen;
    const head = Buffer.alloc(32); head[0] = 0x30; head.writeUInt32LE(N, 4); head.writeUInt16LE(hlen, 8); head.writeUInt16LE(rlen, 10); head[29] = 0x03;
    const recs = Buffer.alloc(N * rlen), memo = [Buffer.alloc(512)];
    let next = 8;
    for (let i = 0; i < N; i++) {
      const o = i * rlen; recs[o] = 0x20;
      Buffer.from(('诗' + i).padEnd(title)).copy(recs, o + 1);
      const text = Buffer.from('正文' + i + '。'.repeat(1 + (i % 7)));
      const blk = Buffer.concat([Buffer.from([0, 0, 0, 1]), (() => { const b = Buffer.alloc(4); b.writeUInt32BE(text.length); return b; })(), text]);
      const pad = Buffer.alloc((bs - (blk.length % bs)) % bs);
      memo.push(blk, pad);
      recs.writeUInt32LE(next, o + 1 + title + auth);
      next += (blk.length + pad.length) / bs;
    }
    const mh = memo[0]; mh.writeUInt32BE(next, 0); mh.writeUInt16BE(bs, 6);
    const dbf = Buffer.concat([head, fh, Buffer.from([0x0D]), recs, Buffer.from([0x1A])]);
    const t0 = Date.now();
    const db = await P.openDbf(blobOf(dbf), blobOf(Buffer.concat(memo)), 'x.fpt', { encoding: 'utf-8' });
    let c = 0, last = null; for await (const b of db.records(5000)) { c += b.length; last = b[b.length - 1]; }
    console.log('       5万条用时', Date.now() - t0, 'ms');
    assert.strictEqual(c, N);
    assert.strictEqual(last.CONTENT, '正文' + (N - 1) + '。'.repeat(1 + ((N - 1) % 7)));
  });

  console.log(n + ' passed');
})();
