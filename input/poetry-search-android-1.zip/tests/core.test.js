const assert = require('assert');
const C = require('../app/src/main/assets/js/core.js');

let n = 0;
function t(name, fn) { try { fn(); n++; console.log('ok  -', name); } catch (e) { console.log('FAIL-', name, '\n   ', e.message); process.exitCode = 1; } }

t('splitSentences: 中英文标点都断句', () => {
  assert.deepStrictEqual(C.splitSentences('白玉谁家郎,回车渡天津。'), ['白玉谁家郎', '回车渡天津']);
  assert.deepStrictEqual(C.splitSentences('床前明月光，疑是地上霜。举头望明月，低头思故乡。'),
    ['床前明月光', '疑是地上霜', '举头望明月', '低头思故乡']);
  assert.deepStrictEqual(C.splitSentences('a,b.c?d!e;f:g、h'), ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h']);
  assert.deepStrictEqual(C.splitSentences('甲\n乙  丙…丁—戊'), ['甲', '乙', '丙', '丁', '戊']);
  assert.deepStrictEqual(C.splitSentences(''), []);
  assert.deepStrictEqual(C.splitSentences(null), []);
});

t('parseQuery: 任意多个空格(含全角)分词', () => {
  assert.deepStrictEqual(C.parseQuery('云月'), { tokens: ['云月'], multi: false });
  assert.deepStrictEqual(C.parseQuery('云 月'), { tokens: ['云', '月'], multi: true });
  assert.deepStrictEqual(C.parseQuery('  云   月　山 '), { tokens: ['云', '月', '山'], multi: true });
  assert.deepStrictEqual(C.parseQuery('   '), { tokens: [], multi: false });
});

const V = (...t) => C.makeVariants(t);

t('同句命中：云 月 在同一句', () => {
  const r = C.sentenceHits('云开见月明，山色空蒙雨亦奇。', V('云', '月'));
  assert.strictEqual(r.length, 1);
  assert.strictEqual(r[0].text, '云开见月明');
  assert.strictEqual(r[0].neighbor, '山色空蒙雨亦奇');
  assert.strictEqual(r[0].idx, 0);
});

t('不同句不算：云在一句、月在另一句', () => {
  const r = C.sentenceHits('云在青山外，月出东山上。', V('云', '月'));
  assert.strictEqual(r.length, 0);
});

t('相邻句：最后一句取上一句；只有一句时为空', () => {
  const r = C.sentenceHits('山高月小，水落石出，云淡风轻月下。', V('云', '月'));
  assert.strictEqual(r.length, 1);
  assert.strictEqual(r[0].text, '云淡风轻月下');
  assert.strictEqual(r[0].neighbor, '水落石出');
  const r2 = C.sentenceHits('云月', V('云', '月'));
  assert.strictEqual(r2[0].neighbor, '');
});

t('超过14字：取含全部关键词的14字窗口并标省略', () => {
  const s = '这是一个很长很长的句子里有云字然后月字也在';
  assert.ok(Array.from(s).length > 14);
  const r = C.sentenceHits(s, V('云', '月'));
  assert.strictEqual(r.length, 1);
  assert.strictEqual(Array.from(r[0].text).length, 14);
  assert.ok(r[0].text.includes('云') && r[0].text.includes('月'));
  assert.ok(r[0].pre || r[0].post);
});

t('超过14字且关键词隔太远：不算命中', () => {
  const s = '云' + '一二三四五六七八九十甲乙丙丁戊己庚辛' + '月';
  const r = C.sentenceHits(s, V('云', '月'));
  assert.strictEqual(r.length, 0);
});

t('三个词都要在同一句', () => {
  assert.strictEqual(C.sentenceHits('云月山水', V('云', '月', '山')).length, 1);
  assert.strictEqual(C.sentenceHits('云月，山水', V('云', '月', '山')).length, 0);
});

t('相邻句也最多14字', () => {
  const r = C.sentenceHits('云月，一二三四五六七八九十甲乙丙丁戊己', V('云', '月'));
  assert.strictEqual(Array.from(r[0].neighbor).length, 15); // 14字 + …
  assert.ok(r[0].neighbor.endsWith('…'));
});

t('繁简写法变体：任一写法命中即可', () => {
  const v = C.makeVariants(['云'], [() => '雲']);
  assert.deepStrictEqual(v, [['云', '雲']]);
  const r = C.sentenceHits('雲開見月明', C.makeVariants(['云', '月'], [(x) => ({ 云: '雲' }[x] || x)]));
  assert.strictEqual(r.length, 1);
  assert.deepStrictEqual(r[0].hits, ['雲', '月']);
});

t('highlight：转义并标记', () => {
  assert.strictEqual(C.highlight('云<月>', ['云', '月']), '<mark>云</mark>&lt;<mark>月</mark>&gt;');
  assert.strictEqual(C.highlight('abc', []), 'abc');
});

const P = { title: '静夜思', author: '李白', dynasty: '唐', book: '全唐诗', content: '床前明月光，疑是地上霜。举头望明月，低头思故乡。' };

t('matchPoem：普通搜索(单词)按范围', () => {
  assert.strictEqual(C.matchPoem(P, V('明月'), 'content', false).length, 1);
  assert.strictEqual(C.matchPoem(P, V('静夜'), 'content', false).length, 0);
  assert.strictEqual(C.matchPoem(P, V('静夜'), 'title', false).length, 1);
  assert.strictEqual(C.matchPoem(P, V('李白'), 'author', false).length, 1);
  assert.strictEqual(C.matchPoem(P, V('李白'), 'all', false).length, 1);
  assert.strictEqual(C.matchPoem(P, V('不存在'), 'all', false).length, 0);
});

t('matchPoem：空格多词 → 例句；all 范围也包含诗题/作者', () => {
  const r = C.matchPoem(P, V('明月', '光'), 'content', true);
  assert.strictEqual(r.length, 1);
  assert.strictEqual(r[0].kind, 'sentence');
  assert.strictEqual(r[0].text, '床前明月光');
  assert.strictEqual(r[0].neighbor, '疑是地上霜');
  const r2 = C.matchPoem(P, V('李', '白'), 'all', true);
  assert.ok(r2.some((x) => x.kind === 'poem' && x.field === 'author'));
  const r3 = C.matchPoem(P, V('举头', '低头'), 'content', true);
  assert.strictEqual(r3.length, 0); // 在不同句
});

t('passFilters：朝代/书籍', () => {
  assert.ok(C.passFilters(P, null));
  assert.ok(C.passFilters(P, { dynasties: new Set(['唐']) }));
  assert.ok(!C.passFilters(P, { dynasties: new Set(['宋']) }));
  assert.ok(C.passFilters({ dynasty: '元末明初' }, { dynasties: new Set(['明']) }));
  assert.ok(C.passFilters({ dynasty: '元末明初' }, { dynasties: new Set(['元']) }));
  assert.ok(!C.passFilters({ dynasty: '' }, { dynasties: new Set(['元']) }));
  assert.ok(C.passFilters(P, { books: new Set(['全唐诗']) }));
  assert.ok(!C.passFilters(P, { books: new Set(['宋词']) }));
  assert.ok(C.passFilters(P, { dynasties: new Set(), books: new Set() }));
});

t('dedupKey：同一句跨库合并', () => {
  const a = C.dedupKey(P, { kind: 'sentence', text: '床前明月光' });
  const b = C.dedupKey({ author: '李白' }, { kind: 'sentence', text: '床前明月光' });
  assert.strictEqual(a, b);
});

t('poemLines：有换行按换行，否则按句末标点断行', () => {
  assert.deepStrictEqual(C.poemLines('甲乙。\n丙丁。'), ['甲乙。', '丙丁。']);
  assert.deepStrictEqual(C.poemLines('床前明月光，疑是地上霜。举头望明月，低头思故乡。'),
    ['床前明月光，疑是地上霜。', '举头望明月，低头思故乡。']);
});

console.log(n + ' passed');
